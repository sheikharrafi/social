import MainLayout from '@/components/layout/MainLayout';
import PostDetailClient from '@/components/features/feed/PostDetailClient';
export default function PostDetailPage({ params }: { params: { id: string } }) {
  return <MainLayout><PostDetailClient postId={params.id} /></MainLayout>;
}
