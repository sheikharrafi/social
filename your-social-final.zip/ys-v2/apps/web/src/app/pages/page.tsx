import MainLayout from '@/components/layout/MainLayout';
import PagesClient from '@/components/features/groups/PagesClient';
export default function PagesPage() {
  return <MainLayout><PagesClient /></MainLayout>;
}
