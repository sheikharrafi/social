import { Suspense } from 'react';
import ResetPasswordClient from '@/components/features/auth/ResetPasswordClient';
import { Spinner } from '@/components/ui/index';

export default function ResetPasswordPage() {
  return (
    <Suspense fallback={<div className="flex justify-center py-20"><Spinner size="lg" /></div>}>
      <ResetPasswordClient />
    </Suspense>
  );
}
