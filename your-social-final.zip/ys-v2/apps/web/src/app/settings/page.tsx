import MainLayout from '@/components/layout/MainLayout';
import SettingsClient from '@/components/features/settings/SettingsClient';
export default function SettingsPage() {
  return <MainLayout><SettingsClient tab="profile" /></MainLayout>;
}
