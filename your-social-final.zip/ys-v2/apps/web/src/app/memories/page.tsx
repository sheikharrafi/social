import MainLayout from '@/components/layout/MainLayout';
import MemoriesClient from '@/components/features/memories/MemoriesClient';
export default function MemoriesPage() {
  return <MainLayout><MemoriesClient /></MainLayout>;
}
