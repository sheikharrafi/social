import type { Metadata } from 'next';
import { ThemeProvider } from '@/components/ui/theme-provider';
import { Toaster } from 'react-hot-toast';
import './globals.css';

export const metadata: Metadata = {
  title: { default: 'Your Social', template: '%s | Your Social' },
  description: 'Connect with friends and the world around you on Your Social.',
  keywords: ['social media', 'connect', 'friends', 'community'],
  openGraph: {
    title: 'Your Social',
    description: 'Connect with friends and the world around you.',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head />
      <body>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          {children}
          <Toaster
            position="top-right"
            toastOptions={{
              className: 'text-sm font-medium',
              duration: 4000,
            }}
          />
        </ThemeProvider>
      </body>
    </html>
  );
}
