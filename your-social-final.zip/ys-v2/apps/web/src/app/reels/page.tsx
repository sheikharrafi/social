import MainLayout from '@/components/layout/MainLayout';
import ReelsClient from '@/components/features/reels/ReelsClient';
export default function ReelsPage() {
  return <MainLayout><ReelsClient /></MainLayout>;
}
