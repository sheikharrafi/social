import MainLayout from '@/components/layout/MainLayout';
import FriendsClient from '@/components/features/friends/FriendsClient';
export default function FriendsPage() {
  return <MainLayout><FriendsClient tab="suggestions" /></MainLayout>;
}
