import MainLayout from '@/components/layout/MainLayout';
import ProfileClient from '@/components/features/profile/ProfileClient';

export default function ProfilePage({ params }: { params: { userId: string } }) {
  return <MainLayout><ProfileClient userId={params.userId} /></MainLayout>;
}
