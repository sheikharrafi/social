'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { Eye, EyeOff, Mail, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/index';
import useAuthStore from '@/store/auth.store';
import toast from 'react-hot-toast';

export default function LoginPage() {
  const [form, setForm] = useState({ email: '', password: '' });
  const [showPwd, setShowPwd] = useState(false);
  const { login, isLoading } = useAuthStore();
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const result = await login(form.email, form.password);
    if (result.success) { toast.success('Welcome back!'); router.push('/'); }
    else toast.error(result.message || 'Login failed');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background flex items-center justify-center p-4">
      <div className="w-full max-w-5xl grid lg:grid-cols-2 gap-8 items-center">
        {/* Left */}
        <motion.div initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} className="hidden lg:block space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-2xl gradient-brand flex items-center justify-center">
              <span className="text-white font-black text-3xl">Y</span>
            </div>
            <h1 className="text-4xl font-black gradient-text">YourSocial</h1>
          </div>
          <p className="text-2xl text-foreground/80 font-medium leading-snug">
            Connect with friends and the world around you.
          </p>
          <div className="space-y-3">
            {['📸 Share your moments', '💬 Chat with friends in real-time', '🌍 Discover communities', '📹 Watch & create Reels'].map(f => (
              <div key={f} className="flex items-center gap-3 text-muted-foreground">
                <span className="text-lg">{f.split(' ')[0]}</span>
                <span className="text-sm font-medium">{f.slice(3)}</span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Right */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <div className="bg-card border border-border/50 rounded-3xl p-8 shadow-xl">
            <div className="lg:hidden flex items-center gap-2 mb-6">
              <div className="w-9 h-9 rounded-xl gradient-brand flex items-center justify-center">
                <span className="text-white font-black text-lg">Y</span>
              </div>
              <span className="font-black text-xl gradient-text">YourSocial</span>
            </div>

            <h2 className="text-2xl font-bold mb-2">Welcome back</h2>
            <p className="text-muted-foreground text-sm mb-6">Log in to your account to continue</p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                label="Email address"
                type="email"
                placeholder="you@example.com"
                value={form.email}
                onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                leftIcon={<Mail className="w-4 h-4" />}
                required
              />
              <Input
                label="Password"
                type={showPwd ? 'text' : 'password'}
                placeholder="Your password"
                value={form.password}
                onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                leftIcon={<Lock className="w-4 h-4" />}
                rightIcon={
                  <button type="button" onClick={() => setShowPwd(p => !p)}>
                    {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                }
                required
              />

              <div className="flex justify-end">
                <Link href="/forgot-password" className="text-sm text-primary hover:underline">Forgot password?</Link>
              </div>

              <Button type="submit" className="w-full h-11 text-base" loading={isLoading}>Log In</Button>
            </form>

            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-border" /></div>
              <div className="relative flex justify-center"><span className="bg-card px-3 text-xs text-muted-foreground">or</span></div>
            </div>

            <Link href="/register">
              <Button variant="outline" className="w-full h-11 text-base">Create new account</Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
