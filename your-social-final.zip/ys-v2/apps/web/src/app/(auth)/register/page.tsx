'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/index';
import useAuthStore from '@/store/auth.store';
import toast from 'react-hot-toast';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const DAYS = Array.from({ length: 31 }, (_, i) => i + 1);
const YEAR = new Date().getFullYear();
const YEARS = Array.from({ length: 100 }, (_, i) => YEAR - i);

export default function RegisterPage() {
  const [form, setForm] = useState({ firstName: '', lastName: '', email: '', password: '', gender: '', day: '1', month: '1', year: String(YEAR - 18) });
  const [showPwd, setShowPwd] = useState(false);
  const { register, isLoading } = useAuthStore();
  const router = useRouter();

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.gender) return toast.error('Please select a gender');
    if (form.password.length < 6) return toast.error('Password must be at least 6 characters');
    const birthday = new Date(`${form.year}-${form.month}-${form.day}`);
    const result = await register({ firstName: form.firstName, lastName: form.lastName, email: form.email, password: form.password, gender: form.gender.toUpperCase(), birthday });
    if (result.success) { toast.success('Account created! Welcome 🎉'); router.push('/'); }
    else toast.error(result.message || 'Registration failed');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background flex items-center justify-center p-4">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        <div className="bg-card border border-border/50 rounded-3xl p-8 shadow-xl">
          <div className="flex items-center gap-2 mb-6">
            <div className="w-9 h-9 rounded-xl gradient-brand flex items-center justify-center">
              <span className="text-white font-black text-lg">Y</span>
            </div>
            <span className="font-black text-xl gradient-text">YourSocial</span>
          </div>

          <h2 className="text-2xl font-bold mb-1">Create account</h2>
          <p className="text-muted-foreground text-sm mb-6">It's quick and easy.</p>

          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <Input placeholder="First name" value={form.firstName} onChange={e => set('firstName', e.target.value)} required />
              <Input placeholder="Last name" value={form.lastName} onChange={e => set('lastName', e.target.value)} required />
            </div>

            <Input type="email" placeholder="Email address" value={form.email} onChange={e => set('email', e.target.value)} required />

            <Input
              type={showPwd ? 'text' : 'password'}
              placeholder="New password (min 6 chars)"
              value={form.password}
              onChange={e => set('password', e.target.value)}
              rightIcon={<button type="button" onClick={() => setShowPwd(p => !p)}>{showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>}
              required
            />

            {/* Birthday */}
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Date of birth</label>
              <div className="grid grid-cols-3 gap-2">
                <select className="h-10 rounded-xl border border-input bg-background px-2 text-sm focus:ring-2 focus:ring-ring outline-none" value={form.month} onChange={e => set('month', e.target.value)}>
                  {MONTHS.map((m, i) => <option key={m} value={i + 1}>{m}</option>)}
                </select>
                <select className="h-10 rounded-xl border border-input bg-background px-2 text-sm focus:ring-2 focus:ring-ring outline-none" value={form.day} onChange={e => set('day', e.target.value)}>
                  {DAYS.map(d => <option key={d} value={d}>{d}</option>)}
                </select>
                <select className="h-10 rounded-xl border border-input bg-background px-2 text-sm focus:ring-2 focus:ring-ring outline-none" value={form.year} onChange={e => set('year', e.target.value)}>
                  {YEARS.map(y => <option key={y} value={y}>{y}</option>)}
                </select>
              </div>
            </div>

            {/* Gender */}
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">Gender</label>
              <div className="grid grid-cols-3 gap-2">
                {['Female', 'Male', 'Other'].map(g => (
                  <label key={g} className={`flex items-center justify-between px-3 h-10 rounded-xl border cursor-pointer transition-colors ${form.gender === g ? 'border-primary bg-primary/10 text-primary' : 'border-input hover:bg-muted'}`}>
                    <span className="text-sm font-medium">{g}</span>
                    <input type="radio" name="gender" value={g} onChange={e => set('gender', e.target.value)} className="accent-primary" />
                  </label>
                ))}
              </div>
            </div>

            <p className="text-xs text-muted-foreground">By clicking Sign Up, you agree to our <span className="text-primary">Terms</span> and <span className="text-primary">Privacy Policy</span>.</p>

            <Button type="submit" className="w-full h-11 text-base" loading={isLoading}>Sign Up</Button>
          </form>

          <p className="text-center mt-4 text-sm">
            Already have an account? <Link href="/login" className="text-primary font-semibold hover:underline">Log in</Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
