import MainLayout from '@/components/layout/MainLayout';
import AdminClient from '@/components/features/admin/AdminClient';
export default function AdminPage() {
  return <MainLayout><AdminClient /></MainLayout>;
}
