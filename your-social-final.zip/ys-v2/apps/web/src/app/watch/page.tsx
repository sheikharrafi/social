import MainLayout from '@/components/layout/MainLayout';
import WatchClient from '@/components/features/watch/WatchClient';
export default function WatchPage() {
  return <MainLayout><WatchClient /></MainLayout>;
}
