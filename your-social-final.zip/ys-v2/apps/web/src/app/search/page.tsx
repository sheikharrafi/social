import { Suspense } from 'react';
import MainLayout from '@/components/layout/MainLayout';
import SearchClient from '@/components/features/search/SearchClient';
import { Spinner } from '@/components/ui/index';

export default function SearchPage() {
  return (
    <MainLayout>
      <Suspense fallback={<div className="flex justify-center py-20"><Spinner size="lg" /></div>}>
        <SearchClient />
      </Suspense>
    </MainLayout>
  );
}
