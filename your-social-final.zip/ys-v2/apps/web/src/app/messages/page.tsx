import { Suspense } from 'react';
import MainLayout from '@/components/layout/MainLayout';
import MessengerClient from '@/components/features/messenger/MessengerClient';
import { Spinner } from '@/components/ui/index';

export default function MessagesPage() {
  return (
    <MainLayout>
      <Suspense fallback={<div className="flex justify-center py-20"><Spinner size="lg" /></div>}>
        <MessengerClient />
      </Suspense>
    </MainLayout>
  );
}
