import { Suspense } from 'react';
import VerifyEmailClient from '@/components/features/auth/VerifyEmailClient';
import { Spinner } from '@/components/ui/index';

export default function VerifyEmailPage() {
  return (
    <Suspense fallback={<div className="flex justify-center py-20"><Spinner size="lg" /></div>}>
      <VerifyEmailClient />
    </Suspense>
  );
}
