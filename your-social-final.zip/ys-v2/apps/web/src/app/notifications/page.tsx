import MainLayout from '@/components/layout/MainLayout';
import { NotificationsClient } from '@/components/features/notifications/NotificationsClient';
export default function NotificationsPage() {
  return <MainLayout><NotificationsClient /></MainLayout>;
}
