import MainLayout from '@/components/layout/MainLayout';
import FeedClient from '@/components/features/feed/FeedClient';

export default function HomePage() {
  return (
    <MainLayout>
      <FeedClient />
    </MainLayout>
  );
}
