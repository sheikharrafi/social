import MainLayout from '@/components/layout/MainLayout';
import GamingClient from '@/components/features/gaming/GamingClient';
export default function GamingPage() {
  return <MainLayout><GamingClient /></MainLayout>;
}
