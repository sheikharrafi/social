import MainLayout from '@/components/layout/MainLayout';
import EventDetailClient from '@/components/features/events/EventDetailClient';
export default function EventDetailPage({ params }: { params: { id: string } }) {
  return <MainLayout><EventDetailClient eventId={params.id} /></MainLayout>;
}
