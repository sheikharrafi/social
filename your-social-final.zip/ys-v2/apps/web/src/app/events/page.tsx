import MainLayout from '@/components/layout/MainLayout';
import EventsClient from '@/components/features/events/EventsClient';

export default function EventsPage() {
  return <MainLayout><EventsClient /></MainLayout>;
}
