import MainLayout from '@/components/layout/MainLayout';
import SavedClient from '@/components/features/feed/SavedClient';
export default function SavedPage() {
  return <MainLayout><SavedClient /></MainLayout>;
}
