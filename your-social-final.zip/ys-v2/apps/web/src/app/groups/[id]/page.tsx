import MainLayout from '@/components/layout/MainLayout';
import GroupDetailClient from '@/components/features/groups/GroupDetailClient';
export default function GroupDetailPage({ params }: { params: { id: string } }) {
  return <MainLayout><GroupDetailClient groupId={params.id} /></MainLayout>;
}
