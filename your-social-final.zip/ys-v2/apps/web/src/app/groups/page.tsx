import MainLayout from '@/components/layout/MainLayout';
import GroupsClient from '@/components/features/groups/GroupsClient';
export default function GroupsPage() {
  return <MainLayout><GroupsClient /></MainLayout>;
}
