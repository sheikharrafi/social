import MainLayout from '@/components/layout/MainLayout';
import MarketplaceClient from '@/components/features/marketplace/MarketplaceClient';
export default function MarketplacePage() {
  return <MainLayout><MarketplaceClient /></MainLayout>;
}
