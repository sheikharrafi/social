'use client';
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { authAPI } from '@/lib/api';

export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  username?: string;
  profilePicture?: string;
  coverPhoto?: string;
  bio?: string;
  role: string;
  isVerified: boolean;
  emailVerified: boolean;
  isOnline: boolean;
  website?: string;
  location?: string;
  workplace?: string;
  education?: string;
  relationship?: string;
  birthday?: string;
  gender?: string;
  hometown?: string;
  privacyProfile?: string;
  privacyFriendList?: string;
  privacyPostDefault?: string;
  notifFriendRequests?: boolean;
  notifPostLikes?: boolean;
  notifComments?: boolean;
  notifMessages?: boolean;
  notifGroupActivity?: boolean;
  _count?: { friendships: number; followers: number; following: number; posts: number; reels: number };
}

interface AuthState {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; message?: string }>;
  register: (data: any) => Promise<{ success: boolean; message?: string }>;
  logout: () => Promise<void>;
  getMe: () => Promise<void>;
  updateUser: (data: Partial<User>) => void;
  setToken: (token: string) => void;
}

const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      isLoading: false,
      isAuthenticated: false,

      setToken: (token) => {
        if (typeof window !== 'undefined') localStorage.setItem('ys_token', token);
        set({ token });
      },

      login: async (email, password) => {
        set({ isLoading: true });
        try {
          const { data } = await authAPI.login({ email, password });
          if (typeof window !== 'undefined') localStorage.setItem('ys_token', data.token);
          set({ user: data.user, token: data.token, isAuthenticated: true, isLoading: false });
          return { success: true };
        } catch (err: any) {
          set({ isLoading: false });
          return { success: false, message: err.response?.data?.message || 'Login failed' };
        }
      },

      register: async (formData) => {
        set({ isLoading: true });
        try {
          const { data } = await authAPI.register(formData);
          if (typeof window !== 'undefined') localStorage.setItem('ys_token', data.token);
          set({ user: data.user, token: data.token, isAuthenticated: true, isLoading: false });
          return { success: true };
        } catch (err: any) {
          set({ isLoading: false });
          return { success: false, message: err.response?.data?.message || 'Registration failed' };
        }
      },

      logout: async () => {
        try { await authAPI.logout(); } catch {}
        if (typeof window !== 'undefined') localStorage.removeItem('ys_token');
        set({ user: null, token: null, isAuthenticated: false });
      },

      getMe: async () => {
        const token = typeof window !== 'undefined' ? localStorage.getItem('ys_token') : null;
        if (!token) return;
        set({ isLoading: true });
        try {
          const { data } = await authAPI.getMe();
          set({ user: data.user, isAuthenticated: true, isLoading: false });
        } catch {
          if (typeof window !== 'undefined') localStorage.removeItem('ys_token');
          set({ user: null, token: null, isAuthenticated: false, isLoading: false });
        }
      },

      updateUser: (data) => set((s) => ({ user: s.user ? { ...s.user, ...data } : null })),
    }),
    { name: 'ys-auth', partialize: (s) => ({ token: s.token, user: s.user, isAuthenticated: s.isAuthenticated }) }
  )
);

export default useAuthStore;
