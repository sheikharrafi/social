'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Calendar, MapPin, Users, Clock, Globe, Lock, X, ChevronLeft, ChevronRight } from 'lucide-react';
import { Card, Skeleton, EmptyState, Badge } from '@/components/ui/index';
import { Button } from '@/components/ui/button';
import { eventAPI } from '@/lib/api';
import { formatDate } from '@/lib/utils';
import toast from 'react-hot-toast';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isToday, addMonths, subMonths } from 'date-fns';

const TABS = ['Upcoming', 'My Events', 'Calendar'];
const CATEGORIES = ['General','Music','Art','Food & Drink','Sports','Technology','Business','Education','Health','Travel','Other'];

export default function EventsClient() {
  const [tab, setTab] = useState('Upcoming');
  const [events, setEvents] = useState<any[]>([]);
  const [myEvents, setMyEvents] = useState<{ hosting: any[]; attending: any[] }>({ hosting: [], attending: [] });
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [calendarDate, setCalendarDate] = useState(new Date());
  const router = useRouter();

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    setLoading(true);
    try {
      const [upcoming, my] = await Promise.all([
        eventAPI.getAll({ upcoming: true }),
        eventAPI.getMy(),
      ]);
      setEvents(upcoming.data.events || []);
      setMyEvents(my.data);
    } catch {}
    setLoading(false);
  };

  const handleRSVP = async (eventId: string, rsvp: string) => {
    try {
      await eventAPI.rsvp(eventId, rsvp);
      toast.success(`RSVP: ${rsvp}`);
      fetchEvents();
    } catch { toast.error('Failed'); }
  };

  // Calendar helpers
  const days = eachDayOfInterval({ start: startOfMonth(calendarDate), end: endOfMonth(calendarDate) });
  const firstDayOfWeek = startOfMonth(calendarDate).getDay();
  const eventDates = events.map(e => new Date(e.startDate));

  const list = tab === 'My Events' ? [...myEvents.hosting, ...myEvents.attending] : events;

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Events</h1>
        <Button onClick={() => setShowCreate(true)}><Plus className="w-4 h-4" /> Create Event</Button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6 border-b border-border pb-0">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-2 text-sm font-semibold border-b-2 -mb-px transition-colors ${tab === t ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`}>
            {t}
          </button>
        ))}
      </div>

      {tab === 'Calendar' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Calendar */}
          <Card className="p-4 lg:col-span-1">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold">{format(calendarDate, 'MMMM yyyy')}</h3>
              <div className="flex gap-1">
                <Button variant="ghost" size="icon-sm" onClick={() => setCalendarDate(subMonths(calendarDate, 1))}>
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon-sm" onClick={() => setCalendarDate(addMonths(calendarDate, 1))}>
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-7 gap-0 text-xs font-semibold text-muted-foreground mb-2">
              {['Su','Mo','Tu','We','Th','Fr','Sa'].map(d => (
                <div key={d} className="text-center py-1">{d}</div>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-0">
              {Array.from({ length: firstDayOfWeek }).map((_, i) => <div key={`empty-${i}`} />)}
              {days.map(day => {
                const hasEvent = eventDates.some(d => isSameDay(d, day));
                return (
                  <button key={day.toString()}
                    className={`aspect-square flex flex-col items-center justify-center rounded-lg text-xs transition-colors relative ${isToday(day) ? 'bg-primary text-primary-foreground font-bold' : 'hover:bg-muted'}`}>
                    {format(day, 'd')}
                    {hasEvent && <div className={`w-1 h-1 rounded-full mt-0.5 ${isToday(day) ? 'bg-white' : 'bg-primary'}`} />}
                  </button>
                );
              })}
            </div>
          </Card>

          {/* Events this month */}
          <div className="lg:col-span-2 space-y-3">
            <h3 className="font-semibold text-muted-foreground">{format(calendarDate, 'MMMM yyyy')}</h3>
            {events.filter(e => {
              const d = new Date(e.startDate);
              return d.getMonth() === calendarDate.getMonth() && d.getFullYear() === calendarDate.getFullYear();
            }).map(e => <EventCard key={e.id} event={e} onClick={() => router.push(`/events/${e.id}`)} onRSVP={handleRSVP} />)}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {loading ? (
            Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-72 rounded-2xl" />)
          ) : list.length === 0 ? (
            <div className="col-span-3">
              <EmptyState icon="📅" title="No events" description="Create an event or discover what's happening."
                action={<Button onClick={() => setShowCreate(true)}><Plus className="w-4 h-4" /> Create Event</Button>} />
            </div>
          ) : list.map((e, i) => (
            <motion.div key={e.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <EventCard event={e} onClick={() => router.push(`/events/${e.id}`)} onRSVP={handleRSVP} />
            </motion.div>
          ))}
        </div>
      )}

      {showCreate && <CreateEventModal onClose={() => setShowCreate(false)} onCreate={e => { setEvents(p => [e, ...p]); setShowCreate(false); router.push(`/events/${e.id}`); }} />}
    </div>
  );
}

function EventCard({ event: e, onClick, onRSVP }: any) {
  const start = new Date(e.startDate);
  return (
    <Card className="overflow-hidden cursor-pointer hover:shadow-md transition-shadow group" onClick={onClick}>
      <div className="h-40 bg-gradient-to-br from-blue-400/30 to-violet-500/30 relative overflow-hidden">
        {e.coverPhoto ? (
          <img src={e.coverPhoto} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-5xl">📅</div>
        )}
        {/* Date badge */}
        <div className="absolute top-3 left-3 bg-card rounded-xl overflow-hidden shadow-md w-12 text-center">
          <div className="bg-destructive py-0.5 text-white text-[10px] font-bold uppercase">{format(start, 'MMM')}</div>
          <div className="text-lg font-black py-0.5">{format(start, 'd')}</div>
        </div>
        <div className="absolute top-3 right-3">
          <Badge variant={e.privacy === 'PUBLIC' ? 'default' : 'secondary'} className="text-xs">
            {e.privacy === 'PUBLIC' ? <Globe className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
          </Badge>
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-bold text-sm mb-2 line-clamp-2">{e.title}</h3>
        <div className="space-y-1 text-xs text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-primary" />
            <span>{format(start, 'EEE, MMM d · h:mm a')}</span>
          </div>
          {e.location && (
            <div className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-rose-500" />
              <span className="truncate">{e.location}</span>
            </div>
          )}
          <div className="flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5" />
            <span>{e._count?.attendees || 0} going</span>
          </div>
        </div>
        <div className="flex gap-2 mt-3" onClick={ev => ev.stopPropagation()}>
          <Button size="sm" className="flex-1" onClick={() => onRSVP(e.id, 'GOING')}>Going</Button>
          <Button size="sm" variant="outline" onClick={() => onRSVP(e.id, 'MAYBE')}>Maybe</Button>
        </div>
      </div>
    </Card>
  );
}

function CreateEventModal({ onClose, onCreate }: any) {
  const [form, setForm] = useState({
    title: '', description: '', startDate: '', endDate: '',
    location: '', onlineLink: '', privacy: 'PUBLIC', category: 'General', coverPhoto: '',
  });
  const [loading, setLoading] = useState(false);
  const f = (k: string) => (e: any) => setForm(p => ({ ...p, [k]: e.target.value }));

  const create = async () => {
    if (!form.title.trim() || !form.startDate) return toast.error('Title and start date required');
    setLoading(true);
    try {
      const { data } = await eventAPI.create(form);
      toast.success('Event created!');
      onCreate(data.event);
    } catch { toast.error('Failed to create event'); }
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4" onClick={e => e.target === e.currentTarget && onClose()}>
      <motion.div initial={{ scale: 0.95, y: 10 }} animate={{ scale: 1, y: 0 }}
        className="bg-card rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div />
          <h3 className="font-bold text-base">Create Event</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="overflow-y-auto flex-1 p-4 space-y-3">
          <input className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring"
            placeholder="Event title *" value={form.title} onChange={f('title')} />
          <textarea className="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring resize-none"
            rows={3} placeholder="Event description..." value={form.description} onChange={f('description')} />
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Start date & time *</label>
              <input type="datetime-local" className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring"
                value={form.startDate} onChange={f('startDate')} />
            </div>
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">End date & time</label>
              <input type="datetime-local" className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring"
                value={form.endDate} onChange={f('endDate')} />
            </div>
          </div>
          <input className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring"
            placeholder="📍 Location" value={form.location} onChange={f('location')} />
          <input className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring"
            placeholder="🔗 Online link (optional)" value={form.onlineLink} onChange={f('onlineLink')} />
          <div className="grid grid-cols-2 gap-2">
            <select className="h-10 rounded-xl border border-input bg-background px-3 text-sm outline-none" value={form.privacy} onChange={f('privacy')}>
              <option value="PUBLIC">🌐 Public</option>
              <option value="FRIENDS">👥 Friends</option>
              <option value="PRIVATE">🔒 Private</option>
            </select>
            <select className="h-10 rounded-xl border border-input bg-background px-3 text-sm outline-none" value={form.category} onChange={f('category')}>
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>
        <div className="p-4 border-t border-border">
          <Button className="w-full" onClick={create} loading={loading}>Create Event</Button>
        </div>
      </motion.div>
    </div>
  );
}
