'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { Calendar, MapPin, Globe, Lock, Users, Clock, Share2, Edit2, Trash2, CheckCircle, HelpCircle, XCircle, ArrowLeft } from 'lucide-react';
import { Avatar, Card, Skeleton, Badge } from '@/components/ui/index';
import { Button } from '@/components/ui/button';
import { eventAPI } from '@/lib/api';
import useAuthStore from '@/store/auth.store';
import { format } from 'date-fns';
import toast from 'react-hot-toast';

export default function EventDetailClient({ eventId }: { eventId: string }) {
  const { user } = useAuthStore();
  const router = useRouter();
  const [event, setEvent] = useState<any>(null);
  const [myRsvp, setMyRsvp] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    eventAPI.get(eventId)
      .then(r => { setEvent(r.data.event); setMyRsvp(r.data.myRsvp); setLoading(false); })
      .catch(() => setLoading(false));
  }, [eventId]);

  const handleRSVP = async (rsvp: string) => {
    try {
      await eventAPI.rsvp(eventId, rsvp);
      setMyRsvp(rsvp);
      toast.success(`RSVP updated: ${rsvp}`);
    } catch { toast.error('Failed to update RSVP'); }
  };

  const handleDelete = async () => {
    if (!confirm('Delete this event?')) return;
    try {
      await eventAPI.delete(eventId);
      toast.success('Event deleted');
      router.push('/events');
    } catch { toast.error('Failed'); }
  };

  if (loading) return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <Skeleton className="h-64 w-full rounded-2xl mb-4" />
      <Skeleton className="h-8 w-64 mb-2" />
      <Skeleton className="h-4 w-32" />
    </div>
  );

  if (!event) return (
    <div className="max-w-3xl mx-auto px-4 py-6 text-center">
      <div className="text-5xl mb-4">📅</div>
      <h2 className="text-xl font-bold">Event not found</h2>
      <Button className="mt-4" variant="outline" onClick={() => router.push('/events')}>
        <ArrowLeft className="w-4 h-4" /> Back to Events
      </Button>
    </div>
  );

  const start = new Date(event.startDate);
  const end = event.endDate ? new Date(event.endDate) : null;
  const isHost = event.host?.id === user?.id;

  const RSVP_OPTIONS = [
    { value: 'GOING', label: 'Going', icon: CheckCircle, color: 'bg-emerald-500' },
    { value: 'MAYBE', label: 'Maybe', icon: HelpCircle, color: 'bg-amber-500' },
    { value: 'NOT_GOING', label: "Can't Go", icon: XCircle, color: 'bg-muted' },
  ];

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <button onClick={() => router.push('/events')} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Events
      </button>

      {/* Cover */}
      <div className="relative h-64 rounded-2xl overflow-hidden bg-gradient-to-br from-blue-400/30 to-violet-500/30 mb-6">
        {event.coverPhoto ? (
          <img src={event.coverPhoto} alt="" className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-7xl">📅</div>
        )}
        {isHost && (
          <div className="absolute top-3 right-3 flex gap-2">
            <Button size="sm" variant="secondary" onClick={handleDelete}>
              <Trash2 className="w-3.5 h-3.5" /> Delete
            </Button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Main info */}
        <div className="md:col-span-2 space-y-4">
          <div>
            <div className="flex items-start gap-2 mb-2">
              <h1 className="text-2xl font-black flex-1">{event.title}</h1>
              <Badge variant={event.privacy === 'PUBLIC' ? 'default' : 'secondary'}>
                {event.privacy === 'PUBLIC' ? <Globe className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
                {event.privacy}
              </Badge>
            </div>
            {event.category && <Badge variant="secondary">{event.category}</Badge>}
          </div>

          {/* RSVP buttons */}
          <div className="flex gap-2">
            {RSVP_OPTIONS.map(opt => (
              <Button key={opt.value} size="sm"
                variant={myRsvp === opt.value ? 'default' : 'outline'}
                className={myRsvp === opt.value ? opt.color + ' border-0 text-white hover:opacity-90' : ''}
                onClick={() => handleRSVP(opt.value)}>
                <opt.icon className="w-3.5 h-3.5" />
                {opt.label}
              </Button>
            ))}
            <Button size="sm" variant="outline">
              <Share2 className="w-3.5 h-3.5" /> Share
            </Button>
          </div>

          {/* Description */}
          {event.description && (
            <Card className="p-4">
              <h3 className="font-bold mb-2">About this event</h3>
              <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-wrap">{event.description}</p>
            </Card>
          )}

          {/* Attendees */}
          <Card className="p-4">
            <h3 className="font-bold mb-3">{event._count?.attendees || 0} Going</h3>
            {event.attendees?.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {event.attendees.slice(0, 12).map((a: any) => (
                  <div key={a.userId} className="flex items-center gap-1.5 bg-muted rounded-full px-3 py-1">
                    <div className="w-5 h-5 rounded-full bg-primary flex items-center justify-center text-white text-xs font-bold">
                      {a.userId?.[0]?.toUpperCase()}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">Be the first to RSVP!</p>
            )}
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-3">
          <Card className="p-4 space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary flex-shrink-0">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <p className="font-semibold text-sm">{format(start, 'EEEE, MMMM d, yyyy')}</p>
                <p className="text-xs text-muted-foreground">{format(start, 'h:mm a')}{end ? ` – ${format(end, 'h:mm a')}` : ''}</p>
              </div>
            </div>

            {event.location && (
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-rose-500/10 flex items-center justify-center text-rose-500 flex-shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-semibold text-sm">{event.location}</p>
                  <p className="text-xs text-muted-foreground">View map</p>
                </div>
              </div>
            )}

            {event.onlineLink && (
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-500 flex-shrink-0">
                  <Globe className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-semibold text-sm">Online Event</p>
                  <a href={event.onlineLink} className="text-xs text-primary hover:underline" target="_blank" rel="noreferrer">Join link</a>
                </div>
              </div>
            )}
          </Card>

          {/* Host */}
          <Card className="p-4">
            <p className="text-xs font-semibold text-muted-foreground mb-2">Hosted by</p>
            <div className="flex items-center gap-3">
              <Avatar src={event.host?.profilePicture} firstName={event.host?.firstName} lastName={event.host?.lastName} size="md" />
              <div>
                <p className="font-semibold text-sm">{event.host?.firstName} {event.host?.lastName}</p>
                {event.host?.username && <p className="text-xs text-muted-foreground">@{event.host.username}</p>}
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
