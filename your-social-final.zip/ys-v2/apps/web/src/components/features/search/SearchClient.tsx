'use client';
import { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { Search, UserPlus, TrendingUp, Hash, Users, FileText } from 'lucide-react';
import { Avatar, Card, Skeleton, EmptyState, Badge } from '@/components/ui/index';
import { Button } from '@/components/ui/button';
import { searchAPI, friendAPI } from '@/lib/api';
import PostCard from '@/components/features/feed/PostCard';
import { formatNumber } from '@/lib/utils';
import toast from 'react-hot-toast';

const FILTERS = [
  { key: 'all', label: 'All' },
  { key: 'people', label: 'People', icon: Users },
  { key: 'posts', label: 'Posts', icon: FileText },
  { key: 'groups', label: 'Groups', icon: Users },
  { key: 'hashtags', label: 'Hashtags', icon: Hash },
];

export default function SearchClient() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const [query, setQuery] = useState(searchParams.get('q') || '');
  const [filter, setFilter] = useState('all');
  const [results, setResults] = useState<any>({});
  const [trending, setTrending] = useState<any>({ hashtags: [], posts: [] });
  const [loading, setLoading] = useState(false);
  const [addedFriends, setAddedFriends] = useState<Set<string>>(new Set());

  useEffect(() => {
    searchAPI.trending().then(r => setTrending(r.data)).catch(() => {});
  }, []);

  useEffect(() => {
    const q = searchParams.get('q') || '';
    setQuery(q);
    if (!q.trim()) return;
    setLoading(true);
    searchAPI.search(q, filter)
      .then(r => { setResults(r.data); setLoading(false); })
      .catch(() => setLoading(false));
  }, [searchParams.get('q'), filter]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) router.push(`/search?q=${encodeURIComponent(query)}`);
  };

  const addFriend = async (id: string) => {
    try {
      await friendAPI.send(id);
      setAddedFriends(prev => new Set([...prev, id]));
      toast.success('Friend request sent!');
    } catch { toast.error('Failed'); }
  };

  const hasResults = results.users?.length || results.posts?.length || results.groups?.length || results.hashtags?.length;
  const q = searchParams.get('q') || '';

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      {/* Search bar */}
      <form onSubmit={handleSearch} className="flex gap-2 mb-5">
        <div className="flex-1 flex items-center gap-2 bg-muted rounded-2xl px-4 h-11">
          <Search className="w-4 h-4 text-muted-foreground shrink-0" />
          <input
            className="bg-transparent text-sm w-full outline-none placeholder:text-muted-foreground"
            placeholder="Search YourSocial..."
            value={query}
            onChange={e => setQuery(e.target.value)}
          />
        </div>
        <Button type="submit" size="lg">Search</Button>
      </form>

      {/* Filters */}
      {q && (
        <div className="flex gap-2 mb-5 overflow-x-auto scrollbar-none pb-1">
          {FILTERS.map(f => (
            <button key={f.key} onClick={() => setFilter(f.key)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold whitespace-nowrap transition-colors shrink-0 ${filter === f.key ? 'bg-primary text-primary-foreground' : 'bg-secondary hover:bg-secondary/80'}`}>
              {f.icon && <f.icon className="w-3.5 h-3.5" />}
              {f.label}
            </button>
          ))}
        </div>
      )}

      {/* No query — show trending */}
      {!q && (
        <div className="space-y-6">
          {trending.hashtags?.length > 0 && (
            <section>
              <h2 className="text-base font-bold mb-3 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-primary" /> Trending Hashtags
              </h2>
              <div className="flex flex-wrap gap-2">
                {trending.hashtags.map((h: any) => (
                  <button key={h.id} onClick={() => { setQuery(`#${h.name}`); router.push(`/search?q=${encodeURIComponent('#'+h.name)}`); }}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-primary/10 text-primary rounded-full text-sm font-semibold hover:bg-primary/20 transition-colors">
                    <Hash className="w-3 h-3" />#{h.name}
                    <span className="text-xs text-primary/70">·{formatNumber(h.postCount)}</span>
                  </button>
                ))}
              </div>
            </section>
          )}
          <EmptyState icon="🔍" title="Search YourSocial" description="Find people, posts, groups, and hashtags." />
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16 rounded-2xl" />)}
        </div>
      )}

      {/* No results */}
      {!loading && q && !hasResults && (
        <EmptyState icon="🔍" title={`No results for "${q}"`} description="Try different keywords or check the spelling." />
      )}

      {/* Results */}
      {!loading && (
        <div className="space-y-6">
          {/* People */}
          {(filter === 'all' || filter === 'people') && results.users?.length > 0 && (
            <section>
              <h3 className="font-bold mb-3 flex items-center gap-2"><Users className="w-4 h-4" /> People</h3>
              <Card className="overflow-hidden divide-y divide-border">
                {results.users.map((u: any, i: number) => (
                  <motion.div key={u.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                    className="flex items-center gap-3 px-4 py-3 hover:bg-muted/50 transition-colors">
                    <button onClick={() => router.push(`/profile/${u.id}`)}>
                      <Avatar src={u.profilePicture} firstName={u.firstName} lastName={u.lastName} size="md" />
                    </button>
                    <div className="flex-1 min-w-0" onClick={() => router.push(`/profile/${u.id}`)} style={{ cursor: 'pointer' }}>
                      <div className="flex items-center gap-1.5">
                        <p className="font-semibold text-sm">{u.firstName} {u.lastName}</p>
                        {u.isVerified && <span className="text-blue-500 text-xs">✓</span>}
                      </div>
                      {u.username && <p className="text-xs text-muted-foreground">@{u.username}</p>}
                      {u.bio && <p className="text-xs text-muted-foreground truncate">{u.bio}</p>}
                    </div>
                    {addedFriends.has(u.id)
                      ? <Badge variant="success">Requested</Badge>
                      : <Button size="sm" variant="outline" onClick={() => addFriend(u.id)}><UserPlus className="w-3.5 h-3.5" /> Add</Button>
                    }
                  </motion.div>
                ))}
              </Card>
            </section>
          )}

          {/* Hashtags */}
          {(filter === 'all' || filter === 'hashtags') && results.hashtags?.length > 0 && (
            <section>
              <h3 className="font-bold mb-3 flex items-center gap-2"><Hash className="w-4 h-4" /> Hashtags</h3>
              <div className="flex flex-wrap gap-2">
                {results.hashtags.map((h: any) => (
                  <button key={h.id} onClick={() => router.push(`/search?q=${encodeURIComponent('#'+h.name)}`)}
                    className="flex items-center gap-1.5 px-3 py-2 bg-secondary rounded-xl text-sm font-semibold hover:bg-secondary/80 transition-colors">
                    <Hash className="w-3.5 h-3.5 text-primary" />#{h.name}
                    <span className="text-xs text-muted-foreground">{formatNumber(h.postCount)} posts</span>
                  </button>
                ))}
              </div>
            </section>
          )}

          {/* Groups */}
          {(filter === 'all' || filter === 'groups') && results.groups?.length > 0 && (
            <section>
              <h3 className="font-bold mb-3 flex items-center gap-2"><Users className="w-4 h-4" /> Groups</h3>
              <div className="space-y-2">
                {results.groups.map((g: any) => (
                  <Card key={g.id} className="flex items-center gap-3 p-3 cursor-pointer hover:bg-muted/50 transition-colors"
                    onClick={() => router.push(`/groups/${g.id}`)}>
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-400 to-violet-500 flex items-center justify-center text-white font-bold text-lg shrink-0">
                      {g.name[0]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm">{g.name}</p>
                      <p className="text-xs text-muted-foreground">{g._count?.members || 0} members · {g.privacy?.toLowerCase()}</p>
                    </div>
                    <Button size="sm" variant="outline">Join</Button>
                  </Card>
                ))}
              </div>
            </section>
          )}

          {/* Posts */}
          {(filter === 'all' || filter === 'posts') && results.posts?.length > 0 && (
            <section>
              <h3 className="font-bold mb-3 flex items-center gap-2"><FileText className="w-4 h-4" /> Posts</h3>
              {results.posts.map((p: any) => <PostCard key={p.id} post={p} />)}
            </section>
          )}
        </div>
      )}
    </div>
  );
}
