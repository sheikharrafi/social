'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { UserPlus, UserCheck, UserX, X } from 'lucide-react';
import { Avatar, Card, Skeleton, EmptyState } from '@/components/ui/index';
import { Button } from '@/components/ui/button';
import { friendAPI } from '@/lib/api';
import toast from 'react-hot-toast';

type Tab = 'suggestions' | 'requests' | 'sent';

export default function FriendsClient({ tab: initialTab }: { tab: Tab }) {
  const [tab, setTab] = useState<Tab>(initialTab);
  const [received, setReceived] = useState<any[]>([]);
  const [sent, setSent] = useState<any[]>([]);
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    setLoading(true);
    Promise.all([friendAPI.getRequests(), friendAPI.getSuggestions()])
      .then(([req, sug]) => {
        setReceived(req.data.received || []);
        setSent(req.data.sent || []);
        setSuggestions(sug.data.suggestions || []);
        setLoading(false);
      }).catch(() => setLoading(false));
  }, []);

  const accept = async (id: string) => {
    await friendAPI.accept(id);
    setReceived(p => p.filter(u => u.id !== id));
    toast.success('Friend request accepted!');
  };
  const decline = async (id: string) => { await friendAPI.decline(id); setReceived(p => p.filter(u => u.id !== id)); };
  const cancel = async (id: string) => { await friendAPI.cancel(id); setSent(p => p.filter(u => u.id !== id)); };
  const addFriend = async (id: string) => {
    await friendAPI.send(id);
    setSuggestions(p => p.filter(u => u.id !== id));
    toast.success('Friend request sent!');
  };
  const removeSug = (id: string) => setSuggestions(p => p.filter(u => u.id !== id));

  const TABS = [
    { key: 'suggestions', label: 'People You May Know' },
    { key: 'requests', label: 'Friend Requests', count: received.length },
    { key: 'sent', label: 'Sent Requests' },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-5">Friends</h1>

      <div className="flex gap-2 mb-6 flex-wrap">
        {TABS.map(t => (
          <button key={t.key} onClick={() => setTab(t.key as Tab)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${tab === t.key ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'}`}>
            {t.label}
            {t.count ? <span className="bg-destructive text-destructive-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center">{t.count}</span> : null}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-56 rounded-2xl" />)}
        </div>
      ) : (
        <>
          {tab === 'requests' && (
            received.length === 0
              ? <EmptyState icon="👋" title="No friend requests" description="When someone sends you a request, it'll appear here." />
              : <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {received.map((u, i) => (
                  <motion.div key={u.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                    <FriendCard user={u} onClick={() => router.push(`/profile/${u.id}`)}>
                      <Button size="sm" className="w-full mb-1" onClick={e => { e.stopPropagation(); accept(u.id); }}><UserCheck className="w-3.5 h-3.5" /> Confirm</Button>
                      <Button size="sm" variant="secondary" className="w-full" onClick={e => { e.stopPropagation(); decline(u.id); }}><X className="w-3.5 h-3.5" /> Delete</Button>
                    </FriendCard>
                  </motion.div>
                ))}
              </div>
          )}

          {tab === 'suggestions' && (
            suggestions.length === 0
              ? <EmptyState icon="🔍" title="No suggestions right now" description="We'll suggest people when we find matches." />
              : <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {suggestions.map((u, i) => (
                  <motion.div key={u.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                    <FriendCard user={u} onClick={() => router.push(`/profile/${u.id}`)}>
                      {u._count?.followers > 0 && <p className="text-xs text-muted-foreground text-center mb-1">{u._count.followers} mutual friends</p>}
                      <Button size="sm" className="w-full mb-1" onClick={e => { e.stopPropagation(); addFriend(u.id); }}><UserPlus className="w-3.5 h-3.5" /> Add Friend</Button>
                      <Button size="sm" variant="ghost" className="w-full" onClick={e => { e.stopPropagation(); removeSug(u.id); }}><X className="w-3.5 h-3.5" /> Remove</Button>
                    </FriendCard>
                  </motion.div>
                ))}
              </div>
          )}

          {tab === 'sent' && (
            sent.length === 0
              ? <EmptyState icon="📨" title="No sent requests" description="Friend requests you've sent will appear here." />
              : <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {sent.map((u, i) => (
                  <motion.div key={u.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                    <FriendCard user={u} onClick={() => router.push(`/profile/${u.id}`)}>
                      <Button size="sm" variant="secondary" className="w-full" onClick={e => { e.stopPropagation(); cancel(u.id); }}><UserX className="w-3.5 h-3.5" /> Cancel Request</Button>
                    </FriendCard>
                  </motion.div>
                ))}
              </div>
          )}
        </>
      )}
    </div>
  );
}

function FriendCard({ user, onClick, children }: any) {
  return (
    <Card className="overflow-hidden cursor-pointer hover:shadow-md transition-shadow" onClick={onClick}>
      <div className="h-20 bg-gradient-to-br from-primary/20 to-violet-500/20" />
      <div className="px-3 pb-3 -mt-8 flex flex-col items-center">
        <div className="w-16 h-16 rounded-full border-3 border-card overflow-hidden bg-muted mb-1.5">
          {user.profilePicture
            ? <img src={user.profilePicture} alt="" className="w-full h-full object-cover" />
            : <div className="w-full h-full bg-primary flex items-center justify-center text-white font-bold text-xl">{user.firstName?.[0]}</div>}
        </div>
        <p className="font-semibold text-sm text-center mb-1 truncate w-full text-center">{user.firstName} {user.lastName}</p>
        {children}
      </div>
    </Card>
  );
}
