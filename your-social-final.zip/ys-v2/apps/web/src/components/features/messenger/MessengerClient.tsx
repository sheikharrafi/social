'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import { useSearchParams } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Phone, Video, Info, Send, Paperclip, Smile, Image as ImageIcon, MoreVertical, Reply, Trash2, Edit2, Check, CheckCheck, X } from 'lucide-react';
import { Avatar, Spinner, EmptyState } from '@/components/ui/index';
import { Button } from '@/components/ui/button';
import { messageAPI, uploadAPI } from '@/lib/api';
import { useSocket } from '@/lib/socket';
import useAuthStore from '@/store/auth.store';
import { formatDate } from '@/lib/utils';
import toast from 'react-hot-toast';

export default function MessengerClient() {
  const { user } = useAuthStore();
  const { socket, isOnline } = useSocket();
  const searchParams = useSearchParams();
  const [conversations, setConversations] = useState<any[]>([]);
  const [active, setActive] = useState<any>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const [search, setSearch] = useState('');
  const [replyTo, setReplyTo] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const typingTimer = useRef<ReturnType<typeof setTimeout>>();
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => { messageAPI.getConversations().then(r => setConversations(r.data.conversations || [])).catch(() => {}); }, []);

  useEffect(() => {
    const uid = searchParams.get('userId');
    if (uid) messageAPI.getOrCreate(uid).then(r => openConv(r.data.conversation)).catch(() => {});
  }, [searchParams]);

  const openConv = useCallback(async (conv: any) => {
    setActive(conv);
    setMessages([]);
    setLoading(true);
    try {
      const { data } = await messageAPI.getMessages(conv.id);
      setMessages(data.messages || []);
      messageAPI.markSeen(conv.id).catch(() => {});
    } catch {}
    setLoading(false);
    socket?.emit('join_conversation', conv.id);
  }, [socket]);

  useEffect(() => {
    if (!socket) return;
    socket.on('new_message', ({ conversationId, message }: any) => {
      if (active?.id === conversationId) {
        setMessages(p => [...p, message]);
        messageAPI.markSeen(conversationId).catch(() => {});
      }
      setConversations(p => p.map(c => c.id === conversationId ? { ...c, lastMessage: message, updatedAt: new Date() } : c).sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()));
    });
    socket.on('typing_start', ({ userId: uid }: any) => { if (uid !== user?.id) setTyping(true); });
    socket.on('typing_stop', ({ userId: uid }: any) => { if (uid !== user?.id) setTyping(false); });
    return () => { socket.off('new_message'); socket.off('typing_start'); socket.off('typing_stop'); };
  }, [socket, active, user?.id]);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const handleInput = (val: string) => {
    setInput(val);
    if (!socket || !active) return;
    socket.emit('typing_start', { conversationId: active.id, userId: user?.id });
    clearTimeout(typingTimer.current);
    typingTimer.current = setTimeout(() => socket.emit('typing_stop', { conversationId: active.id, userId: user?.id }), 1500);
  };

  const sendMsg = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || !active) return;
    const text = input.trim(); setInput(''); setReplyTo(null);
    const temp = { id: Date.now().toString(), senderId: user?.id, content: text, type: 'TEXT', createdAt: new Date(), sender: user };
    setMessages(p => [...p, temp]);
    try {
      const { data } = await messageAPI.send(active.id, { content: text, replyToId: replyTo?.id });
      setMessages(p => p.map(m => m.id === temp.id ? data.message : m));
    } catch { setMessages(p => p.filter(m => m.id !== temp.id)); toast.error('Failed'); }
  };

  const sendFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file || !active) return;
    const fd = new FormData(); fd.append('file', file);
    try {
      const { data } = await messageAPI.send(active.id, fd);
      setMessages(p => [...p, data.message]);
    } catch { toast.error('Failed to upload'); }
    e.target.value = '';
  };

  const deleteMsg = async (id: string) => {
    try { await messageAPI.delete(id, true); setMessages(p => p.map(m => m.id === id ? { ...m, isDeleted: true, content: null } : m)); } catch {}
  };

  const getOther = (conv: any) => conv.members?.find((m: any) => m.user?.id !== user?.id)?.user;
  const filtered = conversations.filter(c => {
    if (!search) return true;
    const other = getOther(c);
    return other ? `${other.firstName} ${other.lastName}`.toLowerCase().includes(search.toLowerCase()) : false;
  });

  const other = active ? getOther(active) : null;

  return (
    <div className="flex h-[calc(100vh-56px)] bg-background">
      {/* Sidebar */}
      <div className={`${active ? 'hidden md:flex' : 'flex'} flex-col w-full md:w-80 border-r border-border flex-shrink-0`}>
        <div className="p-4 pb-3">
          <h2 className="text-xl font-bold mb-3">Messages</h2>
          <div className="flex items-center gap-2 bg-muted rounded-xl px-3 h-9">
            <Search className="w-4 h-4 text-muted-foreground shrink-0" />
            <input className="bg-transparent text-sm w-full outline-none placeholder:text-muted-foreground" placeholder="Search..." value={search} onChange={e => setSearch(e.target.value)} />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {filtered.map(c => {
            const oth = getOther(c);
            const name = c.isGroup ? c.groupName : oth ? `${oth.firstName} ${oth.lastName}` : 'Chat';
            const isActive = active?.id === c.id;
            return (
              <button key={c.id} onClick={() => openConv(c)}
                className={`flex items-center gap-3 w-full px-4 py-3 transition-colors text-left ${isActive ? 'bg-primary/10' : 'hover:bg-muted'}`}>
                <Avatar src={oth?.profilePicture} firstName={oth?.firstName || ''} lastName={oth?.lastName || ''} size="md" online={oth ? isOnline(oth.id) : false} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="font-semibold text-sm truncate">{name}</p>
                    {c.lastMessage && <p className="text-xs text-muted-foreground">{formatDate(c.lastMessage.createdAt)}</p>}
                  </div>
                  <p className="text-xs text-muted-foreground truncate">
                    {c.lastMessage?.isDeleted ? <em>Deleted</em> : c.lastMessage?.content || c.lastMessage?.type || 'No messages'}
                  </p>
                </div>
              </button>
            );
          })}
          {filtered.length === 0 && <p className="text-sm text-muted-foreground text-center py-8">No conversations yet</p>}
        </div>
      </div>

      {/* Chat area */}
      {active ? (
        <div className={`flex flex-col flex-1 min-w-0 ${active ? 'flex' : 'hidden md:flex'}`}>
          {/* Header */}
          <div className="flex items-center gap-3 px-4 py-3 border-b border-border bg-background">
            <button className="md:hidden mr-1" onClick={() => setActive(null)}><X className="w-5 h-5" /></button>
            <Avatar src={other?.profilePicture} firstName={other?.firstName} lastName={other?.lastName} size="md" online={other ? isOnline(other.id) : false} />
            <div className="flex-1">
              <p className="font-semibold text-sm">{other ? `${other.firstName} ${other.lastName}` : active.groupName}</p>
              <p className="text-xs text-muted-foreground">{other && (isOnline(other.id) ? 'Active now' : 'Offline')}</p>
            </div>
            <div className="flex gap-1">
              <Button variant="ghost" size="icon-sm"><Phone className="w-4 h-4" /></Button>
              <Button variant="ghost" size="icon-sm"><Video className="w-4 h-4" /></Button>
              <Button variant="ghost" size="icon-sm"><Info className="w-4 h-4" /></Button>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-1">
            {loading && <Spinner className="mx-auto" />}
            {messages.map((msg, i) => {
              const isOwn = msg.senderId === user?.id || msg.sender?.id === user?.id;
              const showAvatar = !isOwn && (i === 0 || messages[i-1]?.senderId !== msg.senderId);
              return (
                <MsgBubble key={msg.id} msg={msg} isOwn={isOwn} showAvatar={showAvatar}
                  senderPic={msg.sender?.profilePicture} senderName={msg.sender ? `${msg.sender.firstName} ${msg.sender.lastName}` : ''}
                  onReply={() => setReplyTo(msg)} onDelete={() => deleteMsg(msg.id)} />
              );
            })}
            {typing && (
              <div className="flex items-end gap-2">
                <Avatar src={other?.profilePicture} firstName={other?.firstName} lastName={other?.lastName} size="xs" />
                <div className="bg-muted rounded-2xl px-4 py-3 flex gap-1.5">
                  {[0,1,2].map(i => <motion.div key={i} className="w-2 h-2 bg-muted-foreground rounded-full" animate={{ y: [0,-6,0] }} transition={{ repeat: Infinity, duration: 1.2, delay: i*0.2 }} />)}
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Reply preview */}
          {replyTo && (
            <div className="mx-4 mb-1 flex items-center gap-2 bg-muted rounded-xl px-3 py-2 border-l-4 border-primary">
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-primary">{replyTo.sender?.firstName || 'You'}</p>
                <p className="text-xs text-muted-foreground truncate">{replyTo.content}</p>
              </div>
              <button onClick={() => setReplyTo(null)}><X className="w-4 h-4 text-muted-foreground" /></button>
            </div>
          )}

          {/* Input */}
          <form onSubmit={sendMsg} className="flex items-center gap-2 px-4 py-3 border-t border-border">
            <button type="button" onClick={() => fileRef.current?.click()} className="text-primary shrink-0"><Paperclip className="w-5 h-5" /></button>
            <button type="button" onClick={() => fileRef.current?.click()} className="text-emerald-500 shrink-0"><ImageIcon className="w-5 h-5" /></button>
            <input ref={fileRef} type="file" className="hidden" onChange={sendFile} />
            <div className="flex-1 flex items-center bg-muted rounded-full px-4 h-10 gap-2">
              <input className="bg-transparent text-sm flex-1 outline-none placeholder:text-muted-foreground"
                placeholder="Aa" value={input} onChange={e => handleInput(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMsg(); } }} />
              <button type="button" className="text-amber-500 shrink-0"><Smile className="w-4 h-4" /></button>
            </div>
            {input.trim() ? (
              <button type="submit" className="w-10 h-10 rounded-full gradient-brand flex items-center justify-center text-white shrink-0"><Send className="w-4 h-4" /></button>
            ) : (
              <button type="button" className="w-10 h-10 rounded-full gradient-brand flex items-center justify-center text-white shrink-0"
                onClick={() => active && messageAPI.send(active.id, { content: '👍' }).then(r => setMessages(p => [...p, r.data.message])).catch(() => {})}>
                👍
              </button>
            )}
          </form>
        </div>
      ) : (
        <div className="hidden md:flex flex-1 items-center justify-center">
          <EmptyState icon="💬" title="Your Messages" description="Send a message to start a conversation." />
        </div>
      )}
    </div>
  );
}

function MsgBubble({ msg, isOwn, showAvatar, senderPic, senderName, onReply, onDelete }: any) {
  const [hover, setHover] = useState(false);
  return (
    <div className={`flex items-end gap-2 group ${isOwn ? 'flex-row-reverse' : ''}`}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}>
      <div className="w-7 shrink-0">
        {showAvatar && !isOwn && <Avatar src={senderPic} firstName={senderName.split(' ')[0]} lastName={senderName.split(' ')[1]} size="xs" />}
      </div>
      <div className={`flex flex-col ${isOwn ? 'items-end' : 'items-start'} max-w-[65%]`}>
        {msg.replyTo && (
          <div className={`text-xs px-3 py-1.5 rounded-xl mb-1 border-l-2 border-primary bg-muted max-w-full ${isOwn ? 'text-right' : ''}`}>
            <p className="font-semibold text-primary">{msg.replyTo.sender?.firstName}</p>
            <p className="text-muted-foreground truncate">{msg.replyTo.content}</p>
          </div>
        )}
        <div className={`px-3 py-2 rounded-2xl text-sm ${isOwn ? 'bg-primary text-white rounded-br-sm' : 'bg-muted rounded-bl-sm'}`}>
          {msg.isDeleted ? <em className="opacity-60">Message deleted</em>
            : msg.type === 'IMAGE' ? <img src={msg.mediaUrl} alt="" className="rounded-xl max-w-[220px]" />
            : msg.type === 'VIDEO' ? <video src={msg.mediaUrl} controls className="rounded-xl max-w-[220px]" />
            : msg.type === 'AUDIO' ? <audio src={msg.mediaUrl} controls className="max-w-[220px]" />
            : msg.content}
        </div>
        <p className="text-[10px] text-muted-foreground mt-0.5 px-1">{formatDate(msg.createdAt)}</p>
      </div>
      {hover && !msg.isDeleted && (
        <div className={`flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity ${isOwn ? 'flex-row-reverse' : ''}`}>
          <button onClick={onReply} className="w-7 h-7 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80"><Reply className="w-3 h-3" /></button>
          {isOwn && <button onClick={onDelete} className="w-7 h-7 rounded-full bg-muted flex items-center justify-center hover:bg-destructive/20 text-destructive"><Trash2 className="w-3 h-3" /></button>}
        </div>
      )}
    </div>
  );
}
