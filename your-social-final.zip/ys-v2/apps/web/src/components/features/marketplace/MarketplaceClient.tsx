'use client';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Plus, MapPin, Tag, X, Heart } from 'lucide-react';
import { Avatar, Card, Skeleton, EmptyState } from '@/components/ui/index';
import { Button } from '@/components/ui/button';
import { marketAPI, uploadAPI } from '@/lib/api';
import { formatDate } from '@/lib/utils';
import toast from 'react-hot-toast';

const CATS = ['','Electronics','Clothing','Furniture','Vehicles','Home & Garden','Toys & Games','Books','Sports','Collectibles','Free Stuff','Other'];
const CONDS = ['New','Like New','Good','Fair','Poor'];

export default function MarketplaceClient() {
  const [listings, setListings] = useState<any[]>([]);
  const [selected, setSelected] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [myListings, setMyListings] = useState<any[]>([]);
  const [tab, setTab] = useState<'browse'|'selling'>('browse');

  useEffect(() => { fetch_listings(); }, [search, category]);
  useEffect(() => { if (tab === 'selling') marketAPI.getMy().then(r => setMyListings(r.data.listings || [])).catch(() => {}); }, [tab]);

  const fetch_listings = async () => {
    setLoading(true);
    try { const { data } = await marketAPI.getAll({ search: search || undefined, category: category || undefined }); setListings(data.listings || []); }
    catch {}
    setLoading(false);
  };

  return (
    <div className="flex h-[calc(100vh-56px)]">
      {/* Left panel */}
      <div className={`${selected ? 'hidden md:flex' : 'flex'} flex-col w-full md:w-80 border-r border-border flex-shrink-0 overflow-y-auto`}>
        <div className="p-4 space-y-2">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold">Marketplace</h2>
            <Button size="sm" onClick={() => setShowCreate(true)}><Plus className="w-3.5 h-3.5" /> Sell</Button>
          </div>
          <div className="flex items-center gap-2 bg-muted rounded-xl px-3 h-9">
            <Search className="w-4 h-4 text-muted-foreground shrink-0" />
            <input className="bg-transparent text-sm w-full outline-none" placeholder="Search listings..." value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <div className="flex gap-2">
            {['browse','selling'].map(t => (
              <button key={t} onClick={() => setTab(t as any)}
                className={`flex-1 py-1.5 rounded-lg text-xs font-semibold capitalize transition-colors ${tab === t ? 'bg-primary text-primary-foreground' : 'bg-secondary hover:bg-secondary/80'}`}>{t}</button>
            ))}
          </div>
          {tab === 'browse' && (
            <select className="w-full h-9 rounded-xl border border-input bg-background px-2 text-sm outline-none" value={category} onChange={e => setCategory(e.target.value)}>
              <option value="">All Categories</option>
              {CATS.filter(Boolean).map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          )}
        </div>

        <div className="flex-1 overflow-y-auto px-3 pb-3 space-y-2">
          {tab === 'browse' && (loading
            ? Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-xl" />)
            : listings.map(l => (
              <button key={l.id} onClick={() => setSelected(l)}
                className={`flex items-center gap-3 w-full p-2 rounded-xl text-left transition-colors ${selected?.id === l.id ? 'bg-primary/10' : 'hover:bg-muted'}`}>
                <div className="w-16 h-16 rounded-lg bg-muted overflow-hidden shrink-0">
                  {l.images?.[0] && <img src={l.images[0].url} alt="" className="w-full h-full object-cover" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-sm">৳{Number(l.price).toLocaleString()}</p>
                  <p className="text-xs text-muted-foreground truncate">{l.title}</p>
                  {l.location && <p className="text-xs text-muted-foreground flex items-center gap-1"><MapPin className="w-3 h-3" />{l.location}</p>}
                </div>
              </button>
            ))
          )}
          {tab === 'selling' && myListings.map(l => (
            <div key={l.id} className="flex items-center gap-3 p-2 border border-border rounded-xl">
              <div className="w-14 h-14 rounded-lg bg-muted overflow-hidden shrink-0">
                {l.images?.[0] && <img src={l.images[0].url} alt="" className="w-full h-full object-cover" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-bold text-sm">৳{Number(l.price).toLocaleString()}</p>
                <p className="text-xs text-muted-foreground truncate">{l.title}</p>
                <span className={`text-xs font-semibold ${l.status === 'ACTIVE' ? 'text-emerald-500' : 'text-muted-foreground'}`}>{l.status}</span>
              </div>
              <button onClick={() => marketAPI.delete(l.id).then(() => setMyListings(p => p.filter(x => x.id !== l.id)))} className="text-muted-foreground hover:text-destructive"><X className="w-4 h-4" /></button>
            </div>
          ))}
        </div>
      </div>

      {/* Detail */}
      <div className="flex-1 overflow-y-auto p-4">
        {selected ? (
          <ListingDetail listing={selected} onClose={() => setSelected(null)} />
        ) : (
          <div className="h-full flex items-center justify-center">
            <EmptyState icon="🛒" title="Browse Listings" description="Select a listing to see details." />
          </div>
        )}
      </div>

      {showCreate && <CreateListingModal onClose={() => setShowCreate(false)} onCreate={l => { setListings(p => [l, ...p]); setShowCreate(false); setSelected(l); }} />}
    </div>
  );
}

function ListingDetail({ listing, onClose }: any) {
  const [imgIdx, setImgIdx] = useState(0);
  return (
    <div className="max-w-2xl">
      <button onClick={onClose} className="md:hidden mb-3 flex items-center gap-1 text-sm text-muted-foreground"><X className="w-4 h-4" /> Back</button>
      {listing.images?.length > 0 && (
        <div className="mb-4 rounded-2xl overflow-hidden">
          <img src={listing.images[imgIdx]?.url} alt="" className="w-full max-h-96 object-cover" />
          {listing.images.length > 1 && (
            <div className="flex gap-2 p-2 flex-wrap">
              {listing.images.map((img: any, i: number) => (
                <img key={i} src={img.url} alt="" onClick={() => setImgIdx(i)} className={`w-16 h-16 object-cover rounded-lg cursor-pointer border-2 ${i === imgIdx ? 'border-primary' : 'border-transparent'}`} />
              ))}
            </div>
          )}
        </div>
      )}
      <Card className="p-5">
        <div className="flex items-start justify-between mb-3">
          <div>
            <p className="text-3xl font-black">৳{Number(listing.price).toLocaleString()}{listing.negotiable && <span className="text-base font-normal text-muted-foreground ml-2">(Negotiable)</span>}</p>
            <h2 className="text-xl font-bold mt-1">{listing.title}</h2>
          </div>
          <button className="text-muted-foreground hover:text-rose-500"><Heart className="w-5 h-5" /></button>
        </div>
        <div className="flex gap-2 flex-wrap mb-3">
          <span className="flex items-center gap-1 text-xs bg-secondary rounded-full px-3 py-1"><Tag className="w-3 h-3" />{listing.category}</span>
          <span className="text-xs bg-secondary rounded-full px-3 py-1">{listing.condition}</span>
          {listing.location && <span className="flex items-center gap-1 text-xs bg-secondary rounded-full px-3 py-1"><MapPin className="w-3 h-3" />{listing.location}</span>}
        </div>
        {listing.description && <p className="text-sm text-muted-foreground mb-4 leading-relaxed">{listing.description}</p>}
        <div className="flex items-center gap-3 pt-3 border-t border-border mb-4">
          <Avatar src={listing.seller?.profilePicture} firstName={listing.seller?.firstName} lastName={listing.seller?.lastName} size="md" />
          <div>
            <p className="font-semibold text-sm">{listing.seller?.firstName} {listing.seller?.lastName}</p>
            <p className="text-xs text-muted-foreground">Listed {formatDate(listing.createdAt)}</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button className="flex-1">Message Seller</Button>
          <Button variant="outline" className="flex-1"><Heart className="w-4 h-4" /> Save</Button>
        </div>
      </Card>
    </div>
  );
}

function CreateListingModal({ onClose, onCreate }: any) {
  const [form, setForm] = useState({ title: '', description: '', price: '', category: 'Other', condition: 'Good', location: '', negotiable: false });
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const addFiles = (picked: FileList | null) => {
    if (!picked) return;
    const arr = Array.from(picked); setFiles(p => [...p, ...arr]);
    arr.forEach(f => { const r = new FileReader(); r.onload = e => setPreviews(p => [...p, e.target?.result as string]); r.readAsDataURL(f); });
  };
  const create = async () => {
    if (!form.title.trim() || !form.price) return toast.error('Title and price required');
    setLoading(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => fd.append(k, String(v)));
      files.forEach(f => fd.append('files', f));
      const { data } = await marketAPI.create(fd);
      onCreate(data.listing); toast.success('Listing published!');
    } catch { toast.error('Failed to create listing'); }
    setLoading(false);
  };
  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4" onClick={e => e.target === e.currentTarget && onClose()}>
      <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="bg-card rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-border shrink-0">
          <div /><h3 className="font-bold">Create Listing</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-muted flex items-center justify-center"><X className="w-4 h-4" /></button>
        </div>
        <div className="overflow-y-auto flex-1 p-4 space-y-3">
          <label className="flex flex-col items-center justify-center h-24 border-2 border-dashed border-border rounded-xl cursor-pointer hover:bg-muted transition-colors">
            <span className="text-2xl mb-1">📷</span><span className="text-sm text-muted-foreground">Add photos</span>
            <input type="file" multiple accept="image/*" className="hidden" onChange={e => addFiles(e.target.files)} />
          </label>
          {previews.length > 0 && <div className="flex gap-2 flex-wrap">{previews.map((p, i) => <div key={i} className="relative"><img src={p} alt="" className="w-16 h-16 object-cover rounded-lg" /><button onClick={() => { setFiles(a => a.filter((_,j) => j !== i)); setPreviews(a => a.filter((_,j) => j !== i)); }} className="absolute -top-1 -right-1 w-4 h-4 bg-destructive text-white rounded-full flex items-center justify-center text-[10px]">✕</button></div>)}</div>}
          <input className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring" placeholder="Title *" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} />
          <input className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring" placeholder="Price (৳) *" type="number" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} />
          <div className="grid grid-cols-2 gap-2">
            <select className="h-10 rounded-xl border border-input bg-background px-2 text-sm outline-none" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
              {CATS.filter(Boolean).map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <select className="h-10 rounded-xl border border-input bg-background px-2 text-sm outline-none" value={form.condition} onChange={e => setForm(f => ({ ...f, condition: e.target.value }))}>
              {CONDS.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <textarea className="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring resize-none" rows={3} placeholder="Description" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
          <input className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring" placeholder="Location" value={form.location} onChange={e => setForm(f => ({ ...f, location: e.target.value }))} />
          <label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={form.negotiable} onChange={e => setForm(f => ({ ...f, negotiable: e.target.checked }))} className="rounded accent-primary w-4 h-4" /><span className="text-sm font-medium">Price is negotiable</span></label>
        </div>
        <div className="p-4 border-t border-border shrink-0">
          <Button className="w-full" onClick={create} loading={loading}>Publish Listing</Button>
        </div>
      </motion.div>
    </div>
  );
}
