'use client';
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Heart, Share2, Archive } from 'lucide-react';
import { Card, EmptyState, Skeleton } from '@/components/ui/index';
import { Button } from '@/components/ui/button';
import { postAPI } from '@/lib/api';
import PostCard from '@/components/features/feed/PostCard';
import { format, subYears } from 'date-fns';
import useAuthStore from '@/store/auth.store';

export default function MemoriesClient() {
  const { user } = useAuthStore();
  const [memories, setMemories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const today = new Date();

  useEffect(() => {
    if (!user) return;
    // Fetch user's past posts on this day
    postAPI.getUserPosts(user.id)
      .then(r => {
        const posts = r.data.posts || [];
        // Filter posts from previous years on same day/month
        const todayMemories = posts.filter((p: any) => {
          const d = new Date(p.createdAt);
          return (
            d.getMonth() === today.getMonth() &&
            d.getDate() === today.getDate() &&
            d.getFullYear() < today.getFullYear()
          );
        });
        setMemories(todayMemories);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [user]);

  const years = [...new Set(memories.map(m => new Date(m.createdAt).getFullYear()))].sort((a, b) => b - a);

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8">
        <div className="w-20 h-20 rounded-full gradient-brand flex items-center justify-center text-4xl mx-auto mb-4 shadow-lg">
          🌸
        </div>
        <h1 className="text-2xl font-black mb-1">Memories</h1>
        <p className="text-muted-foreground text-sm">
          On This Day — <span className="font-semibold text-foreground">{format(today, 'MMMM d')}</span>
        </p>
      </motion.div>

      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-48 rounded-2xl" />)}
        </div>
      ) : memories.length === 0 ? (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          <Card className="p-8 text-center">
            <div className="text-5xl mb-4">📸</div>
            <h3 className="text-lg font-bold mb-2">No memories yet</h3>
            <p className="text-muted-foreground text-sm">
              Post something today — next year it will show up here as a memory!
            </p>
          </Card>
        </motion.div>
      ) : (
        <div className="space-y-8">
          {years.map(year => {
            const yearPosts = memories.filter(m => new Date(m.createdAt).getFullYear() === year);
            const yearsAgo = today.getFullYear() - year;
            return (
              <motion.div key={year} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                <div className="flex items-center gap-3 mb-3">
                  <div className="flex-1 h-px bg-border" />
                  <div className="flex items-center gap-2 bg-card border border-border rounded-full px-4 py-1.5 shadow-sm">
                    <span className="text-lg">🕐</span>
                    <span className="text-sm font-bold">
                      {yearsAgo} {yearsAgo === 1 ? 'year' : 'years'} ago · {year}
                    </span>
                  </div>
                  <div className="flex-1 h-px bg-border" />
                </div>
                {yearPosts.map(post => (
                  <div key={post.id} className="relative">
                    <div className="absolute -top-2 -right-2 z-10">
                      <div className="bg-gradient-to-r from-rose-400 to-pink-500 text-white text-xs font-bold px-2 py-0.5 rounded-full shadow">
                        {year}
                      </div>
                    </div>
                    <PostCard post={post} />
                  </div>
                ))}
                <div className="flex gap-2 mt-3">
                  <Button variant="secondary" size="sm" className="flex-1">
                    <Heart className="w-3.5 h-3.5" /> React
                  </Button>
                  <Button variant="secondary" size="sm" className="flex-1">
                    <Share2 className="w-3.5 h-3.5" /> Share Memory
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Archive className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Fun stats */}
      {!loading && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card className="p-4 mt-6 bg-gradient-to-r from-primary/5 to-violet-500/5 border-primary/20">
            <h3 className="font-bold mb-3">Your Year in Posts</h3>
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="bg-background rounded-xl p-3">
                <p className="text-2xl font-black text-primary">{memories.length}</p>
                <p className="text-xs text-muted-foreground">Total Memories</p>
              </div>
              <div className="bg-background rounded-xl p-3">
                <p className="text-2xl font-black text-rose-500">
                  {memories.reduce((sum, m) => sum + (m.reactions?.length || 0), 0)}
                </p>
                <p className="text-xs text-muted-foreground">Total Reactions</p>
              </div>
              <div className="bg-background rounded-xl p-3">
                <p className="text-2xl font-black text-violet-500">
                  {memories.reduce((sum, m) => sum + (m._count?.comments || 0), 0)}
                </p>
                <p className="text-xs text-muted-foreground">Total Comments</p>
              </div>
            </div>
          </Card>
        </motion.div>
      )}
    </div>
  );
}
