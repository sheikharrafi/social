'use client';
import { useState, useEffect } from 'react';
import { Globe, Lock, Users } from 'lucide-react';
import { Avatar, Card, Spinner, Skeleton } from '@/components/ui/index';
import { Button } from '@/components/ui/button';
import { groupAPI } from '@/lib/api';
import useAuthStore from '@/store/auth.store';
import PostCard from '@/components/features/feed/PostCard';
import CreatePost from '@/components/features/feed/CreatePost';
import toast from 'react-hot-toast';

export default function GroupDetailClient({ groupId }: { groupId: string }) {
  const { user } = useAuthStore();
  const [group, setGroup] = useState<any>(null);
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [joining, setJoining] = useState(false);

  useEffect(() => {
    Promise.all([groupAPI.get(groupId), groupAPI.getPosts(groupId)])
      .then(([g, p]) => { setGroup(g.data); setPosts(p.data.posts || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, [groupId]);

  const join = async () => {
    setJoining(true);
    try { await groupAPI.join(groupId); setGroup((g: any) => ({ ...g, isMember: true })); toast.success('Joined!'); }
    catch { toast.error('Failed to join'); }
    setJoining(false);
  };
  const leave = async () => {
    if (!confirm('Leave this group?')) return;
    try { await groupAPI.leave(groupId); setGroup((g: any) => ({ ...g, isMember: false })); toast.success('Left group'); }
    catch {}
  };

  if (loading) return <div className="max-w-4xl mx-auto px-4 py-6"><Skeleton className="h-48 w-full rounded-2xl mb-4" /><Skeleton className="h-8 w-64 mb-2" /><Skeleton className="h-5 w-32" /></div>;
  if (!group) return <div className="text-center py-20 text-muted-foreground">Group not found</div>;

  const isMember = group.isMember;
  const isAdmin = group.myRole === 'ADMIN';

  return (
    <div className="pb-10">
      <div className="relative h-48 md:h-64 bg-gradient-to-br from-blue-500/40 to-violet-500/40 overflow-hidden">
        {group.group?.coverPhoto && <img src={group.group.coverPhoto} alt="" className="w-full h-full object-cover" />}
      </div>

      <div className="max-w-4xl mx-auto px-4">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 py-4 border-b border-border">
          <div>
            <h1 className="text-2xl font-black">{group.group?.name}</h1>
            <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
              {group.group?.privacy === 'PRIVATE' ? <Lock className="w-3.5 h-3.5" /> : <Globe className="w-3.5 h-3.5" />}
              <span className="capitalize">{group.group?.privacy?.toLowerCase()}</span>
              <span>·</span>
              <Users className="w-3.5 h-3.5" />
              <span>{group.group?._count?.members || 0} members</span>
            </div>
          </div>
          <div className="flex gap-2">
            {isMember ? (
              <Button variant="secondary" onClick={leave}>Leave Group</Button>
            ) : (
              <Button onClick={join} loading={joining}><Users className="w-4 h-4" /> Join Group</Button>
            )}
          </div>
        </div>

        <div className="flex gap-6 mt-4">
          <div className="hidden md:block w-72 shrink-0 space-y-3">
            <Card className="p-4">
              <h3 className="font-bold mb-2">About</h3>
              {group.group?.description && <p className="text-sm text-muted-foreground">{group.group.description}</p>}
            </Card>
            <Card className="p-4">
              <h3 className="font-bold mb-3">Members ({group.group?._count?.members || 0})</h3>
              {(group.group?.members || []).map((m: any) => (
                <div key={m.user?.id} className="flex items-center gap-2 mb-2">
                  <Avatar src={m.user?.profilePicture} firstName={m.user?.firstName} lastName={m.user?.lastName} size="sm" />
                  <span className="text-sm font-medium">{m.user?.firstName} {m.user?.lastName}</span>
                </div>
              ))}
            </Card>
          </div>

          <div className="flex-1 min-w-0 space-y-3">
            {isMember && <CreatePost onCreated={p => setPosts(prev => [p, ...prev])} />}
            {posts.map(p => <PostCard key={p.id} post={p} onDelete={id => setPosts(prev => prev.filter(x => x.id !== id))} />)}
            {posts.length === 0 && <div className="text-center py-12 text-muted-foreground">No posts in this group yet.</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
