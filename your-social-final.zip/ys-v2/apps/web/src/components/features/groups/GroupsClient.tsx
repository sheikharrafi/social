'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { Plus, Lock, Globe, Users, X } from 'lucide-react';
import { Card, Skeleton, EmptyState } from '@/components/ui/index';
import { Button } from '@/components/ui/button';
import { groupAPI } from '@/lib/api';
import toast from 'react-hot-toast';

export default function GroupsClient() {
  const [myGroups, setMyGroups] = useState<any[]>([]);
  const [discover, setDiscover] = useState<any[]>([]);
  const [tab, setTab] = useState<'my' | 'discover'>('my');
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const router = useRouter();

  useEffect(() => {
    Promise.all([groupAPI.getMy(), groupAPI.discover()])
      .then(([my, disc]) => { setMyGroups(my.data.groups || []); setDiscover(disc.data.groups || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const list = tab === 'my' ? myGroups : discover;

  return (
    <div className="max-w-5xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-2xl font-bold">Groups</h1>
        <Button onClick={() => setShowCreate(true)}><Plus className="w-4 h-4" /> Create Group</Button>
      </div>

      <div className="flex gap-2 mb-5">
        <button onClick={() => setTab('my')} className={`px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${tab === 'my' ? 'bg-primary text-primary-foreground' : 'bg-secondary hover:bg-secondary/80'}`}>Your Groups</button>
        <button onClick={() => setTab('discover')} className={`px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${tab === 'discover' ? 'bg-primary text-primary-foreground' : 'bg-secondary hover:bg-secondary/80'}`}>Discover</button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-52 rounded-2xl" />)}
        </div>
      ) : list.length === 0 ? (
        <EmptyState icon="👥" title={tab === 'my' ? "No groups yet" : "No groups to discover"}
          description={tab === 'my' ? "Create or join a group to get started." : "Check back later for new groups."}
          action={tab === 'my' ? <Button onClick={() => setShowCreate(true)}><Plus className="w-4 h-4" /> Create Group</Button> : undefined} />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {list.map((g, i) => (
            <motion.div key={g.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <Card className="overflow-hidden cursor-pointer hover:shadow-md transition-shadow" onClick={() => router.push(`/groups/${g.id}`)}>
                <div className="h-32 bg-gradient-to-br from-blue-500/30 to-violet-500/30 overflow-hidden">
                  {g.coverPhoto ? <img src={g.coverPhoto} alt="" className="w-full h-full object-cover" /> :
                    <div className="w-full h-full flex items-center justify-center text-4xl font-black text-white/60">{g.name[0]}</div>}
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-sm mb-1 truncate">{g.name}</h3>
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    {g.privacy === 'PRIVATE' ? <Lock className="w-3 h-3" /> : <Globe className="w-3 h-3" />}
                    <span className="capitalize">{g.privacy?.toLowerCase()}</span>
                    <span>·</span>
                    <Users className="w-3 h-3" />
                    <span>{g._count?.members || 0} members</span>
                  </div>
                  {tab === 'discover' && (
                    <Button size="sm" className="w-full mt-3" onClick={e => { e.stopPropagation(); groupAPI.join(g.id).then(() => toast.success('Joined!')).catch(() => {}); }}>
                      Join Group
                    </Button>
                  )}
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {showCreate && <CreateGroupModal onClose={() => setShowCreate(false)} onCreate={g => { setMyGroups(p => [g, ...p]); setShowCreate(false); router.push(`/groups/${g.id}`); }} />}
    </div>
  );
}

function CreateGroupModal({ onClose, onCreate }: any) {
  const [form, setForm] = useState({ name: '', description: '', privacy: 'PUBLIC', category: 'General' });
  const [loading, setLoading] = useState(false);

  const create = async () => {
    if (!form.name.trim()) return toast.error('Name is required');
    setLoading(true);
    try { const { data } = await groupAPI.create(form); toast.success('Group created!'); onCreate(data.group); }
    catch { toast.error('Failed to create group'); }
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4" onClick={e => e.target === e.currentTarget && onClose()}>
      <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="bg-card rounded-2xl w-full max-w-md shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div /><h3 className="font-bold">Create Group</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-muted flex items-center justify-center"><X className="w-4 h-4" /></button>
        </div>
        <div className="p-4 space-y-3">
          <div><label className="text-xs font-medium text-muted-foreground mb-1 block">Group name *</label>
            <input className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="e.g. Photography Lovers" /></div>
          <div><label className="text-xs font-medium text-muted-foreground mb-1 block">Description</label>
            <textarea className="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring resize-none" rows={3} value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="What is this group about?" /></div>
          <div><label className="text-xs font-medium text-muted-foreground mb-1 block">Privacy</label>
            <select className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm outline-none" value={form.privacy} onChange={e => setForm(f => ({ ...f, privacy: e.target.value }))}>
              <option value="PUBLIC">Public</option><option value="PRIVATE">Private</option>
            </select></div>
        </div>
        <div className="p-4 border-t border-border">
          <Button className="w-full" onClick={create} loading={loading}>Create Group</Button>
        </div>
      </motion.div>
    </div>
  );
}
