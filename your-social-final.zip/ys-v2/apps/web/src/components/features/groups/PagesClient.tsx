'use client';
import { useState, useEffect } from 'react';
import { Plus, ThumbsUp, X } from 'lucide-react';
import { Avatar, Card, Skeleton, EmptyState } from '@/components/ui/index';
import { Button } from '@/components/ui/button';
import { pageAPI } from '@/lib/api';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function PagesClient() {
  const [pages, setPages] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);

  useEffect(() => { pageAPI.getMy().then(r => { setPages(r.data.pages || []); setLoading(false); }).catch(() => setLoading(false)); }, []);

  const like = async (id: string) => {
    const { data } = await pageAPI.like(id);
    setPages(p => p.map(pg => pg.id === id ? { ...pg, isLiked: data.liked } : pg));
  };

  const CATS = ['Business','Brand','Artist','Public Figure','Entertainment','Sports','Education','Community','Non-profit','Other'];

  return (
    <div className="max-w-5xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-2xl font-bold">Pages</h1>
        <Button onClick={() => setShowCreate(true)}><Plus className="w-4 h-4" /> Create Page</Button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-52 rounded-2xl" />)}
        </div>
      ) : pages.length === 0 ? (
        <EmptyState icon="🚩" title="No pages yet" description="Create a page for your business, brand, or cause."
          action={<Button onClick={() => setShowCreate(true)}><Plus className="w-4 h-4" /> Create Page</Button>} />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {pages.map((pg, i) => (
            <motion.div key={pg.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <Card className="overflow-hidden">
                <div className="h-28 bg-gradient-to-br from-rose-500/30 to-orange-400/30 overflow-hidden">
                  {pg.coverPhoto && <img src={pg.coverPhoto} alt="" className="w-full h-full object-cover" />}
                </div>
                <div className="p-4">
                  <div className="flex items-start gap-3 -mt-8 mb-2">
                    <div className="w-14 h-14 rounded-xl border-2 border-card overflow-hidden bg-muted shrink-0">
                      {pg.profilePicture ? <img src={pg.profilePicture} alt="" className="w-full h-full object-cover" /> :
                        <div className="w-full h-full bg-primary flex items-center justify-center text-white font-bold text-xl">{pg.name[0]}</div>}
                    </div>
                    <div className="pt-8">
                      <h3 className="font-bold text-sm">{pg.name}</h3>
                      <p className="text-xs text-muted-foreground">{pg.category}</p>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mb-3">{pg._count?.likes || 0} likes · {pg._count?.followers || 0} followers</p>
                  <Button size="sm" variant={pg.isLiked ? 'secondary' : 'default'} className="w-full" onClick={() => like(pg.id)}>
                    <ThumbsUp className="w-3.5 h-3.5" /> {pg.isLiked ? 'Liked' : 'Like Page'}
                  </Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {showCreate && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4" onClick={e => e.target === e.currentTarget && setShowCreate(false)}>
          <motion.div initial={{ scale: 0.95 }} animate={{ scale: 1 }} className="bg-card rounded-2xl w-full max-w-md shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b border-border">
              <div /><h3 className="font-bold">Create Page</h3>
              <button onClick={() => setShowCreate(false)} className="w-8 h-8 rounded-full bg-muted flex items-center justify-center"><X className="w-4 h-4" /></button>
            </div>
            <CreatePageForm onDone={pg => { setPages(p => [pg, ...p]); setShowCreate(false); toast.success('Page created!'); }} CATS={CATS} />
          </motion.div>
        </div>
      )}
    </div>
  );
}

function CreatePageForm({ onDone, CATS }: any) {
  const [form, setForm] = useState({ name: '', description: '', category: 'Business' });
  const [loading, setLoading] = useState(false);
  const create = async () => {
    if (!form.name.trim()) return toast.error('Name is required');
    setLoading(true);
    try { const { data } = await pageAPI.create(form); onDone(data.page); }
    catch { toast.error('Failed'); }
    setLoading(false);
  };
  return (
    <div className="p-4 space-y-3">
      <div><label className="text-xs font-medium text-muted-foreground mb-1 block">Page name *</label>
        <input className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></div>
      <div><label className="text-xs font-medium text-muted-foreground mb-1 block">Category</label>
        <select className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm outline-none" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
          {CATS.map((c: string) => <option key={c} value={c}>{c}</option>)}
        </select></div>
      <div><label className="text-xs font-medium text-muted-foreground mb-1 block">Description</label>
        <textarea className="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring resize-none" rows={3} value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} /></div>
      <Button className="w-full" onClick={create} loading={loading}>Create Page</Button>
    </div>
  );
}
