'use client';
// Notifications page
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { CheckCheck, Trash2 } from 'lucide-react';
import { Avatar, Card, Spinner, EmptyState } from '@/components/ui/index';
import { Button } from '@/components/ui/button';
import { notifAPI } from '@/lib/api';
import { formatDate } from '@/lib/utils';
import { useRouter } from 'next/navigation';
import { useSocket } from '@/lib/socket';
import useAuthStore from '@/store/auth.store';

export function NotificationsClient() {
  const [notifs, setNotifs] = useState<any[]>([]);
  const [unread, setUnread] = useState(0);
  const [loading, setLoading] = useState(true);
  const { socket } = useSocket();
  const router = useRouter();

  useEffect(() => {
    notifAPI.getAll().then(r => { setNotifs(r.data.notifications || []); setUnread(r.data.unreadCount || 0); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!socket) return;
    socket.on('notification', (n: any) => { setNotifs(p => [n, ...p]); setUnread(p => p + 1); });
    return () => { socket.off('notification'); };
  }, [socket]);

  const markAll = async () => { await notifAPI.readAll(); setNotifs(p => p.map(n => ({ ...n, isRead: true }))); setUnread(0); };
  const click = async (n: any) => { if (!n.isRead) { await notifAPI.readOne(n.id); setNotifs(p => p.map(x => x.id === n.id ? { ...x, isRead: true } : x)); setUnread(p => Math.max(0,p-1)); } if (n.link) router.push(n.link); };
  const del = async (e: any, id: string) => { e.stopPropagation(); await notifAPI.delete(id); setNotifs(p => p.filter(n => n.id !== id)); };

  return (
    <div className="max-w-2xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-bold">Notifications</h1>
        {unread > 0 && <Button variant="outline" size="sm" onClick={markAll}><CheckCheck className="w-4 h-4" /> Mark all read</Button>}
      </div>
      {loading ? <Spinner center /> : notifs.length === 0 ? <EmptyState icon="🔔" title="No notifications" description="You're all caught up!" /> : (
        <Card className="overflow-hidden">
          {notifs.map((n, i) => (
            <motion.div key={n.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
              onClick={() => click(n)}
              className={`flex items-start gap-3 px-4 py-3 cursor-pointer transition-colors border-b border-border last:border-0 ${!n.isRead ? 'bg-primary/5' : 'hover:bg-muted/50'}`}>
              <Avatar src={n.sender?.profilePicture} firstName={n.sender?.firstName} lastName={n.sender?.lastName} size="md" />
              <div className="flex-1 min-w-0">
                <p className="text-sm">{n.message}</p>
                <p className={`text-xs mt-0.5 ${!n.isRead ? 'text-primary font-semibold' : 'text-muted-foreground'}`}>{formatDate(n.createdAt)}</p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {!n.isRead && <div className="w-2.5 h-2.5 rounded-full bg-primary" />}
                <button onClick={e => del(e, n.id)} className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            </motion.div>
          ))}
        </Card>
      )}
    </div>
  );
}
