'use client';
import { useState, useEffect } from 'react';
import { postAPI } from '@/lib/api';
import { Skeleton } from '@/components/ui/index';
import PostCard from './PostCard';

export default function PostDetailClient({ postId }: { postId: string }) {
  const [post, setPost] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    postAPI.getPost(postId).then(r => { setPost(r.data.post); setLoading(false); }).catch(() => setLoading(false));
  }, [postId]);

  if (loading) return (
    <div className="max-w-xl mx-auto px-4 py-6">
      <Skeleton className="h-64 rounded-2xl" />
    </div>
  );

  if (!post) return (
    <div className="max-w-xl mx-auto px-4 py-6 text-center text-muted-foreground">
      Post not found.
    </div>
  );

  return (
    <div className="max-w-xl mx-auto px-4 py-6">
      <PostCard post={post} onUpdate={setPost} />
    </div>
  );
}
