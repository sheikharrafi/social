'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Send, ThumbsUp, ChevronDown } from 'lucide-react';
import { Avatar, Spinner } from '@/components/ui/index';
import { commentAPI } from '@/lib/api';
import { formatDate } from '@/lib/utils';
import useAuthStore from '@/store/auth.store';

export default function CommentsSection({ postId }: { postId: string }) {
  const { user } = useAuthStore();
  const [comments, setComments] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [replyTo, setReplyTo] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    commentAPI.get(postId).then(r => { setComments(r.data.comments || []); setLoading(false); }).catch(() => setLoading(false));
  }, [postId]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    try {
      const { data } = await commentAPI.create({ postId, content: input, parentCommentId: replyTo?.id });
      if (replyTo) {
        setComments(prev => prev.map(c => c.id === replyTo.id ? { ...c, replies: [...(c.replies || []), data.comment] } : c));
      } else {
        setComments(prev => [data.comment, ...prev]);
      }
      setInput(''); setReplyTo(null);
    } catch {}
  };

  return (
    <div className="px-4 pb-3 border-t border-border/50 pt-3">
      <form onSubmit={submit} className="flex items-center gap-2 mb-3">
        <Avatar src={user?.profilePicture} firstName={user?.firstName} lastName={user?.lastName} size="sm" />
        <div className="flex-1 flex items-center gap-2 bg-muted rounded-full px-4 h-9">
          {replyTo && (
            <span className="text-xs text-primary font-semibold shrink-0">
              @{replyTo.author?.firstName} ·{' '}
              <button type="button" onClick={() => setReplyTo(null)} className="text-muted-foreground">✕</button>
            </span>
          )}
          <input
            className="bg-transparent text-sm flex-1 outline-none placeholder:text-muted-foreground"
            placeholder={replyTo ? 'Write a reply...' : 'Write a comment...'}
            value={input}
            onChange={e => setInput(e.target.value)}
          />
          <button type="submit" className="text-primary disabled:opacity-40" disabled={!input.trim()}>
            <Send className="w-4 h-4" />
          </button>
        </div>
      </form>

      {loading && <Spinner size="sm" className="mx-auto" />}

      <div className="space-y-3">
        {comments.map(c => (
          <CommentItem key={c.id} comment={c} currentUserId={user?.id} onReply={setReplyTo}
            onDelete={id => setComments(prev => prev.filter(x => x.id !== id))} />
        ))}
      </div>
    </div>
  );
}

function CommentItem({ comment, currentUserId, onReply, onDelete, isReply = false }: any) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(comment.content);
  const [showReplies, setShowReplies] = useState(false);
  const name = `${comment.author?.firstName} ${comment.author?.lastName}`;
  const isOwner = comment.author?.id === currentUserId;

  const handleEdit = async () => {
    try { await commentAPI.update(comment.id, val); comment.content = val; comment.isEdited = true; setEditing(false); } catch {}
  };

  return (
    <div className="flex gap-2">
      <Link href={`/profile/${comment.author?.id}`} className="shrink-0 mt-0.5">
        <Avatar src={comment.author?.profilePicture} firstName={comment.author?.firstName} lastName={comment.author?.lastName} size="sm" />
      </Link>
      <div className="flex-1">
        <div className="inline-block bg-muted rounded-2xl px-3 py-2 max-w-full">
          <Link href={`/profile/${comment.author?.id}`} className="font-semibold text-xs hover:underline block">{name}</Link>
          {editing ? (
            <div className="mt-1">
              <input className="bg-background border border-input rounded-lg px-2 py-1 text-sm w-full outline-none" value={val} onChange={e => setVal(e.target.value)} autoFocus />
              <div className="flex gap-2 mt-1">
                <button className="text-xs text-primary font-semibold" onClick={handleEdit}>Save</button>
                <button className="text-xs text-muted-foreground" onClick={() => setEditing(false)}>Cancel</button>
              </div>
            </div>
          ) : (
            <p className="text-sm mt-0.5">{comment.content}</p>
          )}
        </div>
        <div className="flex items-center gap-3 mt-1 px-1 text-xs text-muted-foreground">
          <span>{formatDate(comment.createdAt)}</span>
          <button className="font-semibold hover:text-foreground" onClick={() => commentAPI.react(comment.id, 'LIKE')}>Like</button>
          {!isReply && <button className="font-semibold hover:text-foreground" onClick={() => onReply(comment)}>Reply</button>}
          {isOwner && <button className="font-semibold hover:text-foreground" onClick={() => setEditing(true)}>Edit</button>}
          {isOwner && <button className="font-semibold hover:text-destructive" onClick={() => { commentAPI.delete(comment.id); onDelete(comment.id); }}>Delete</button>}
        </div>
        {comment.replies?.length > 0 && !isReply && (
          <button className="flex items-center gap-1 text-xs text-primary font-semibold mt-1 px-1" onClick={() => setShowReplies(p => !p)}>
            <ChevronDown className={`w-3 h-3 transition-transform ${showReplies ? 'rotate-180' : ''}`} />
            {showReplies ? 'Hide' : `${comment.replies.length}`} {comment.replies.length === 1 ? 'reply' : 'replies'}
          </button>
        )}
        {showReplies && comment.replies?.map((r: any) => (
          <CommentItem key={r.id} comment={r} currentUserId={currentUserId} onReply={onReply} onDelete={onDelete} isReply />
        ))}
      </div>
    </div>
  );
}
