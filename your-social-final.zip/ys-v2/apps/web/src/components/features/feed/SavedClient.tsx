'use client';
import { useState, useEffect } from 'react';
import { postAPI } from '@/lib/api';
import { Skeleton, EmptyState } from '@/components/ui/index';
import PostCard from './PostCard';

export default function SavedClient() {
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    postAPI.getSaved().then(r => { setPosts(r.data.posts || []); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="max-w-xl mx-auto px-4 py-6 space-y-3">
      <div className="h-8 w-32 bg-muted animate-pulse rounded-xl mb-4" />
      {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-48 rounded-2xl" />)}
    </div>
  );

  return (
    <div className="max-w-xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-5 flex items-center gap-2">🔖 Saved Posts</h1>
      {posts.length === 0
        ? <EmptyState icon="🔖" title="No saved posts" description="Save posts to view them here later." />
        : posts.map(p => <PostCard key={p.id} post={p} onDelete={id => setPosts(prev => prev.filter(x => x.id !== id))} />)
      }
    </div>
  );
}
