'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { postAPI } from '@/lib/api';
import { Spinner, Skeleton, EmptyState } from '@/components/ui/index';
import Stories from './Stories';
import CreatePost from './CreatePost';
import PostCard from './PostCard';

export default function FeedClient() {
  const [posts, setPosts] = useState<any[]>([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(false);
  const [initial, setInitial] = useState(true);
  const loaderRef = useRef<HTMLDivElement>(null);

  const fetchPosts = useCallback(async (p: number) => {
    if (loading) return;
    setLoading(true);
    try {
      const { data } = await postAPI.getFeed(p);
      if (p === 1) setPosts(data.posts || []);
      else setPosts(prev => [...prev, ...(data.posts || [])]);
      setHasMore(p < (data.pages || 1));
    } catch {}
    setLoading(false);
    setInitial(false);
  }, []);

  useEffect(() => { fetchPosts(1); }, []);

  useEffect(() => {
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && hasMore && !loading) { const next = page + 1; setPage(next); fetchPosts(next); }
    }, { threshold: 0.1 });
    if (loaderRef.current) obs.observe(loaderRef.current);
    return () => obs.disconnect();
  }, [hasMore, loading, page]);

  if (initial) return (
    <div className="max-w-xl mx-auto px-4 py-6 space-y-4">
      <Skeleton className="h-36 rounded-2xl" />
      <Skeleton className="h-24 rounded-2xl" />
      {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-48 rounded-2xl" />)}
    </div>
  );

  return (
    <div className="max-w-xl mx-auto px-4 py-6 space-y-3">
      <Stories />
      <CreatePost onCreated={post => setPosts(prev => [post, ...prev])} />

      <AnimatePresence initial={false}>
        {posts.map((post, i) => (
          <motion.div key={post.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i < 5 ? i * 0.05 : 0 }}>
            <PostCard post={post} onDelete={id => setPosts(prev => prev.filter(p => p.id !== id))} onUpdate={u => setPosts(prev => prev.map(p => p.id === u.id ? u : p))} />
          </motion.div>
        ))}
      </AnimatePresence>

      {posts.length === 0 && !loading && (
        <EmptyState icon="📰" title="Your feed is empty" description="Add friends or follow people to see their posts here." />
      )}

      <div ref={loaderRef} className="flex justify-center py-4">
        {loading && <Spinner />}
        {!hasMore && posts.length > 0 && <p className="text-sm text-muted-foreground">You're all caught up 🎉</p>}
      </div>
    </div>
  );
}
