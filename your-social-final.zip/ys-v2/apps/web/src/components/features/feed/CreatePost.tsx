'use client';
import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Image, Video, Smile, MapPin, Users, Globe, Lock, X, ChevronDown } from 'lucide-react';
import { Avatar, Card, Textarea } from '@/components/ui/index';
import { Button } from '@/components/ui/button';
import { postAPI, uploadAPI } from '@/lib/api';
import useAuthStore from '@/store/auth.store';
import toast from 'react-hot-toast';

const AUDIENCES = [
  { value: 'PUBLIC', label: 'Public', icon: Globe },
  { value: 'FRIENDS', label: 'Friends', icon: Users },
  { value: 'ONLY_ME', label: 'Only me', icon: Lock },
];

const BG_COLORS = ['', '#1877f2', '#8b5cf6', '#ef4444', '#f97316', '#10b981', '#f59e0b', '#ec4899', '#06b6d4'];

const FEELINGS = [
  { emoji: '😊', text: 'happy' }, { emoji: '😢', text: 'sad' }, { emoji: '😍', text: 'in love' },
  { emoji: '🎉', text: 'excited' }, { emoji: '😴', text: 'tired' }, { emoji: '😡', text: 'angry' },
  { emoji: '🤒', text: 'sick' }, { emoji: '😎', text: 'blessed' }, { emoji: '🙏', text: 'grateful' },
];

export default function CreatePost({ onCreated }: { onCreated: (post: any) => void }) {
  const { user } = useAuthStore();
  const [open, setOpen] = useState(false);
  const [content, setContent] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [audience, setAudience] = useState('FRIENDS');
  const [bg, setBg] = useState('');
  const [feeling, setFeeling] = useState<any>(null);
  const [location, setLocation] = useState('');
  const [showAudience, setShowAudience] = useState(false);
  const [showFeeling, setShowFeeling] = useState(false);
  const [loading, setLoading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const fullName = user ? `${user.firstName} ${user.lastName}` : '';
  const aud = AUDIENCES.find(a => a.value === audience)!;

  const addFiles = (picked: FileList | null) => {
    if (!picked) return;
    const arr = Array.from(picked);
    setFiles(p => [...p, ...arr]);
    arr.forEach(f => { const r = new FileReader(); r.onload = e => setPreviews(p => [...p, e.target?.result as string]); r.readAsDataURL(f); });
    setBg('');
  };

  const removeFile = (i: number) => { setFiles(p => p.filter((_, j) => j !== i)); setPreviews(p => p.filter((_, j) => j !== i)); };

  const reset = () => { setOpen(false); setContent(''); setFiles([]); setPreviews([]); setBg(''); setFeeling(null); setLocation(''); };

  const handleSubmit = async () => {
    if (!content.trim() && files.length === 0) return toast.error('Add some text or media');
    setLoading(true);
    try {
      const fd = new FormData();
      fd.append('content', content);
      fd.append('audience', audience);
      if (bg) fd.append('background', bg);
      if (feeling) { fd.append('feeling', feeling.text); fd.append('feelingEmoji', feeling.emoji); }
      if (location) fd.append('location', location);
      files.forEach(f => fd.append('files', f));
      const { data } = await postAPI.createPost(fd);
      onCreated(data.post);
      reset();
      toast.success('Post published!');
    } catch (e: any) {
      toast.error(e.response?.data?.message || 'Failed to post');
    }
    setLoading(false);
  };

  return (
    <>
      <Card className="p-3">
        <div className="flex items-center gap-3">
          <Avatar src={user?.profilePicture} firstName={user?.firstName} lastName={user?.lastName} size="md" />
          <button
            onClick={() => setOpen(true)}
            className="flex-1 bg-muted hover:bg-muted/80 rounded-full px-4 h-10 text-sm text-muted-foreground text-left transition-colors"
          >
            What's on your mind, {user?.firstName}?
          </button>
        </div>
        <div className="flex items-center gap-1 mt-2 pt-2 border-t border-border/50">
          {[
            { icon: Image, label: 'Photo/Video', color: 'text-emerald-500', action: () => { setOpen(true); setTimeout(() => fileRef.current?.click(), 50); } },
            { icon: Smile, label: 'Feeling', color: 'text-amber-500', action: () => { setOpen(true); setShowFeeling(true); } },
            { icon: MapPin, label: 'Location', color: 'text-rose-500', action: () => { setOpen(true); } },
          ].map(b => (
            <button key={b.label} onClick={b.action} className="flex items-center gap-1.5 flex-1 justify-center py-1.5 rounded-xl text-xs font-semibold text-muted-foreground hover:bg-muted transition-colors">
              <b.icon className={`w-4 h-4 ${b.color}`} />
              <span className="hidden sm:inline">{b.label}</span>
            </button>
          ))}
        </div>
      </Card>

      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4"
            onClick={e => e.target === e.currentTarget && reset()}>
            <motion.div initial={{ scale: 0.95, y: 10 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95 }}
              className="bg-card rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-border">
                <div />
                <h3 className="font-bold text-base">Create post</h3>
                <button onClick={reset} className="w-8 h-8 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors"><X className="w-4 h-4" /></button>
              </div>

              <div className="overflow-y-auto flex-1 p-4 space-y-3">
                {/* Author row */}
                <div className="flex items-center gap-2">
                  <Avatar src={user?.profilePicture} firstName={user?.firstName} lastName={user?.lastName} size="md" />
                  <div>
                    <p className="font-semibold text-sm">
                      {fullName}
                      {feeling && <span className="font-normal text-muted-foreground"> is {feeling.emoji} feeling {feeling.text}</span>}
                      {location && <span className="font-normal text-muted-foreground"> 📍 {location}</span>}
                    </p>
                    <div className="relative">
                      <button onClick={() => setShowAudience(p => !p)}
                        className="flex items-center gap-1 text-xs bg-muted px-2 py-0.5 rounded-md font-semibold mt-0.5 hover:bg-muted/80">
                        <aud.icon className="w-3 h-3" />{aud.label}<ChevronDown className="w-3 h-3" />
                      </button>
                      {showAudience && (
                        <div className="absolute left-0 top-full mt-1 bg-popover border border-border rounded-xl shadow-lg overflow-hidden z-10 w-40">
                          {AUDIENCES.map(a => (
                            <button key={a.value} onClick={() => { setAudience(a.value); setShowAudience(false); }}
                              className="flex items-center gap-2 w-full px-3 py-2 text-sm hover:bg-muted transition-colors">
                              <a.icon className="w-4 h-4" />{a.label}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Text area */}
                {bg ? (
                  <div className="rounded-xl min-h-[180px] flex items-center justify-center p-6" style={{ background: bg }}>
                    <textarea value={content} onChange={e => setContent(e.target.value)}
                      placeholder={`What's on your mind, ${user?.firstName}?`}
                      className="bg-transparent text-white text-2xl font-bold text-center w-full outline-none resize-none placeholder:text-white/60"
                      rows={3} autoFocus />
                  </div>
                ) : (
                  <Textarea value={content} onChange={e => setContent(e.target.value)}
                    placeholder={`What's on your mind, ${user?.firstName}?`}
                    className={`border-0 bg-transparent p-0 focus-visible:ring-0 ${content.length < 85 && !previews.length ? 'text-xl' : 'text-sm'}`}
                    rows={4} autoFocus />
                )}

                {/* Image previews */}
                {previews.length > 0 && (
                  <div className={`grid gap-1 ${previews.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
                    {previews.map((p, i) => (
                      <div key={i} className="relative rounded-xl overflow-hidden">
                        <img src={p} alt="" className="w-full object-cover max-h-48" />
                        <button onClick={() => removeFile(i)} className="absolute top-1.5 right-1.5 bg-black/60 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs hover:bg-black/80">✕</button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Background colors */}
                {previews.length === 0 && (
                  <div className="flex gap-2 flex-wrap">
                    {BG_COLORS.map(c => (
                      <button key={c} onClick={() => setBg(c)}
                        className={`w-8 h-8 rounded-lg border-2 transition-all ${bg === c ? 'border-foreground scale-110' : 'border-transparent'}`}
                        style={{ background: c || 'var(--muted)' }} />
                    ))}
                  </div>
                )}

                {/* Feelings */}
                {showFeeling && (
                  <div>
                    <p className="text-xs font-semibold text-muted-foreground mb-2">How are you feeling?</p>
                    <div className="flex flex-wrap gap-2">
                      {FEELINGS.map(f => (
                        <button key={f.text} onClick={() => { setFeeling(f); setShowFeeling(false); }}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${feeling?.text === f.text ? 'bg-primary/20 text-primary' : 'bg-muted hover:bg-muted/80'}`}>
                          <span className="text-base">{f.emoji}</span> {f.text}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Location input */}
                <div className="flex items-center gap-2 bg-muted rounded-xl px-3 h-9">
                  <MapPin className="w-4 h-4 text-rose-500 shrink-0" />
                  <input className="bg-transparent text-sm flex-1 outline-none placeholder:text-muted-foreground"
                    placeholder="Add a location..." value={location} onChange={e => setLocation(e.target.value)} />
                </div>

                {/* Add to post */}
                <div className="flex items-center justify-between border border-border rounded-xl px-3 py-2">
                  <span className="text-sm font-semibold">Add to your post</span>
                  <div className="flex gap-1">
                    <button onClick={() => fileRef.current?.click()} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-muted"><Image className="w-4 h-4 text-emerald-500" /></button>
                    <button onClick={() => setShowFeeling(p => !p)} className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-muted"><Smile className="w-4 h-4 text-amber-500" /></button>
                  </div>
                </div>
              </div>

              <div className="p-4 border-t border-border">
                <Button className="w-full h-10" onClick={handleSubmit} loading={loading}
                  disabled={!content.trim() && files.length === 0}>Post</Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <input ref={fileRef} type="file" multiple accept="image/*,video/*" className="hidden" onChange={e => addFiles(e.target.files)} />
    </>
  );
}
