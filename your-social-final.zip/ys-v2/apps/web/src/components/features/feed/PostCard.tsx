'use client';
import { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { MoreHorizontal, ThumbsUp, MessageCircle, Share2, Bookmark, Globe, Users, Lock, Pencil, Trash2, Flag } from 'lucide-react';
import { Avatar, Badge, Card } from '@/components/ui/index';
import { Button } from '@/components/ui/button';
import { formatDate } from '@/lib/utils';
import { postAPI } from '@/lib/api';
import CommentsSection from './CommentsSection';
import toast from 'react-hot-toast';
import useAuthStore from '@/store/auth.store';

const REACTIONS = [
  { type: 'LIKE', emoji: '👍', label: 'Like', color: 'text-blue-500' },
  { type: 'LOVE', emoji: '❤️', label: 'Love', color: 'text-rose-500' },
  { type: 'HAHA', emoji: '😂', label: 'Haha', color: 'text-amber-500' },
  { type: 'WOW', emoji: '😮', label: 'Wow', color: 'text-amber-500' },
  { type: 'SAD', emoji: '😢', label: 'Sad', color: 'text-amber-500' },
  { type: 'ANGRY', emoji: '😡', label: 'Angry', color: 'text-orange-500' },
];

const AUD_ICON: any = { PUBLIC: <Globe className="w-3 h-3" />, FRIENDS: <Users className="w-3 h-3" />, ONLY_ME: <Lock className="w-3 h-3" /> };

export default function PostCard({ post: init, onDelete, onUpdate }: { post: any; onDelete?: (id: string) => void; onUpdate?: (p: any) => void }) {
  const { user } = useAuthStore();
  const [post, setPost] = useState(init);
  const [showComments, setShowComments] = useState(false);
  const [showReactions, setShowReactions] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editContent, setEditContent] = useState(init.content || '');
  const [imageViewer, setImageViewer] = useState<string | null>(null);
  const reactTimer = useRef<ReturnType<typeof setTimeout>>();
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const h = (e: MouseEvent) => { if (menuRef.current && !menuRef.current.contains(e.target as Node)) setShowMenu(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);

  const myReaction = post.reactions?.find((r: any) => r.userId === user?.id);
  const totalReactions = post.reactions?.length || 0;
  const totalComments = post._count?.comments || 0;
  const totalShares = post._count?.shares || 0;

  const topReactionTypes = REACTIONS.filter(r => post.reactions?.some((x: any) => x.type === r.type)).slice(0, 3);

  const handleReact = async (type: string) => {
    setShowReactions(false);
    const prevReactions = post.reactions || [];
    const existIdx = prevReactions.findIndex((r: any) => r.userId === user?.id);
    let updated;
    if (existIdx !== -1 && prevReactions[existIdx].type === type) {
      updated = prevReactions.filter((_: any, i: number) => i !== existIdx);
    } else if (existIdx !== -1) {
      updated = prevReactions.map((r: any, i: number) => i === existIdx ? { ...r, type } : r);
    } else {
      updated = [...prevReactions, { userId: user?.id, type }];
    }
    setPost((p: any) => ({ ...p, reactions: updated }));
    try { await postAPI.react(post.id, type); } catch { setPost((p: any) => ({ ...p, reactions: prevReactions })); }
  };

  const handleDelete = async () => {
    if (!confirm('Delete this post?')) return;
    try { await postAPI.deletePost(post.id); onDelete?.(post.id); toast.success('Post deleted'); } catch { toast.error('Failed to delete'); }
  };

  const handleEdit = async () => {
    try {
      const { data } = await postAPI.updatePost(post.id, { content: editContent });
      setPost((p: any) => ({ ...p, content: data.post.content, isEdited: true }));
      onUpdate?.(data.post);
      setEditing(false);
    } catch { toast.error('Failed to update'); }
  };

  const handleSave = async () => {
    try { const { data } = await postAPI.save(post.id); toast.success(data.saved ? 'Post saved' : 'Post unsaved'); } catch {}
    setShowMenu(false);
  };

  const authorName = post.author ? `${post.author.firstName} ${post.author.lastName}` : 'Unknown';
  const isOwner = post.author?.id === user?.id;
  const currentReaction = myReaction ? REACTIONS.find(r => r.type === myReaction.type) : null;

  return (
    <>
      <Card className="overflow-hidden">
        {/* Header */}
        <div className="flex items-start justify-between p-4 pb-2">
          <div className="flex items-center gap-3">
            <Link href={`/profile/${post.author?.id}`}>
              <Avatar src={post.author?.profilePicture} firstName={post.author?.firstName} lastName={post.author?.lastName} size="md" />
            </Link>
            <div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <Link href={`/profile/${post.author?.id}`} className="font-semibold text-sm hover:underline">{authorName}</Link>
                {post.author?.isVerified && <span className="text-blue-500 text-xs">✓</span>}
                {post.feeling && <span className="text-muted-foreground text-sm"> is {post.feelingEmoji} {post.feeling}</span>}
                {post.location && <span className="text-muted-foreground text-sm"> 📍 {post.location}</span>}
              </div>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <span>{formatDate(post.createdAt)}</span>
                {post.isEdited && <span>· Edited</span>}
                <span>·</span>
                <span title={post.audience}>{AUD_ICON[post.audience]}</span>
              </div>
            </div>
          </div>

          <div ref={menuRef} className="relative">
            <Button variant="ghost" size="icon-sm" onClick={() => setShowMenu(p => !p)}>
              <MoreHorizontal className="w-4 h-4" />
            </Button>
            <AnimatePresence>
              {showMenu && (
                <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
                  className="absolute right-0 top-full mt-1 w-52 bg-popover border border-border rounded-xl shadow-lg overflow-hidden z-20">
                  <button onClick={handleSave} className="flex items-center gap-2.5 w-full px-3 py-2.5 text-sm hover:bg-muted transition-colors">
                    <Bookmark className="w-4 h-4" /> Save post
                  </button>
                  {isOwner && <>
                    <button onClick={() => { setEditing(true); setShowMenu(false); }} className="flex items-center gap-2.5 w-full px-3 py-2.5 text-sm hover:bg-muted transition-colors">
                      <Pencil className="w-4 h-4" /> Edit post
                    </button>
                    <button onClick={handleDelete} className="flex items-center gap-2.5 w-full px-3 py-2.5 text-sm text-destructive hover:bg-destructive/10 transition-colors">
                      <Trash2 className="w-4 h-4" /> Delete post
                    </button>
                  </>}
                  {!isOwner && (
                    <button className="flex items-center gap-2.5 w-full px-3 py-2.5 text-sm hover:bg-muted transition-colors">
                      <Flag className="w-4 h-4" /> Report post
                    </button>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Content */}
        {editing ? (
          <div className="px-4 pb-3">
            <textarea className="w-full min-h-[80px] rounded-xl border border-input bg-background p-3 text-sm outline-none focus:ring-2 focus:ring-ring resize-none" value={editContent} onChange={e => setEditContent(e.target.value)} autoFocus />
            <div className="flex gap-2 mt-2">
              <Button size="sm" onClick={handleEdit}>Save</Button>
              <Button size="sm" variant="outline" onClick={() => setEditing(false)}>Cancel</Button>
            </div>
          </div>
        ) : post.content && (
          <div className={`px-4 pb-2 ${!post.media?.length && post.content.length < 100 ? 'text-xl font-semibold' : 'text-sm'} ${post.background ? 'min-h-[200px] flex items-center justify-center text-white font-bold text-2xl text-center rounded-xl mx-4 mb-2' : ''}`}
            style={post.background ? { background: post.background } : {}}>
            {post.content}
          </div>
        )}

        {/* Media */}
        {post.media?.length > 0 && (
          <div className={`grid gap-0.5 overflow-hidden ${post.media.length === 1 ? '' : post.media.length === 2 ? 'grid-cols-2' : post.media.length === 3 ? 'grid-cols-2' : 'grid-cols-2'}`}>
            {post.media.slice(0, 4).map((m: any, i: number) => (
              <div key={m.id} className={`relative ${post.media.length === 3 && i === 0 ? 'row-span-2' : ''} ${i === 3 && post.media.length > 4 ? 'relative' : ''}`}
                style={{ aspectRatio: post.media.length === 1 ? undefined : '1', maxHeight: post.media.length === 1 ? '500px' : undefined }}>
                <img src={m.url} alt="" className="w-full h-full object-cover cursor-pointer" onClick={() => setImageViewer(m.url)} />
                {i === 3 && post.media.length > 4 && (
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center cursor-pointer" onClick={() => setImageViewer(m.url)}>
                    <span className="text-white text-2xl font-bold">+{post.media.length - 4}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Shared post */}
        {post.sharedPost && (
          <div className="mx-4 mb-2 border border-border rounded-xl overflow-hidden">
            <div className="flex items-center gap-2 p-3">
              <Avatar src={post.sharedPost.author?.profilePicture} firstName={post.sharedPost.author?.firstName} lastName={post.sharedPost.author?.lastName} size="xs" />
              <Link href={`/profile/${post.sharedPost.author?.id}`} className="font-semibold text-xs hover:underline">
                {post.sharedPost.author?.firstName} {post.sharedPost.author?.lastName}
              </Link>
              <span className="text-xs text-muted-foreground">· {formatDate(post.sharedPost.createdAt)}</span>
            </div>
            {post.sharedPost.content && <p className="px-3 pb-2 text-sm">{post.sharedPost.content}</p>}
            {post.sharedPost.media?.[0] && <img src={post.sharedPost.media[0].url} alt="" className="w-full max-h-48 object-cover" />}
          </div>
        )}

        {/* Stats */}
        {(totalReactions > 0 || totalComments > 0 || totalShares > 0) && (
          <div className="flex items-center justify-between px-4 py-1.5 text-xs text-muted-foreground">
            <div className="flex items-center gap-1.5">
              {topReactionTypes.map(r => <span key={r.type}>{r.emoji}</span>)}
              {totalReactions > 0 && <span>{totalReactions.toLocaleString()}</span>}
            </div>
            <div className="flex items-center gap-3">
              {totalComments > 0 && <button onClick={() => setShowComments(p => !p)} className="hover:underline">{totalComments} comment{totalComments !== 1 ? 's' : ''}</button>}
              {totalShares > 0 && <span>{totalShares} share{totalShares !== 1 ? 's' : ''}</span>}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex border-t border-border/50 mx-2">
          {/* Like button with reaction picker */}
          <div className="relative flex-1"
            onMouseEnter={() => { reactTimer.current = setTimeout(() => setShowReactions(true), 500); }}
            onMouseLeave={() => { clearTimeout(reactTimer.current); }}>
            <button
              className={`flex items-center justify-center gap-2 w-full py-2 rounded-xl text-sm font-semibold transition-colors hover:bg-muted ${currentReaction ? currentReaction.color : 'text-muted-foreground'}`}
              onClick={() => handleReact(myReaction ? myReaction.type : 'LIKE')}
            >
              {currentReaction ? <span className="text-base">{currentReaction.emoji}</span> : <ThumbsUp className="w-4 h-4" />}
              {currentReaction ? currentReaction.label : 'Like'}
            </button>

            <AnimatePresence>
              {showReactions && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8, y: 4 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.8 }}
                  className="absolute bottom-full left-0 mb-2 flex gap-1 bg-popover border border-border rounded-full shadow-xl px-3 py-2 z-10"
                  onMouseEnter={() => clearTimeout(reactTimer.current)}
                  onMouseLeave={() => setShowReactions(false)}
                >
                  {REACTIONS.map(r => (
                    <button key={r.type} onClick={() => handleReact(r.type)}
                      className="flex flex-col items-center gap-0.5 hover:scale-125 transition-transform"
                      title={r.label}>
                      <span className="text-2xl">{r.emoji}</span>
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <button className="flex items-center justify-center gap-2 flex-1 py-2 rounded-xl text-sm font-semibold text-muted-foreground hover:bg-muted transition-colors"
            onClick={() => setShowComments(p => !p)}>
            <MessageCircle className="w-4 h-4" /> Comment
          </button>

          <button className="flex items-center justify-center gap-2 flex-1 py-2 rounded-xl text-sm font-semibold text-muted-foreground hover:bg-muted transition-colors"
            onClick={() => { postAPI.share(post.id, {}); toast.success('Shared!'); }}>
            <Share2 className="w-4 h-4" /> Share
          </button>
        </div>

        {/* Comments */}
        {showComments && <CommentsSection postId={post.id} />}
      </Card>

      {/* Image viewer */}
      <AnimatePresence>
        {imageViewer && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 p-4"
            onClick={() => setImageViewer(null)}>
            <img src={imageViewer} alt="" className="max-w-full max-h-full rounded-xl object-contain" onClick={e => e.stopPropagation()} />
            <button onClick={() => setImageViewer(null)} className="absolute top-4 right-4 text-white text-2xl bg-black/50 w-10 h-10 rounded-full flex items-center justify-center">✕</button>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
