'use client';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, X, ChevronLeft, ChevronRight } from 'lucide-react';
import { Avatar } from '@/components/ui/index';
import { storyAPI, uploadAPI } from '@/lib/api';
import useAuthStore from '@/store/auth.store';
import toast from 'react-hot-toast';

export default function Stories() {
  const { user } = useAuthStore();
  const [groups, setGroups] = useState<any[]>([]);
  const [viewer, setViewer] = useState<{ gi: number; si: number } | null>(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => { storyAPI.getAll().then(r => setGroups(r.data.storyGroups || [])).catch(() => {}); }, []);

  const handleAdd = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    setUploading(true);
    try {
      const fd = new FormData(); fd.append('file', file);
      await storyAPI.create(fd);
      const { data } = await storyAPI.getAll();
      setGroups(data.storyGroups || []);
      toast.success('Story added!');
    } catch { toast.error('Failed to add story'); }
    setUploading(false);
  };

  const open = (gi: number, si = 0) => {
    setViewer({ gi, si });
    storyAPI.view(groups[gi].stories[si].id).catch(() => {});
  };

  const next = () => {
    if (!viewer) return;
    const g = groups[viewer.gi];
    if (viewer.si + 1 < g.stories.length) setViewer({ ...viewer, si: viewer.si + 1 });
    else if (viewer.gi + 1 < groups.length) open(viewer.gi + 1);
    else setViewer(null);
  };

  const prev = () => {
    if (!viewer) return;
    if (viewer.si > 0) setViewer({ ...viewer, si: viewer.si - 1 });
    else if (viewer.gi > 0) open(viewer.gi - 1);
  };

  return (
    <>
      <div className="flex gap-2 overflow-x-auto scrollbar-none pb-1">
        {/* Add story card */}
        <label className="flex-shrink-0 w-[110px] h-[190px] rounded-2xl overflow-hidden cursor-pointer relative group">
          <input type="file" accept="image/*,video/*" className="hidden" onChange={handleAdd} />
          <div className="w-full h-[60%] bg-muted overflow-hidden">
            {user?.profilePicture ? <img src={user.profilePicture} alt="" className="w-full h-full object-cover" /> : <div className="w-full h-full gradient-brand" />}
          </div>
          <div className="absolute top-[calc(60%-20px)] left-1/2 -translate-x-1/2 w-10 h-10 rounded-full gradient-brand border-3 border-card flex items-center justify-center shadow-md">
            {uploading ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> : <Plus className="w-5 h-5 text-white" />}
          </div>
          <div className="absolute bottom-0 left-0 right-0 bg-card flex flex-col items-center justify-end pb-3 pt-6">
            <span className="text-xs font-bold text-center">Add Story</span>
          </div>
        </label>

        {/* Story cards */}
        {groups.map((group, gi) => {
          const latest = group.stories[group.stories.length - 1];
          const a = group.author;
          return (
            <motion.div key={a.id} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
              className="flex-shrink-0 w-[110px] h-[190px] rounded-2xl overflow-hidden cursor-pointer relative"
              onClick={() => open(gi)}>
              {latest.mediaUrl ? (
                latest.type === 'VIDEO'
                  ? <video src={latest.mediaUrl} className="w-full h-full object-cover" />
                  : <img src={latest.mediaUrl} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center p-3 text-center font-bold text-white text-sm"
                  style={{ background: latest.bgColor || '#1877f2' }}>{latest.text}</div>
              )}
              <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/60" />
              <div className="absolute top-2 left-2">
                <div className="ring-2 ring-primary rounded-full p-0.5">
                  <Avatar src={a.profilePicture} firstName={a.firstName} lastName={a.lastName} size="xs" />
                </div>
              </div>
              <p className="absolute bottom-2 left-2 right-2 text-white text-xs font-semibold truncate">{a.firstName}</p>
            </motion.div>
          );
        })}
      </div>

      {/* Story viewer */}
      <AnimatePresence>
        {viewer && (() => {
          const group = groups[viewer.gi];
          const story = group.stories[viewer.si];
          const a = group.author;
          return (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black z-50 flex items-center justify-center"
              onClick={e => e.target === e.currentTarget && setViewer(null)}>
              {/* Progress bars */}
              <div className="absolute top-3 left-4 right-4 flex gap-1 z-10">
                {group.stories.map((_: any, i: number) => (
                  <div key={i} className="flex-1 h-0.5 bg-white/30 rounded-full overflow-hidden">
                    {i < viewer.si && <div className="h-full bg-white w-full" />}
                    {i === viewer.si && <motion.div className="h-full bg-white" initial={{ width: 0 }} animate={{ width: '100%' }} transition={{ duration: 5, ease: 'linear' }} onAnimationComplete={next} />}
                  </div>
                ))}
              </div>

              {/* Author */}
              <div className="absolute top-7 left-4 flex items-center gap-2 z-10">
                <Avatar src={a.profilePicture} firstName={a.firstName} lastName={a.lastName} size="sm" />
                <div>
                  <p className="text-white text-sm font-semibold">{a.firstName} {a.lastName}</p>
                </div>
              </div>
              <button onClick={() => setViewer(null)} className="absolute top-4 right-4 text-white z-10 w-8 h-8 rounded-full bg-black/40 flex items-center justify-center"><X className="w-4 h-4" /></button>

              {/* Nav */}
              <button onClick={prev} className="absolute left-4 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-black/40 flex items-center justify-center text-white"><ChevronLeft className="w-5 h-5" /></button>
              <button onClick={next} className="absolute right-4 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-black/40 flex items-center justify-center text-white"><ChevronRight className="w-5 h-5" /></button>

              {/* Media */}
              <div className="max-w-sm w-full mx-auto h-full flex items-center justify-center px-4" onClick={e => e.stopPropagation()}>
                {story.type === 'VIDEO'
                  ? <video src={story.mediaUrl} autoPlay className="max-h-[85vh] rounded-2xl w-full object-contain" />
                  : story.mediaUrl
                    ? <img src={story.mediaUrl} alt="" className="max-h-[85vh] rounded-2xl w-full object-contain" />
                    : <div className="w-full h-[85vh] rounded-2xl flex items-center justify-center p-8 text-white font-bold text-3xl text-center" style={{ background: story.bgColor || '#1877f2' }}>{story.text}</div>
                }
              </div>
            </motion.div>
          );
        })()}
      </AnimatePresence>
    </>
  );
}
