'use client';
import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { Camera, UserPlus, UserCheck, UserX, MessageCircle, MoreHorizontal, MapPin, Briefcase, GraduationCap, Heart, Globe, Pencil } from 'lucide-react';
import { Avatar, Badge, Card, Skeleton, Separator } from '@/components/ui/index';
import { Button } from '@/components/ui/button';
import { userAPI, friendAPI, postAPI, uploadAPI } from '@/lib/api';
import useAuthStore from '@/store/auth.store';
import PostCard from '@/components/features/feed/PostCard';
import CreatePost from '@/components/features/feed/CreatePost';
import toast from 'react-hot-toast';

const TABS = ['Posts', 'About', 'Friends', 'Photos', 'Videos'];

export default function ProfileClient({ userId }: { userId: string }) {
  const { user: me, updateUser } = useAuthStore();
  const router = useRouter();
  const [profile, setProfile] = useState<any>(null);
  const [posts, setPosts] = useState<any[]>([]);
  const [photos, setPhotos] = useState<any[]>([]);
  const [friends, setFriends] = useState<any[]>([]);
  const [tab, setTab] = useState('Posts');
  const [loading, setLoading] = useState(true);
  const [editBio, setEditBio] = useState(false);
  const [bioVal, setBioVal] = useState('');
  const coverRef = useRef<HTMLInputElement>(null);
  const avatarRef = useRef<HTMLInputElement>(null);
  const isMe = userId === me?.id;

  useEffect(() => {
    setLoading(true);
    Promise.all([userAPI.getProfile(userId), postAPI.getUserPosts(userId)]).then(([p, po]) => {
      setProfile(p.data.user);
      setPosts(po.data.posts || []);
      setBioVal(p.data.user.bio || '');
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [userId]);

  useEffect(() => {
    if (tab === 'Photos') userAPI.getPhotos(userId).then(r => setPhotos(r.data.photos || [])).catch(() => {});
    if (tab === 'Friends') userAPI.getFriends(userId).then(r => setFriends(r.data.friends || [])).catch(() => {});
  }, [tab, userId]);

  const handleFriendAction = async () => {
    try {
      const fs = profile.friendStatus;
      if (fs === 'NONE') { await friendAPI.send(userId); setProfile((p: any) => ({ ...p, friendStatus: 'SENT' })); toast.success('Request sent!'); }
      else if (fs === 'SENT') { await friendAPI.cancel(userId); setProfile((p: any) => ({ ...p, friendStatus: 'NONE' })); }
      else if (fs === 'RECEIVED') { await friendAPI.accept(userId); setProfile((p: any) => ({ ...p, friendStatus: 'FRIENDS' })); toast.success('Friends!'); }
      else if (fs === 'FRIENDS') { await friendAPI.unfriend(userId); setProfile((p: any) => ({ ...p, friendStatus: 'NONE' })); toast.success('Unfriended'); }
    } catch { toast.error('Action failed'); }
  };

  const handleCover = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    try { const { data } = await userAPI.uploadCover(file); setProfile((p: any) => ({ ...p, coverPhoto: data.url })); updateUser({ coverPhoto: data.url }); toast.success('Cover updated!'); } catch { toast.error('Failed'); }
  };

  const handleAvatar = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return;
    try { const { data } = await userAPI.uploadAvatar(file); setProfile((p: any) => ({ ...p, profilePicture: data.url })); updateUser({ profilePicture: data.url }); toast.success('Photo updated!'); } catch { toast.error('Failed'); }
  };

  const saveBio = async () => {
    try { await userAPI.updateProfile({ bio: bioVal }); setProfile((p: any) => ({ ...p, bio: bioVal })); updateUser({ bio: bioVal }); setEditBio(false); toast.success('Bio saved!'); } catch {}
  };

  if (loading) return (
    <div className="max-w-3xl mx-auto">
      <Skeleton className="h-48 w-full" />
      <div className="px-4 -mt-12 pb-4"><Skeleton className="w-32 h-32 rounded-full" /></div>
      <div className="px-4 space-y-3"><Skeleton className="h-6 w-48" /><Skeleton className="h-4 w-32" /></div>
    </div>
  );

  if (!profile) return <div className="text-center py-20 text-muted-foreground">User not found</div>;

  const fullName = `${profile.firstName} ${profile.lastName}`;
  const fs = profile.friendStatus;

  return (
    <div className="pb-10">
      {/* Cover */}
      <div className="relative h-48 md:h-72 bg-gradient-to-r from-blue-500 to-violet-600 overflow-hidden">
        {profile.coverPhoto && <img src={profile.coverPhoto} alt="" className="w-full h-full object-cover" />}
        {isMe && (
          <label className="absolute bottom-3 right-3 cursor-pointer">
            <Button variant="secondary" size="sm" asChild>
              <span><Camera className="w-4 h-4" /> Edit cover</span>
            </Button>
            <input ref={coverRef} type="file" accept="image/*" className="hidden" onChange={handleCover} />
          </label>
        )}
      </div>

      {/* Profile info */}
      <div className="max-w-3xl mx-auto px-4">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 -mt-16 pb-4">
          <div className="flex items-end gap-4">
            <div className="relative">
              <div className="w-32 h-32 rounded-full border-4 border-background overflow-hidden bg-muted">
                {profile.profilePicture
                  ? <img src={profile.profilePicture} alt={fullName} className="w-full h-full object-cover" />
                  : <div className="w-full h-full bg-primary flex items-center justify-center text-white text-4xl font-bold">{profile.firstName[0]}{profile.lastName[0]}</div>}
              </div>
              {isMe && (
                <label className="absolute bottom-1 right-1 w-8 h-8 bg-muted border-2 border-background rounded-full flex items-center justify-center cursor-pointer hover:bg-muted/80">
                  <Camera className="w-4 h-4" />
                  <input ref={avatarRef} type="file" accept="image/*" className="hidden" onChange={handleAvatar} />
                </label>
              )}
            </div>
            <div className="pb-2">
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-black">{fullName}</h1>
                {profile.isVerified && <span className="text-blue-500 font-bold">✓</span>}
              </div>
              <p className="text-sm text-muted-foreground">{profile._count?.friendships || 0} friends · {profile._count?.followers || 0} followers</p>
            </div>
          </div>

          <div className="flex gap-2 pb-2 flex-wrap">
            {isMe ? (
              <Button variant="secondary" onClick={() => router.push('/settings')}><Pencil className="w-4 h-4" /> Edit profile</Button>
            ) : (
              <>
                <Button variant={fs === 'FRIENDS' ? 'secondary' : 'default'} onClick={handleFriendAction}>
                  {fs === 'NONE' && <><UserPlus className="w-4 h-4" /> Add friend</>}
                  {fs === 'SENT' && <><UserX className="w-4 h-4" /> Requested</>}
                  {fs === 'RECEIVED' && <><UserCheck className="w-4 h-4" /> Accept</>}
                  {fs === 'FRIENDS' && <><UserCheck className="w-4 h-4" /> Friends</>}
                </Button>
                <Button variant="secondary" onClick={() => router.push(`/messages?userId=${userId}`)}><MessageCircle className="w-4 h-4" /> Message</Button>
                <Button variant="ghost" size="icon"><MoreHorizontal className="w-4 h-4" /></Button>
              </>
            )}
          </div>
        </div>

        {/* Bio */}
        <div className="text-center mb-4">
          {editBio ? (
            <div className="max-w-sm mx-auto">
              <textarea className="w-full border border-input rounded-xl p-2 text-sm text-center resize-none outline-none focus:ring-2 focus:ring-ring bg-background" value={bioVal} onChange={e => setBioVal(e.target.value)} rows={3} maxLength={500} autoFocus />
              <div className="flex gap-2 justify-center mt-2">
                <Button size="sm" onClick={saveBio}>Save</Button>
                <Button size="sm" variant="outline" onClick={() => setEditBio(false)}>Cancel</Button>
              </div>
            </div>
          ) : (
            <div>
              {profile.bio && <p className="text-muted-foreground text-sm">{profile.bio}</p>}
              {isMe && <Button variant="ghost" size="sm" className="mt-1" onClick={() => setEditBio(true)}><Pencil className="w-3 h-3" /> {profile.bio ? 'Edit bio' : 'Add bio'}</Button>}
            </div>
          )}
        </div>

        {/* Quick info */}
        <div className="flex flex-wrap justify-center gap-4 text-sm text-muted-foreground mb-4">
          {profile.workplace && <span className="flex items-center gap-1"><Briefcase className="w-4 h-4" /> {profile.workplace}</span>}
          {profile.education && <span className="flex items-center gap-1"><GraduationCap className="w-4 h-4" /> {profile.education}</span>}
          {profile.location && <span className="flex items-center gap-1"><MapPin className="w-4 h-4" /> {profile.location}</span>}
          {profile.relationship && <span className="flex items-center gap-1"><Heart className="w-4 h-4" /> {profile.relationship}</span>}
          {profile.website && <a href={profile.website} className="flex items-center gap-1 text-primary hover:underline"><Globe className="w-4 h-4" /> {profile.website}</a>}
        </div>

        <Separator />

        {/* Tabs */}
        <div className="flex border-b border-border mt-2 overflow-x-auto scrollbar-none">
          {TABS.map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`px-4 py-3 text-sm font-semibold transition-colors whitespace-nowrap border-b-2 -mb-px ${tab === t ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`}>
              {t}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <div className="mt-4">
          {tab === 'Posts' && (
            <div className="flex gap-4">
              <div className="hidden md:block w-80 shrink-0 space-y-3">
                <Card className="p-4">
                  <h3 className="font-bold mb-3">Intro</h3>
                  {[
                    { icon: Briefcase, val: profile.workplace, prefix: 'Works at' },
                    { icon: GraduationCap, val: profile.education, prefix: 'Studied at' },
                    { icon: MapPin, val: profile.location, prefix: 'Lives in' },
                    { icon: MapPin, val: profile.hometown, prefix: 'From' },
                    { icon: Heart, val: profile.relationship, prefix: '' },
                  ].filter(f => f.val).map((f, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm mb-2">
                      <f.icon className="w-4 h-4 text-muted-foreground shrink-0" />
                      <span>{f.prefix && <b>{f.prefix} </b>}{f.val}</span>
                    </div>
                  ))}
                  {isMe && <Button variant="secondary" size="sm" className="w-full mt-2" onClick={() => router.push('/settings')}>Edit details</Button>}
                </Card>
                {photos.length > 0 && (
                  <Card className="p-4">
                    <div className="flex justify-between mb-3"><h3 className="font-bold">Photos</h3><button className="text-sm text-primary" onClick={() => setTab('Photos')}>See all</button></div>
                    <div className="grid grid-cols-3 gap-1">
                      {photos.slice(0, 9).map((p: any, i: number) => (
                        <img key={i} src={p.url} alt="" className="aspect-square object-cover rounded-lg cursor-pointer" />
                      ))}
                    </div>
                  </Card>
                )}
              </div>
              <div className="flex-1 min-w-0 space-y-3">
                {isMe && <CreatePost onCreated={p => setPosts(prev => [p, ...prev])} />}
                {posts.map(p => <PostCard key={p.id} post={p} onDelete={id => setPosts(prev => prev.filter(x => x.id !== id))} onUpdate={u => setPosts(prev => prev.map(x => x.id === u.id ? u : x))} />)}
                {posts.length === 0 && <div className="text-center py-12 text-muted-foreground">No posts yet.</div>}
              </div>
            </div>
          )}

          {tab === 'About' && (
            <Card className="p-6 max-w-xl">
              <h3 className="font-bold text-lg mb-4">About</h3>
              {[
                { label: 'Workplace', val: profile.workplace, icon: Briefcase },
                { label: 'Education', val: profile.education, icon: GraduationCap },
                { label: 'Location', val: profile.location, icon: MapPin },
                { label: 'Hometown', val: profile.hometown, icon: MapPin },
                { label: 'Relationship', val: profile.relationship, icon: Heart },
                { label: 'Website', val: profile.website, icon: Globe },
              ].map(f => (
                <div key={f.label} className="flex items-center justify-between py-3 border-b border-border last:border-0">
                  <div className="flex items-center gap-3">
                    <f.icon className="w-4 h-4 text-muted-foreground" />
                    <div><p className="text-xs text-muted-foreground">{f.label}</p><p className="font-medium text-sm">{f.val || <span className="text-muted-foreground">Not added</span>}</p></div>
                  </div>
                </div>
              ))}
              {isMe && <Button variant="secondary" className="w-full mt-4" onClick={() => router.push('/settings')}>Edit details</Button>}
            </Card>
          )}

          {tab === 'Friends' && (
            <div>
              <p className="text-sm text-muted-foreground mb-3">{friends.length} friends</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {friends.map((f: any) => (
                  <Card key={f.id} className="p-3 flex items-center gap-3 cursor-pointer hover:bg-muted/50 transition-colors" onClick={() => router.push(`/profile/${f.id}`)}>
                    <Avatar src={f.profilePicture} firstName={f.firstName} lastName={f.lastName} size="md" />
                    <p className="font-semibold text-sm truncate">{f.firstName} {f.lastName}</p>
                  </Card>
                ))}
              </div>
              {friends.length === 0 && <div className="text-center py-12 text-muted-foreground">No friends to show.</div>}
            </div>
          )}

          {tab === 'Photos' && (
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-1">
              {photos.map((p: any, i: number) => (
                <img key={i} src={p.url} alt="" className="aspect-square object-cover rounded-xl cursor-pointer hover:opacity-90 transition-opacity" />
              ))}
              {photos.length === 0 && <div className="col-span-4 text-center py-12 text-muted-foreground">No photos yet.</div>}
            </div>
          )}

          {tab === 'Videos' && (
            <div className="text-center py-12 text-muted-foreground">No videos yet.</div>
          )}
        </div>
      </div>
    </div>
  );
}
