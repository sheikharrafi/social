'use client';
import { useState, useEffect, useRef } from 'react';
import { Play, ThumbsUp, MessageCircle, Share2, Volume2, VolumeX } from 'lucide-react';
import { Avatar, Skeleton, EmptyState } from '@/components/ui/index';
import { Button } from '@/components/ui/button';
import { postAPI, reelAPI } from '@/lib/api';
import { formatDate, formatNumber } from '@/lib/utils';
import { motion } from 'framer-motion';
import Link from 'next/link';

export default function WatchClient() {
  const [videos, setVideos] = useState<any[]>([]);
  const [playing, setPlaying] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [muted, setMuted] = useState(false);

  useEffect(() => {
    postAPI.getFeed()
      .then(r => {
        const vids = (r.data.posts || []).filter((p: any) => p.media?.some((m: any) => m.type === 'VIDEO'));
        setVideos(vids);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const handlePlay = (v: any) => {
    setPlaying(v);
    setTimeout(() => videoRef.current?.play(), 100);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">Watch</h1>

      {playing && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
          className="mb-6 bg-black rounded-2xl overflow-hidden relative">
          <video
            ref={videoRef}
            src={playing.media?.find((m: any) => m.type === 'VIDEO')?.url}
            className="w-full max-h-[500px] object-contain"
            controls
            muted={muted}
          />
          <button onClick={() => setMuted(p => !p)}
            className="absolute top-3 right-3 bg-black/50 text-white rounded-full w-9 h-9 flex items-center justify-center">
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
          <div className="p-4 bg-card border-t border-border">
            <div className="flex items-start gap-3">
              <Link href={`/profile/${playing.author?.id}`}>
                <Avatar src={playing.author?.profilePicture} firstName={playing.author?.firstName} lastName={playing.author?.lastName} size="md" />
              </Link>
              <div className="flex-1">
                <Link href={`/profile/${playing.author?.id}`} className="font-semibold text-sm hover:underline">
                  {playing.author?.firstName} {playing.author?.lastName}
                </Link>
                <p className="text-xs text-muted-foreground">{formatDate(playing.createdAt)}</p>
                {playing.content && <p className="text-sm mt-1">{playing.content}</p>}
              </div>
            </div>
            <div className="flex gap-3 mt-3">
              <Button variant="secondary" size="sm">
                <ThumbsUp className="w-4 h-4" /> {formatNumber(playing.reactions?.length || 0)}
              </Button>
              <Button variant="secondary" size="sm">
                <MessageCircle className="w-4 h-4" /> {formatNumber(playing._count?.comments || 0)}
              </Button>
              <Button variant="secondary" size="sm">
                <Share2 className="w-4 h-4" /> Share
              </Button>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="mt-2" onClick={() => setPlaying(null)}>
            ← Back to all videos
          </Button>
        </motion.div>
      )}

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-52 rounded-2xl" />)}
        </div>
      ) : videos.length === 0 ? (
        <EmptyState icon="📹" title="No videos yet" description="Videos from people you follow will appear here." />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {videos.map((v, i) => {
            const videoMedia = v.media?.find((m: any) => m.type === 'VIDEO');
            if (!videoMedia) return null;
            return (
              <motion.div key={v.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                className="cursor-pointer group" onClick={() => handlePlay(v)}>
                <div className="relative rounded-2xl overflow-hidden bg-black aspect-video">
                  <video src={videoMedia.url} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-14 h-14 rounded-full bg-white/90 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                      <Play className="w-6 h-6 text-primary ml-1" />
                    </div>
                  </div>
                </div>
                <div className="mt-2 flex gap-2">
                  <Avatar src={v.author?.profilePicture} firstName={v.author?.firstName} lastName={v.author?.lastName} size="sm" className="mt-0.5" />
                  <div>
                    <p className="text-sm font-semibold line-clamp-2">{v.content || 'Video'}</p>
                    <p className="text-xs text-muted-foreground">{v.author?.firstName} {v.author?.lastName} · {formatDate(v.createdAt)}</p>
                    <p className="text-xs text-muted-foreground">{formatNumber(v.reactions?.length || 0)} likes</p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
