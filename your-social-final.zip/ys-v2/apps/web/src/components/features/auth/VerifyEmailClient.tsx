'use client';
import { useEffect, useState } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Spinner } from '@/components/ui/index';
import { authAPI } from '@/lib/api';

export default function VerifyEmailClient() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');

  useEffect(() => {
    const token = searchParams.get('token');
    if (!token) { setStatus('error'); return; }
    authAPI.verifyEmail(token)
      .then(() => setStatus('success'))
      .catch(() => setStatus('error'));
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-background via-muted/30 to-background">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
        className="bg-card border border-border/50 rounded-3xl p-8 shadow-xl text-center max-w-sm w-full">
        {status === 'loading' && (
          <><Spinner size="lg" className="mx-auto mb-4" /><p className="text-muted-foreground">Verifying your email...</p></>
        )}
        {status === 'success' && (
          <><div className="text-6xl mb-4">✅</div>
          <h2 className="text-2xl font-bold mb-2">Email verified!</h2>
          <p className="text-muted-foreground mb-5">Your account is now fully verified. Welcome to YourSocial!</p>
          <Button className="w-full" onClick={() => router.push('/')}>Go to Home</Button></>
        )}
        {status === 'error' && (
          <><div className="text-6xl mb-4">❌</div>
          <h2 className="text-2xl font-bold mb-2">Verification failed</h2>
          <p className="text-muted-foreground mb-5">The link may be invalid or expired. Please request a new one.</p>
          <Button className="w-full" onClick={() => router.push('/login')}>Back to Login</Button></>
        )}
      </motion.div>
    </div>
  );
}
