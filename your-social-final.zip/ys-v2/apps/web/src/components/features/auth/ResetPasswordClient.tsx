'use client';
import { useState } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/index';
import { authAPI } from '@/lib/api';
import toast from 'react-hot-toast';

export default function ResetPasswordClient() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const token = searchParams.get('token') || '';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirm) return toast.error('Passwords do not match');
    if (password.length < 6) return toast.error('Password must be at least 6 characters');
    setLoading(true);
    try {
      await authAPI.resetPassword({ token, password });
      toast.success('Password reset successfully!');
      router.push('/login');
    } catch (e: any) {
      toast.error(e.response?.data?.message || 'Invalid or expired token');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-background via-muted/30 to-background">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        <div className="bg-card border border-border/50 rounded-3xl p-8 shadow-xl">
          <div className="flex items-center gap-2 mb-6">
            <div className="w-9 h-9 rounded-xl gradient-brand flex items-center justify-center">
              <span className="text-white font-black text-lg">Y</span>
            </div>
            <span className="font-black text-xl gradient-text">YourSocial</span>
          </div>
          <h2 className="text-2xl font-bold mb-2">Set new password</h2>
          <p className="text-muted-foreground text-sm mb-6">Enter and confirm your new password.</p>
          {!token ? (
            <p className="text-destructive text-sm">Invalid reset link. Please request a new one.</p>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input label="New password" type="password" placeholder="Minimum 6 characters" value={password}
                onChange={e => setPassword(e.target.value)} leftIcon={<Lock className="w-4 h-4" />} required minLength={6} />
              <Input label="Confirm password" type="password" placeholder="Repeat password" value={confirm}
                onChange={e => setConfirm(e.target.value)} leftIcon={<Lock className="w-4 h-4" />} required />
              <Button type="submit" className="w-full" loading={loading}>Reset Password</Button>
            </form>
          )}
        </div>
      </motion.div>
    </div>
  );
}
