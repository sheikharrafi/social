'use client';
import { motion } from 'framer-motion';
import { Gamepad2, Trophy, Users, Play, Star, ExternalLink } from 'lucide-react';
import { Card, Badge } from '@/components/ui/index';
import { Button } from '@/components/ui/button';

const GAMES = [
  { id: 1, name: 'Word Blitz', category: 'Word', players: '2.1M', rating: 4.5, emoji: '💬', color: 'from-blue-400 to-blue-600', description: 'Find as many words as possible!' },
  { id: 2, name: 'Instant Game', category: 'Puzzle', players: '1.8M', rating: 4.3, emoji: '🧩', color: 'from-violet-400 to-violet-600', description: 'Classic puzzle game' },
  { id: 3, name: 'Solitaire', category: 'Card', players: '3.2M', rating: 4.7, emoji: '🃏', color: 'from-emerald-400 to-emerald-600', description: 'Classic card game' },
  { id: 4, name: '8 Ball Pool', category: 'Sports', players: '5.5M', rating: 4.8, emoji: '🎱', color: 'from-amber-400 to-amber-600', description: 'Challenge your friends' },
  { id: 5, name: 'Trivia Crack', category: 'Trivia', players: '2.9M', rating: 4.4, emoji: '❓', color: 'from-rose-400 to-rose-600', description: 'Test your knowledge' },
  { id: 6, name: 'Chess', category: 'Strategy', players: '4.1M', rating: 4.9, emoji: '♟️', color: 'from-slate-500 to-slate-700', description: 'The classic strategy game' },
  { id: 7, name: 'Crossword', category: 'Word', players: '1.2M', rating: 4.2, emoji: '📝', color: 'from-cyan-400 to-cyan-600', description: 'Daily crossword puzzles' },
  { id: 8, name: 'Coin Master', category: 'Casual', players: '8.3M', rating: 4.6, emoji: '🪙', color: 'from-orange-400 to-orange-600', description: 'Spin & build your village' },
];

const CATEGORIES = ['All', 'Word', 'Puzzle', 'Card', 'Sports', 'Trivia', 'Strategy', 'Casual'];

export default function GamingClient() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-6">
      {/* Hero */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-violet-600 to-blue-600 p-8 mb-8 text-white">
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
              <Gamepad2 className="w-7 h-7" />
            </div>
            <div>
              <h1 className="text-2xl font-black">Gaming</h1>
              <p className="text-white/70 text-sm">Play with your friends</p>
            </div>
          </div>
          <div className="flex gap-4 text-sm">
            <div className="flex items-center gap-1.5"><Users className="w-4 h-4" /> 50M+ players</div>
            <div className="flex items-center gap-1.5"><Gamepad2 className="w-4 h-4" /> 100+ games</div>
            <div className="flex items-center gap-1.5"><Trophy className="w-4 h-4" /> Leaderboards</div>
          </div>
        </div>
        <div className="absolute right-6 top-4 text-7xl opacity-20 select-none">🎮</div>
        <div className="absolute right-20 bottom-2 text-5xl opacity-10 select-none">🕹️</div>
      </motion.div>

      {/* Categories */}
      <div className="flex gap-2 overflow-x-auto scrollbar-none pb-2 mb-6">
        {CATEGORIES.map(cat => (
          <button key={cat}
            className="shrink-0 px-4 py-1.5 rounded-full text-sm font-semibold bg-secondary hover:bg-primary hover:text-primary-foreground transition-colors">
            {cat}
          </button>
        ))}
      </div>

      {/* Games grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {GAMES.map((game, i) => (
          <motion.div key={game.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
            <Card className="overflow-hidden cursor-pointer hover:shadow-lg transition-all hover:-translate-y-0.5 group">
              <div className={`h-28 bg-gradient-to-br ${game.color} flex items-center justify-center relative`}>
                <span className="text-5xl">{game.emoji}</span>
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
                <div className="absolute top-2 right-2">
                  <Badge className="bg-black/30 border-0 text-white text-[10px]">{game.category}</Badge>
                </div>
              </div>
              <div className="p-3">
                <h3 className="font-bold text-sm">{game.name}</h3>
                <p className="text-xs text-muted-foreground mb-1 line-clamp-1">{game.description}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1 text-amber-500 text-xs">
                    <Star className="w-3 h-3 fill-amber-500" />
                    <span className="font-semibold">{game.rating}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">{game.players}</span>
                </div>
                <Button size="sm" className="w-full mt-2 h-7 text-xs">
                  <Play className="w-3 h-3" /> Play Now
                </Button>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Leaderboard teaser */}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}>
        <Card className="p-5 mt-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-amber-500" />
              <h3 className="font-bold">Weekly Leaderboard</h3>
            </div>
            <Button variant="ghost" size="sm">See all <ExternalLink className="w-3 h-3" /></Button>
          </div>
          <div className="space-y-2">
            {[
              { rank: 1, name: 'You', score: '12,450', medal: '🥇' },
              { rank: 2, name: 'Sarah K.', score: '11,200', medal: '🥈' },
              { rank: 3, name: 'Mike R.', score: '9,800', medal: '🥉' },
            ].map(entry => (
              <div key={entry.rank} className="flex items-center gap-3 p-2 rounded-xl hover:bg-muted transition-colors">
                <span className="text-xl w-8 text-center">{entry.medal}</span>
                <div className="flex-1">
                  <p className="font-semibold text-sm">{entry.name}</p>
                </div>
                <p className="font-bold text-sm text-primary">{entry.score}</p>
              </div>
            ))}
          </div>
        </Card>
      </motion.div>
    </div>
  );
}
