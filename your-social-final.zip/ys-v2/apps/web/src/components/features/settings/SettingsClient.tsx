'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useTheme } from 'next-themes';
import { User, Lock, Bell, Eye, Sun, Moon, Shield, LogOut, CheckCircle } from 'lucide-react';
import { Card, Avatar, Input, Textarea } from '@/components/ui/index';
import { Button } from '@/components/ui/button';
import { userAPI, verifyAPI } from '@/lib/api';
import useAuthStore from '@/store/auth.store';
import toast from 'react-hot-toast';

type Tab = 'profile' | 'security' | 'privacy' | 'notifications' | 'display' | 'verification';

const TABS = [
  { key: 'profile', label: 'Edit Profile', icon: User },
  { key: 'security', label: 'Security', icon: Lock },
  { key: 'privacy', label: 'Privacy', icon: Eye },
  { key: 'notifications', label: 'Notifications', icon: Bell },
  { key: 'display', label: 'Display', icon: Sun },
  { key: 'verification', label: 'Verification', icon: Shield },
];

export default function SettingsClient({ tab: initialTab }: { tab: Tab }) {
  const [tab, setTab] = useState<Tab>(initialTab);
  const { logout } = useAuthStore();
  const router = useRouter();

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">Settings</h1>
      <div className="flex gap-6">
        {/* Sidebar */}
        <div className="w-56 shrink-0 hidden md:block">
          <div className="space-y-0.5">
            {TABS.map(t => (
              <button key={t.key} onClick={() => setTab(t.key as Tab)}
                className={`flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${tab === t.key ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`}>
                <t.icon className="w-4 h-4" /> {t.label}
              </button>
            ))}
            <div className="pt-2 mt-2 border-t border-border">
              <button onClick={async () => { await logout(); router.push('/login'); }}
                className="flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors">
                <LogOut className="w-4 h-4" /> Log Out
              </button>
            </div>
          </div>
        </div>

        {/* Mobile tab selector */}
        <div className="md:hidden w-full mb-4">
          <select className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm outline-none"
            value={tab} onChange={e => setTab(e.target.value as Tab)}>
            {TABS.map(t => <option key={t.key} value={t.key}>{t.label}</option>)}
          </select>
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          {tab === 'profile' && <ProfileTab />}
          {tab === 'security' && <SecurityTab />}
          {tab === 'privacy' && <PrivacyTab />}
          {tab === 'notifications' && <NotifTab />}
          {tab === 'display' && <DisplayTab />}
          {tab === 'verification' && <VerificationTab />}
        </div>
      </div>
    </div>
  );
}

function ProfileTab() {
  const { user, updateUser } = useAuthStore();
  const [form, setForm] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    bio: user?.bio || '',
    website: user?.website || '',
    location: user?.location || '',
    workplace: user?.workplace || '',
    education: user?.education || '',
    relationship: user?.relationship || '',
    gender: user?.gender || '',
    hometown: user?.hometown || '',
    username: user?.username || '',
  });
  const [saving, setSaving] = useState(false);
  const f = (k: string) => (e: any) => setForm(p => ({ ...p, [k]: e.target.value }));

  const save = async () => {
    setSaving(true);
    try {
      const { data } = await userAPI.updateProfile(form);
      updateUser(data.user);
      toast.success('Profile updated!');
    } catch { toast.error('Failed to save'); }
    setSaving(false);
  };

  return (
    <Card className="p-6 space-y-4">
      <h2 className="text-lg font-bold">Profile Information</h2>
      <div className="flex items-center gap-4 pb-4 border-b border-border">
        <Avatar src={user?.profilePicture} firstName={user?.firstName} lastName={user?.lastName} size="xl" />
        <div>
          <p className="font-semibold">{user?.firstName} {user?.lastName}</p>
          <p className="text-sm text-muted-foreground">To change your photo, go to your <a href={`/profile/${user?.id}`} className="text-primary hover:underline">profile page</a>.</p>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <Input label="First name" value={form.firstName} onChange={f('firstName')} />
        <Input label="Last name" value={form.lastName} onChange={f('lastName')} />
      </div>
      <Input label="Username" value={form.username} onChange={f('username')} placeholder="@yourname" />
      <div className="space-y-1">
        <label className="text-xs font-medium text-muted-foreground">Bio</label>
        <Textarea value={form.bio} onChange={f('bio')} placeholder="Tell people about yourself..." className="resize-none" rows={3} maxLength={500} />
        <p className="text-xs text-muted-foreground text-right">{form.bio.length}/500</p>
      </div>
      {[['website','Website','🔗'],['location','Current city','📍'],['hometown','Hometown','🏘️'],['workplace','Workplace','💼'],['education','Education','🎓']].map(([k,l,e]) => (
        <Input key={k} label={`${e} ${l}`} value={(form as any)[k]} onChange={f(k)} placeholder={`Add your ${l.toLowerCase()}`} />
      ))}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-1 block">Gender</label>
          <select className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring" value={form.gender} onChange={f('gender')}>
            <option value="">Select gender</option>
            {['MALE','FEMALE','OTHER','PREFER_NOT_TO_SAY'].map(g => <option key={g} value={g}>{g.replace(/_/g,' ')}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-1 block">Relationship</label>
          <select className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm outline-none focus:ring-2 focus:ring-ring" value={form.relationship} onChange={f('relationship')}>
            <option value="">Select status</option>
            {['SINGLE','IN_RELATIONSHIP','ENGAGED','MARRIED','RATHER_NOT_SAY'].map(r => <option key={r} value={r}>{r.replace(/_/g,' ')}</option>)}
          </select>
        </div>
      </div>
      <Button onClick={save} loading={saving}>Save Changes</Button>
    </Card>
  );
}

function SecurityTab() {
  const [form, setForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [saving, setSaving] = useState(false);
  const change = async () => {
    if (form.newPassword !== form.confirmPassword) return toast.error('Passwords do not match');
    if (form.newPassword.length < 6) return toast.error('Min 6 characters');
    setSaving(true);
    try { await userAPI.changePassword({ currentPassword: form.currentPassword, newPassword: form.newPassword }); toast.success('Password changed!'); setForm({ currentPassword: '', newPassword: '', confirmPassword: '' }); }
    catch (e: any) { toast.error(e.response?.data?.message || 'Failed'); }
    setSaving(false);
  };
  return (
    <Card className="p-6 space-y-4 max-w-md">
      <h2 className="text-lg font-bold">Change Password</h2>
      <Input label="Current password" type="password" value={form.currentPassword} onChange={e => setForm(f => ({ ...f, currentPassword: e.target.value }))} />
      <Input label="New password" type="password" value={form.newPassword} onChange={e => setForm(f => ({ ...f, newPassword: e.target.value }))} />
      <Input label="Confirm new password" type="password" value={form.confirmPassword} onChange={e => setForm(f => ({ ...f, confirmPassword: e.target.value }))} />
      <Button onClick={change} loading={saving}>Update Password</Button>
    </Card>
  );
}

function PrivacyTab() {
  const { user, updateUser } = useAuthStore();
  const [form, setForm] = useState({
    privacyProfile: user?.privacyProfile || 'PUBLIC',
    privacyFriendList: user?.privacyFriendList || 'FRIENDS',
    privacyPostDefault: user?.privacyPostDefault || 'FRIENDS',
  });
  const [saving, setSaving] = useState(false);
  const save = async () => {
    setSaving(true);
    try { await userAPI.updateProfile(form); updateUser(form as any); toast.success('Privacy settings saved!'); }
    catch { toast.error('Failed'); }
    setSaving(false);
  };
  const rows = [
    { key: 'privacyProfile', label: 'Who can see your profile?', desc: 'Control who can view your profile.' },
    { key: 'privacyFriendList', label: 'Who can see your friends?', desc: 'Control who sees your friend list.' },
    { key: 'privacyPostDefault', label: 'Default post audience', desc: 'Default audience when you create posts.' },
  ];
  return (
    <Card className="p-6 space-y-4">
      <h2 className="text-lg font-bold">Privacy Settings</h2>
      {rows.map(r => (
        <div key={r.key} className="flex items-center justify-between py-3 border-b border-border last:border-0">
          <div>
            <p className="font-medium text-sm">{r.label}</p>
            <p className="text-xs text-muted-foreground">{r.desc}</p>
          </div>
          <select className="h-9 rounded-xl border border-input bg-background px-2 text-xs outline-none"
            value={(form as any)[r.key]} onChange={e => setForm(f => ({ ...f, [r.key]: e.target.value }))}>
            <option value="PUBLIC">Public</option>
            <option value="FRIENDS">Friends</option>
            <option value="ONLY_ME">Only Me</option>
          </select>
        </div>
      ))}
      <Button onClick={save} loading={saving}>Save Privacy Settings</Button>
    </Card>
  );
}

function NotifTab() {
  const { user, updateUser } = useAuthStore();
  const [form, setForm] = useState({
    notifFriendRequests: user?.notifFriendRequests !== false,
    notifPostLikes: user?.notifPostLikes !== false,
    notifComments: user?.notifComments !== false,
    notifMessages: user?.notifMessages !== false,
    notifGroupActivity: user?.notifGroupActivity !== false,
  });
  const [saving, setSaving] = useState(false);
  const save = async () => {
    setSaving(true);
    try { await userAPI.updateProfile(form); updateUser(form as any); toast.success('Saved!'); }
    catch { toast.error('Failed'); }
    setSaving(false);
  };
  const rows = [
    { key: 'notifFriendRequests', label: 'Friend requests' },
    { key: 'notifPostLikes', label: 'Post reactions' },
    { key: 'notifComments', label: 'Comments on your posts' },
    { key: 'notifMessages', label: 'New messages' },
    { key: 'notifGroupActivity', label: 'Group activity' },
  ];
  return (
    <Card className="p-6 space-y-2">
      <h2 className="text-lg font-bold mb-3">Notification Preferences</h2>
      {rows.map(r => (
        <div key={r.key} className="flex items-center justify-between py-3 border-b border-border last:border-0">
          <p className="font-medium text-sm">{r.label}</p>
          <label className="relative inline-flex items-center cursor-pointer">
            <input type="checkbox" className="sr-only peer" checked={(form as any)[r.key]} onChange={e => setForm(f => ({ ...f, [r.key]: e.target.checked }))} />
            <div className="w-11 h-6 bg-muted peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
          </label>
        </div>
      ))}
      <Button onClick={save} loading={saving} className="mt-3">Save Notifications</Button>
    </Card>
  );
}

function DisplayTab() {
  const { theme, setTheme } = useTheme();
  return (
    <Card className="p-6 space-y-5">
      <h2 className="text-lg font-bold">Display</h2>
      <div className="flex items-center justify-between">
        <div>
          <p className="font-medium text-sm">Dark Mode</p>
          <p className="text-xs text-muted-foreground">Switch between light and dark themes.</p>
        </div>
        <label className="relative inline-flex items-center cursor-pointer">
          <input type="checkbox" className="sr-only peer" checked={theme === 'dark'} onChange={e => setTheme(e.target.checked ? 'dark' : 'light')} />
          <div className="w-11 h-6 bg-muted rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
        </label>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {['light','dark'].map(t => (
          <button key={t} onClick={() => setTheme(t)}
            className={`p-4 rounded-xl border-2 transition-all ${theme === t ? 'border-primary' : 'border-border'}`}
            style={{ background: t === 'dark' ? '#18191a' : '#f0f2f5' }}>
            <div className="h-10 rounded-lg mb-2" style={{ background: t === 'dark' ? '#242526' : '#ffffff' }} />
            <div className="flex items-center gap-2 justify-center">
              {t === 'dark' ? <Moon className="w-3.5 h-3.5 text-white" /> : <Sun className="w-3.5 h-3.5 text-yellow-500" />}
              <span className="text-xs font-semibold capitalize" style={{ color: t === 'dark' ? '#fff' : '#000' }}>{t} Mode</span>
            </div>
          </button>
        ))}
      </div>
    </Card>
  );
}

function VerificationTab() {
  const { user } = useAuthStore();
  const [form, setForm] = useState({ fullName: `${user?.firstName} ${user?.lastName}`, category: 'Public Figure', reason: '' });
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const submit = async () => {
    if (!form.reason.trim()) return toast.error('Please explain why you want verification');
    setLoading(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => fd.append(k, v));
      if (file) fd.append('file', file);
      await verifyAPI.submit(fd);
      toast.success('Verification request submitted!');
    } catch (e: any) { toast.error(e.response?.data?.message || 'Failed'); }
    setLoading(false);
  };
  return (
    <Card className="p-6 space-y-4 max-w-md">
      <div className="flex items-center gap-3">
        <Shield className="w-6 h-6 text-blue-500" />
        <h2 className="text-lg font-bold">Request Verification</h2>
      </div>
      {user?.isVerified ? (
        <div className="flex items-center gap-3 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl">
          <CheckCircle className="w-6 h-6 text-blue-500" />
          <div>
            <p className="font-semibold text-sm">You are verified ✓</p>
            <p className="text-xs text-muted-foreground">Your account has a blue checkmark.</p>
          </div>
        </div>
      ) : (
        <>
          <p className="text-sm text-muted-foreground">Apply for the blue verification badge to show your account is authentic.</p>
          <Input label="Full name" value={form.fullName} onChange={e => setForm(f => ({ ...f, fullName: e.target.value }))} />
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1 block">Category</label>
            <select className="w-full h-10 rounded-xl border border-input bg-background px-3 text-sm outline-none" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
              {['Public Figure','Journalist','Musician','Actor','Athlete','Brand','Business','Other'].map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1 block">Why should you be verified? *</label>
            <Textarea value={form.reason} onChange={e => setForm(f => ({ ...f, reason: e.target.value }))} rows={4} placeholder="Describe why you or your brand deserves verification..." />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1 block">ID / Proof document (optional)</label>
            <input type="file" accept="image/*,.pdf" onChange={e => setFile(e.target.files?.[0] || null)} className="text-sm" />
          </div>
          <Button onClick={submit} loading={loading} className="w-full">Submit Request</Button>
        </>
      )}
    </Card>
  );
}
