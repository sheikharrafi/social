'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, MessageCircle, Share2, Music, Plus, Volume2, VolumeX, Play, Pause } from 'lucide-react';
import { Avatar } from '@/components/ui/index';
import { reelAPI } from '@/lib/api';
import { formatNumber } from '@/lib/utils';
import Link from 'next/link';
import useAuthStore from '@/store/auth.store';
import toast from 'react-hot-toast';

export default function ReelsClient() {
  const { user } = useAuthStore();
  const [reels, setReels] = useState<any[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [muted, setMuted] = useState(false);
  const [paused, setPaused] = useState(false);
  const videoRefs = useRef<Map<number, HTMLVideoElement>>(new Map());
  const containerRef = useRef<HTMLDivElement>(null);
  const loaderRef = useRef<HTMLDivElement>(null);

  const fetchReels = useCallback(async (p: number) => {
    try {
      const { data } = await reelAPI.getAll(p);
      const newReels = data.reels || [];
      setReels(prev => p === 1 ? newReels : [...prev, ...newReels]);
      setHasMore(newReels.length === 10);
      setLoading(false);
    } catch { setLoading(false); }
  }, []);

  useEffect(() => { fetchReels(1); }, []);

  // Pause/play on scroll via IntersectionObserver
  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          const idx = parseInt(entry.target.getAttribute('data-idx') || '0');
          const vid = videoRefs.current.get(idx);
          if (!vid) return;
          if (entry.isIntersecting) {
            setCurrentIdx(idx);
            vid.play().catch(() => {});
            reelAPI.view(reels[idx]?.id).catch(() => {});
          } else {
            vid.pause();
          }
        });
      },
      { threshold: 0.7 }
    );

    document.querySelectorAll('[data-reel]').forEach(el => obs.observe(el));
    return () => obs.disconnect();
  }, [reels]);

  // Infinite scroll
  useEffect(() => {
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && hasMore && !loading) {
        const next = page + 1; setPage(next); fetchReels(next);
      }
    });
    if (loaderRef.current) obs.observe(loaderRef.current);
    return () => obs.disconnect();
  }, [hasMore, loading, page]);

  const handleReact = async (reel: any, idx: number) => {
    setReels(prev => prev.map((r, i) => {
      if (i !== idx) return r;
      const hasLike = r.reactions?.some((x: any) => x.userId === user?.id);
      return {
        ...r,
        reactions: hasLike
          ? r.reactions.filter((x: any) => x.userId !== user?.id)
          : [...(r.reactions || []), { userId: user?.id, type: 'LIKE' }]
      };
    }));
    await reelAPI.react(reel.id, 'LIKE').catch(() => {});
  };

  const togglePlay = (idx: number) => {
    const vid = videoRefs.current.get(idx);
    if (!vid) return;
    if (vid.paused) { vid.play(); setPaused(false); }
    else { vid.pause(); setPaused(true); }
  };

  if (loading) return (
    <div className="flex items-center justify-center h-[calc(100vh-56px)]">
      <div className="w-8 h-8 border-3 border-primary border-t-transparent rounded-full animate-spin" />
    </div>
  );

  if (reels.length === 0) return (
    <div className="flex flex-col items-center justify-center h-[calc(100vh-56px)] text-center px-4">
      <div className="text-6xl mb-4">🎬</div>
      <h2 className="text-xl font-bold mb-2">No Reels Yet</h2>
      <p className="text-muted-foreground">Follow creators to see their reels here.</p>
    </div>
  );

  return (
    <div ref={containerRef} className="h-[calc(100vh-56px)] overflow-y-scroll scrollbar-none snap-y snap-mandatory">
      {reels.map((reel, idx) => {
        const isLiked = reel.reactions?.some((r: any) => r.userId === user?.id);
        return (
          <div key={reel.id} data-reel data-idx={idx}
            className="snap-start relative w-full h-[calc(100vh-56px)] flex items-center justify-center bg-black overflow-hidden">
            {/* Video */}
            <video
              ref={el => { if (el) videoRefs.current.set(idx, el); }}
              src={reel.videoUrl}
              className="w-full h-full object-cover"
              loop
              muted={muted}
              playsInline
              onClick={() => togglePlay(idx)}
            />

            {/* Pause overlay */}
            <AnimatePresence>
              {paused && currentIdx === idx && (
                <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
                  className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="w-20 h-20 rounded-full bg-black/50 flex items-center justify-center">
                    <Pause className="w-10 h-10 text-white" />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Gradient */}
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/70 pointer-events-none" />

            {/* Top controls */}
            <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
              <h2 className="text-white font-bold text-lg">Reels</h2>
              <button onClick={() => setMuted(p => !p)} className="text-white bg-black/40 rounded-full w-9 h-9 flex items-center justify-center">
                {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
            </div>

            {/* Right actions */}
            <div className="absolute right-4 bottom-24 flex flex-col items-center gap-5 z-10">
              <button onClick={() => handleReact(reel, idx)} className="flex flex-col items-center gap-1">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center ${isLiked ? 'bg-rose-500' : 'bg-black/40'}`}>
                  <Heart className={`w-6 h-6 ${isLiked ? 'text-white fill-white' : 'text-white'}`} />
                </div>
                <span className="text-white text-xs font-semibold">{formatNumber(reel.reactions?.length || 0)}</span>
              </button>

              <button className="flex flex-col items-center gap-1">
                <div className="w-12 h-12 rounded-full bg-black/40 flex items-center justify-center">
                  <MessageCircle className="w-6 h-6 text-white" />
                </div>
                <span className="text-white text-xs font-semibold">{formatNumber(reel._count?.comments || 0)}</span>
              </button>

              <button className="flex flex-col items-center gap-1">
                <div className="w-12 h-12 rounded-full bg-black/40 flex items-center justify-center">
                  <Share2 className="w-6 h-6 text-white" />
                </div>
                <span className="text-white text-xs font-semibold">Share</span>
              </button>

              {/* Spinning music disc */}
              <div className="w-10 h-10 rounded-full border-4 border-white/50 overflow-hidden animate-spin"
                style={{ animationDuration: '4s' }}>
                <Avatar src={reel.author?.profilePicture} firstName={reel.author?.firstName} lastName={reel.author?.lastName} size="sm" />
              </div>
            </div>

            {/* Bottom info */}
            <div className="absolute bottom-6 left-4 right-20 z-10">
              <Link href={`/profile/${reel.author?.id}`} className="flex items-center gap-2 mb-2">
                <Avatar src={reel.author?.profilePicture} firstName={reel.author?.firstName} lastName={reel.author?.lastName} size="sm" />
                <span className="text-white font-semibold text-sm">@{reel.author?.username || `${reel.author?.firstName}${reel.author?.lastName}`}</span>
                {reel.author?.isVerified && <span className="text-blue-400 text-xs">✓</span>}
              </Link>
              {reel.caption && <p className="text-white text-sm line-clamp-2 mb-2">{reel.caption}</p>}
              {reel.audioName && (
                <div className="flex items-center gap-2 text-white/80 text-xs">
                  <Music className="w-3 h-3" />
                  <span className="truncate">{reel.audioName}</span>
                </div>
              )}
            </div>
          </div>
        );
      })}
      <div ref={loaderRef} className="h-20 flex items-center justify-center bg-black">
        {loading && <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />}
      </div>
    </div>
  );
}
