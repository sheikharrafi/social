'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import {
  Users, FileText, Flag, Shield, BarChart2, AlertTriangle,
  CheckCircle, XCircle, Clock, TrendingUp, Play, Image, Eye, Star
} from 'lucide-react';
import { Card, Avatar, Badge, Skeleton, EmptyState } from '@/components/ui/index';
import { Button } from '@/components/ui/button';
import { adminAPI, verifyAPI } from '@/lib/api';
import { formatDate, formatNumber } from '@/lib/utils';
import useAuthStore from '@/store/auth.store';
import toast from 'react-hot-toast';

const TABS = ['Overview', 'Users', 'Verification', 'Reports'];

export default function AdminClient() {
  const { user } = useAuthStore();
  const router = useRouter();
  const [tab, setTab] = useState('Overview');
  const [stats, setStats] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [verifications, setVerifications] = useState<any[]>([]);
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [userSearch, setUserSearch] = useState('');
  const [userPage, setUserPage] = useState(1);
  const [totalUsers, setTotalUsers] = useState(0);

  useEffect(() => {
    if (user?.role !== 'ADMIN' && user?.role !== 'MODERATOR') {
      router.push('/');
      return;
    }
    loadAll();
  }, [user]);

  const loadAll = async () => {
    setLoading(true);
    try {
      const [s, v, r] = await Promise.all([
        adminAPI.getStats(),
        verifyAPI.getRequests(),
        adminAPI.getReports(),
      ]);
      setStats(s.data.stats);
      setVerifications(v.data.requests || []);
      setReports(r.data.reports || []);
    } catch {}
    setLoading(false);
  };

  const loadUsers = async (search = '', page = 1) => {
    try {
      const { data } = await adminAPI.getUsers({ search, page, limit: 20 });
      setUsers(data.users || []);
      setTotalUsers(data.total || 0);
    } catch {}
  };

  useEffect(() => {
    if (tab === 'Users') loadUsers(userSearch, userPage);
  }, [tab, userSearch, userPage]);

  const handleVerification = async (id: string, decision: 'APPROVED' | 'REJECTED', note = '') => {
    try {
      await verifyAPI.review(id, decision, note);
      setVerifications(p => p.filter(v => v.id !== id));
      toast.success(`Verification ${decision.toLowerCase()}`);
    } catch { toast.error('Failed'); }
  };

  if (user?.role !== 'ADMIN' && user?.role !== 'MODERATOR') return null;

  const STAT_CARDS = stats ? [
    { label: 'Total Users', value: formatNumber(stats.users), icon: Users, color: 'text-blue-500', bg: 'bg-blue-500/10', delta: `+${stats.newUsersToday} today` },
    { label: 'Total Posts', value: formatNumber(stats.posts), icon: FileText, color: 'text-violet-500', bg: 'bg-violet-500/10', delta: null },
    { label: 'Total Reels', value: formatNumber(stats.reels), icon: Play, color: 'text-rose-500', bg: 'bg-rose-500/10', delta: null },
    { label: 'Active Groups', value: formatNumber(stats.groups), icon: Users, color: 'text-emerald-500', bg: 'bg-emerald-500/10', delta: null },
    { label: 'New This Week', value: formatNumber(stats.newUsersThisWeek), icon: TrendingUp, color: 'text-amber-500', bg: 'bg-amber-500/10', delta: null },
    { label: 'Pending Reports', value: formatNumber(stats.pendingReports), icon: AlertTriangle, color: 'text-destructive', bg: 'bg-destructive/10', delta: null },
  ] : [];

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Admin Dashboard</h1>
          <p className="text-sm text-muted-foreground">Your Social platform management</p>
        </div>
        <Badge variant="warning" className="text-sm px-3 py-1">
          <Shield className="w-3.5 h-3.5" /> {user?.role}
        </Badge>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-border mb-6">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-2.5 text-sm font-semibold border-b-2 -mb-px transition-colors ${tab === t ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`}>
            {t}
            {t === 'Verification' && verifications.length > 0 && (
              <span className="ml-1.5 bg-primary text-primary-foreground text-xs rounded-full px-1.5 py-0.5">{verifications.length}</span>
            )}
            {t === 'Reports' && reports.length > 0 && (
              <span className="ml-1.5 bg-destructive text-destructive-foreground text-xs rounded-full px-1.5 py-0.5">{reports.length}</span>
            )}
          </button>
        ))}
      </div>

      {/* Overview */}
      {tab === 'Overview' && (
        loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-2xl" />)}
          </div>
        ) : (
          <div className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {STAT_CARDS.map((s, i) => (
                <motion.div key={s.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                  <Card className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className={`w-10 h-10 rounded-xl ${s.bg} flex items-center justify-center`}>
                        <s.icon className={`w-5 h-5 ${s.color}`} />
                      </div>
                      {s.delta && <span className="text-xs text-emerald-500 font-semibold">{s.delta}</span>}
                    </div>
                    <p className="text-2xl font-black">{s.value}</p>
                    <p className="text-sm text-muted-foreground">{s.label}</p>
                  </Card>
                </motion.div>
              ))}
            </div>

            {/* Quick actions */}
            <Card className="p-5">
              <h3 className="font-bold mb-4">Quick Actions</h3>
              <div className="flex flex-wrap gap-3">
                <Button variant="outline" size="sm" onClick={() => setTab('Verification')}><Shield className="w-4 h-4" /> Review Verifications ({verifications.length})</Button>
                <Button variant="outline" size="sm" onClick={() => setTab('Reports')}><AlertTriangle className="w-4 h-4" /> Review Reports ({reports.length})</Button>
                <Button variant="outline" size="sm" onClick={() => setTab('Users')}><Users className="w-4 h-4" /> Manage Users</Button>
              </div>
            </Card>
          </div>
        )
      )}

      {/* Users */}
      {tab === 'Users' && (
        <div className="space-y-4">
          <div className="flex gap-3">
            <div className="flex-1 flex items-center gap-2 bg-muted rounded-xl px-3 h-10">
              <input className="bg-transparent text-sm w-full outline-none placeholder:text-muted-foreground"
                placeholder="Search users by name or email..."
                value={userSearch}
                onChange={e => { setUserSearch(e.target.value); setUserPage(1); }}
              />
            </div>
          </div>

          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border bg-muted/50">
                  <tr>
                    {['User', 'Email', 'Role', 'Verified', 'Posts', 'Joined', 'Actions'].map(h => (
                      <th key={h} className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {users.map(u => (
                    <tr key={u.id} className="hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <Avatar src={u.profilePicture} firstName={u.firstName} lastName={u.lastName} size="sm" />
                          <span className="font-medium">{u.firstName} {u.lastName}</span>
                          {u.isVerified && <span className="text-blue-500 text-xs">✓</span>}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{u.email}</td>
                      <td className="px-4 py-3">
                        <Badge variant={u.role === 'ADMIN' ? 'destructive' : u.role === 'MODERATOR' ? 'warning' : 'secondary'} className="text-xs">
                          {u.role}
                        </Badge>
                      </td>
                      <td className="px-4 py-3">
                        {u.emailVerified
                          ? <CheckCircle className="w-4 h-4 text-emerald-500" />
                          : <XCircle className="w-4 h-4 text-muted-foreground" />}
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">{u._count?.posts || 0}</td>
                      <td className="px-4 py-3 text-muted-foreground">{formatDate(u.createdAt)}</td>
                      <td className="px-4 py-3">
                        <Button size="sm" variant="ghost" onClick={() => router.push(`/profile/${u.id}`)}>
                          <Eye className="w-3.5 h-3.5" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {users.length === 0 && (
              <div className="text-center py-8 text-muted-foreground text-sm">No users found</div>
            )}
          </Card>

          {/* Pagination */}
          {totalUsers > 20 && (
            <div className="flex items-center justify-between">
              <p className="text-sm text-muted-foreground">Showing {users.length} of {totalUsers} users</p>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" disabled={userPage === 1} onClick={() => setUserPage(p => p - 1)}>Previous</Button>
                <Button size="sm" variant="outline" disabled={userPage * 20 >= totalUsers} onClick={() => setUserPage(p => p + 1)}>Next</Button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Verification */}
      {tab === 'Verification' && (
        verifications.length === 0 ? (
          <EmptyState icon="✅" title="No pending verifications" description="All verification requests have been reviewed." />
        ) : (
          <div className="space-y-4">
            {verifications.map((v, i) => (
              <motion.div key={v.id} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                <Card className="p-5">
                  <div className="flex items-start gap-4">
                    <Avatar src={v.user?.profilePicture} firstName={v.user?.firstName} lastName={v.user?.lastName} size="lg" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <h3 className="font-bold">{v.fullName}</h3>
                          <p className="text-sm text-muted-foreground">{v.user?.email}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="secondary">{v.category}</Badge>
                            <span className="text-xs text-muted-foreground">{formatDate(v.createdAt)}</span>
                          </div>
                        </div>
                        <Badge variant="warning"><Clock className="w-3 h-3" /> Pending</Badge>
                      </div>
                      <p className="text-sm mt-3 text-muted-foreground bg-muted rounded-xl p-3">{v.reason}</p>
                      {v.proofUrl && (
                        <a href={v.proofUrl} target="_blank" rel="noreferrer" className="text-xs text-primary hover:underline mt-2 block">
                          View proof document →
                        </a>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-3 mt-4 pt-4 border-t border-border">
                    <Button size="sm" className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white border-0"
                      onClick={() => handleVerification(v.id, 'APPROVED')}>
                      <CheckCircle className="w-4 h-4" /> Approve
                    </Button>
                    <Button size="sm" variant="destructive" className="flex-1"
                      onClick={() => handleVerification(v.id, 'REJECTED', 'Does not meet our verification criteria')}>
                      <XCircle className="w-4 h-4" /> Reject
                    </Button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        )
      )}

      {/* Reports */}
      {tab === 'Reports' && (
        reports.length === 0 ? (
          <EmptyState icon="🛡️" title="No pending reports" description="All reports have been reviewed." />
        ) : (
          <div className="space-y-3">
            {reports.map((r, i) => (
              <motion.div key={r.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}>
                <Card className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-xl bg-destructive/10 flex items-center justify-center flex-shrink-0">
                        <Flag className="w-5 h-5 text-destructive" />
                      </div>
                      <div>
                        <p className="font-semibold text-sm">{r.entityType} reported</p>
                        <p className="text-sm text-muted-foreground mt-0.5">{r.reason}</p>
                        {r.description && <p className="text-xs text-muted-foreground mt-1 italic">"{r.description}"</p>}
                        <p className="text-xs text-muted-foreground mt-1">By {r.reporter?.firstName} {r.reporter?.lastName} · {formatDate(r.createdAt)}</p>
                      </div>
                    </div>
                    <div className="flex gap-2 shrink-0">
                      <Button size="sm" variant="outline">Review</Button>
                      <Button size="sm" variant="ghost">Dismiss</Button>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        )
      )}
    </div>
  );
}
