'use client';
import { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { useTheme } from 'next-themes';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Home, Users, ShoppingBag, Tv2, Bell, MessageCircle, Search,
  Sun, Moon, LogOut, Settings, User, Bookmark, ChevronDown, Menu, X,
  UsersRound, Flag, Play, Calendar,
} from 'lucide-react';
import useAuthStore from '@/store/auth.store';
import { Avatar, Badge } from '@/components/ui/index';
import { Button } from '@/components/ui/button';
import { searchAPI } from '@/lib/api';
import { cn } from '@/lib/utils';

const NAV_LINKS = [
  { href: '/', icon: Home, label: 'Home' },
  { href: '/friends', icon: Users, label: 'Friends' },
  { href: '/groups', icon: UsersRound, label: 'Groups' },
  { href: '/marketplace', icon: ShoppingBag, label: 'Market' },
  { href: '/watch', icon: Tv2, label: 'Watch' },
  { href: '/reels', icon: Play, label: 'Reels' },
  { href: '/events', icon: Calendar, label: 'Events' },
];

export default function Navbar() {
  const { user, logout } = useAuthStore();
  const { theme, setTheme } = useTheme();
  const router = useRouter();
  const pathname = usePathname();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any>(null);
  const [showMenu, setShowMenu] = useState(false);
  const [showMobile, setShowMobile] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) setResults(null);
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setShowMenu(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  useEffect(() => {
    if (!query.trim()) { setResults(null); return; }
    const t = setTimeout(async () => {
      try { const { data } = await searchAPI.search(query); setResults(data); } catch {}
    }, 350);
    return () => clearTimeout(t);
  }, [query]);

  const handleSearch = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && query.trim()) { router.push(`/search?q=${encodeURIComponent(query)}`); setResults(null); }
  };

  const fullName = user ? `${user.firstName} ${user.lastName}` : '';

  return (
    <header className="fixed top-0 left-0 right-0 z-50 h-14 glass border-b border-border/50">
      <div className="flex items-center h-full px-4 gap-2 max-w-screen-2xl mx-auto">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-1.5 min-w-[140px] flex-shrink-0">
          <div className="w-9 h-9 rounded-xl gradient-brand flex items-center justify-center">
            <span className="text-white font-black text-lg">Y</span>
          </div>
          <span className="font-black text-lg hidden sm:block gradient-text">YourSocial</span>
        </Link>

        {/* Search */}
        <div ref={searchRef} className="relative flex-1 max-w-xs hidden md:block">
          <div className="flex items-center gap-2 bg-muted rounded-xl px-3 h-9">
            <Search className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            <input
              className="bg-transparent text-sm w-full outline-none placeholder:text-muted-foreground"
              placeholder="Search YourSocial..."
              value={query}
              onChange={e => setQuery(e.target.value)}
              onKeyDown={handleSearch}
            />
          </div>
          <AnimatePresence>
            {results && (
              <motion.div
                initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 6 }}
                className="absolute top-full mt-2 left-0 w-80 bg-popover border border-border rounded-2xl shadow-xl overflow-hidden z-50"
              >
                {results.users?.slice(0, 5).map((u: any) => (
                  <button key={u.id} onClick={() => { router.push(`/profile/${u.id}`); setResults(null); setQuery(''); }}
                    className="flex items-center gap-3 w-full px-4 py-2.5 hover:bg-muted text-left transition-colors">
                    <Avatar src={u.profilePicture} firstName={u.firstName} lastName={u.lastName} size="sm" />
                    <div>
                      <p className="text-sm font-semibold">{u.firstName} {u.lastName}</p>
                      {u.username && <p className="text-xs text-muted-foreground">@{u.username}</p>}
                    </div>
                  </button>
                ))}
                {results.groups?.slice(0, 3).map((g: any) => (
                  <button key={g.id} onClick={() => { router.push(`/groups/${g.id}`); setResults(null); setQuery(''); }}
                    className="flex items-center gap-3 w-full px-4 py-2.5 hover:bg-muted text-left transition-colors">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center"><UsersRound className="w-4 h-4 text-primary" /></div>
                    <p className="text-sm font-semibold">{g.name}</p>
                  </button>
                ))}
                {!results.users?.length && !results.groups?.length && (
                  <p className="text-sm text-muted-foreground text-center py-4">No results found</p>
                )}
                <div className="border-t border-border px-4 py-2">
                  <button onClick={() => { router.push(`/search?q=${query}`); setResults(null); }}
                    className="text-sm text-primary font-medium hover:underline">
                    See all results for "{query}"
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Nav links — desktop */}
        <nav className="hidden md:flex items-center gap-1 flex-1 justify-center">
          {NAV_LINKS.map(l => {
            const active = pathname === l.href || (l.href !== '/' && pathname.startsWith(l.href));
            return (
              <Link key={l.href} href={l.href}
                className={cn('flex items-center justify-center w-20 h-10 rounded-xl transition-all duration-150 relative group',
                  active ? 'text-primary' : 'text-muted-foreground hover:text-foreground hover:bg-muted')}
              >
                <l.icon className={cn('w-5 h-5 transition-transform group-hover:scale-110', active && 'scale-110')} />
                {active && <motion.div layoutId="nav-indicator" className="absolute bottom-1 left-1/2 -translate-x-1/2 w-5 h-0.5 bg-primary rounded-full" />}
              </Link>
            );
          })}
        </nav>

        {/* Actions */}
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <Button variant="ghost" size="icon-sm" className="hidden md:flex" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </Button>

          <Link href="/messages">
            <Button variant="ghost" size="icon-sm" className="hidden md:flex relative">
              <MessageCircle className="w-4 h-4" />
            </Button>
          </Link>

          <Link href="/notifications">
            <Button variant="ghost" size="icon-sm" className="hidden md:flex relative">
              <Bell className="w-4 h-4" />
            </Button>
          </Link>

          {/* User menu */}
          <div ref={menuRef} className="relative">
            <button onClick={() => setShowMenu(p => !p)} className="flex items-center gap-1.5 hover:bg-muted rounded-xl px-2 py-1 transition-colors">
              <Avatar src={user?.profilePicture} firstName={user?.firstName} lastName={user?.lastName} size="sm" />
              <ChevronDown className="w-3 h-3 text-muted-foreground hidden sm:block" />
            </button>

            <AnimatePresence>
              {showMenu && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, y: 4 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: 4 }}
                  className="absolute right-0 top-full mt-2 w-72 bg-popover border border-border rounded-2xl shadow-xl overflow-hidden z-50"
                >
                  <Link href={`/profile/${user?.id}`} onClick={() => setShowMenu(false)}
                    className="flex items-center gap-3 p-4 hover:bg-muted transition-colors border-b border-border">
                    <Avatar src={user?.profilePicture} firstName={user?.firstName} lastName={user?.lastName} size="md" />
                    <div>
                      <p className="font-semibold text-sm">{fullName}</p>
                      <p className="text-xs text-muted-foreground">{user?.email}</p>
                    </div>
                  </Link>
                  {[
                    { href: '/saved', icon: Bookmark, label: 'Saved Posts' },
                    { href: '/pages', icon: Flag, label: 'Pages' },
                    { href: '/settings', icon: Settings, label: 'Settings' },
                  ].map(item => (
                    <Link key={item.href} href={item.href} onClick={() => setShowMenu(false)}
                      className="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors">
                      <item.icon className="w-4 h-4 text-muted-foreground" />
                      {item.label}
                    </Link>
                  ))}
                  <button onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                    className="flex items-center gap-3 px-4 py-2.5 text-sm hover:bg-muted transition-colors w-full">
                    {theme === 'dark' ? <Sun className="w-4 h-4 text-muted-foreground" /> : <Moon className="w-4 h-4 text-muted-foreground" />}
                    {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
                  </button>
                  <div className="border-t border-border">
                    <button onClick={async () => { setShowMenu(false); await logout(); router.push('/login'); }}
                      className="flex items-center gap-3 px-4 py-2.5 text-sm text-destructive hover:bg-destructive/10 transition-colors w-full">
                      <LogOut className="w-4 h-4" /> Log Out
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Mobile menu button */}
          <Button variant="ghost" size="icon-sm" className="md:hidden" onClick={() => setShowMobile(p => !p)}>
            {showMobile ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </Button>
        </div>
      </div>

      {/* Mobile nav */}
      <AnimatePresence>
        {showMobile && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
            className="md:hidden border-t border-border bg-background px-4 py-3">
            <div className="flex items-center gap-2 bg-muted rounded-xl px-3 h-9 mb-3">
              <Search className="w-4 h-4 text-muted-foreground" />
              <input className="bg-transparent text-sm w-full outline-none placeholder:text-muted-foreground" placeholder="Search..." value={query} onChange={e => setQuery(e.target.value)} onKeyDown={handleSearch} />
            </div>
            <div className="grid grid-cols-5 gap-1">
              {NAV_LINKS.map(l => {
                const active = pathname === l.href || (l.href !== '/' && pathname.startsWith(l.href));
                return (
                  <Link key={l.href} href={l.href} onClick={() => setShowMobile(false)}
                    className={cn('flex flex-col items-center gap-1 py-2 rounded-xl transition-colors', active ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-muted')}>
                    <l.icon className="w-5 h-5" />
                    <span className="text-[10px] font-medium">{l.label}</span>
                  </Link>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
