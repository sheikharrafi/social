'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Home, Users, UsersRound, ShoppingBag, Tv2, Play, Flag,
  Bookmark, Calendar, Gamepad2, Clock, Star, ChevronDown, ChevronUp, Shield
} from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/utils';
import { Avatar } from '@/components/ui/index';
import useAuthStore from '@/store/auth.store';

const PRIMARY_LINKS = [
  { href: '/', icon: Home, label: 'Home', exact: true },
  { href: '/friends', icon: Users, label: 'Friends' },
  { href: '/groups', icon: UsersRound, label: 'Groups' },
  { href: '/marketplace', icon: ShoppingBag, label: 'Marketplace' },
  { href: '/watch', icon: Tv2, label: 'Watch' },
  { href: '/reels', icon: Play, label: 'Reels' },
  { href: '/events', icon: Calendar, label: 'Events' },
  { href: '/gaming', icon: Gamepad2, label: 'Gaming' },
];

const MORE_LINKS = [
  { href: '/pages', icon: Flag, label: 'Pages' },
  { href: '/saved', icon: Bookmark, label: 'Saved' },
  { href: '/memories', icon: Clock, label: 'Memories' },
];

function SidebarLink({ href, icon: Icon, label, exact = false }: { href: string; icon: any; label: string; exact?: boolean }) {
  const pathname = usePathname();
  const active = exact ? pathname === href : pathname.startsWith(href);
  return (
    <Link href={href}
      className={cn(
        'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150',
        active
          ? 'bg-primary/10 text-primary font-semibold'
          : 'text-muted-foreground hover:text-foreground hover:bg-muted'
      )}>
      <Icon className={cn('w-5 h-5 flex-shrink-0', active && 'text-primary')} />
      {label}
    </Link>
  );
}

export default function LeftSidebar() {
  const { user } = useAuthStore();
  const [showMore, setShowMore] = useState(false);
  const fullName = user ? `${user.firstName} ${user.lastName}` : '';

  return (
    <aside className="fixed left-0 top-14 h-[calc(100vh-56px)] w-64 hidden lg:flex flex-col overflow-y-auto py-3 px-2 border-r border-border/50 scrollbar-none">
      {/* Profile */}
      <Link href={`/profile/${user?.id}`}
        className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-muted transition-colors mb-1 group">
        <Avatar src={user?.profilePicture} firstName={user?.firstName} lastName={user?.lastName} size="sm" />
        <span className="font-semibold text-sm truncate group-hover:text-primary transition-colors">{fullName}</span>
      </Link>

      <div className="space-y-0.5">
        {PRIMARY_LINKS.map(l => (
          <SidebarLink key={l.href} {...l} />
        ))}

        {/* More / Less toggle */}
        <button onClick={() => setShowMore(p => !p)}
          className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-colors w-full">
          <div className="w-5 h-5 rounded-full bg-muted-foreground/20 flex items-center justify-center flex-shrink-0">
            {showMore ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </div>
          {showMore ? 'See less' : 'See more'}
        </button>

        {showMore && MORE_LINKS.map(l => (
          <SidebarLink key={l.href} {...l} />
        ))}

        {/* Admin link (only for admin/moderator) */}
        {(user?.role === 'ADMIN' || user?.role === 'MODERATOR') && (
          <>
            <div className="h-px bg-border mx-3 my-1" />
            <SidebarLink href="/admin" icon={Shield} label="Admin Dashboard" />
          </>
        )}
      </div>

      {/* Footer */}
      <div className="mt-auto px-3 pt-4">
        <p className="text-[11px] text-muted-foreground leading-relaxed">
          Privacy · Terms · Advertising · Cookies · More · <span className="font-medium">Your Social © 2025</span>
        </p>
      </div>
    </aside>
  );
}
