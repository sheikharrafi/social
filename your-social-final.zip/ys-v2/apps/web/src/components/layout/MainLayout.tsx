'use client';
import { usePathname } from 'next/navigation';
import Navbar from './Navbar';
import LeftSidebar from './LeftSidebar';
import RightSidebar from './RightSidebar';
import { SocketProvider } from '@/lib/socket';

const FULL_WIDTH = ['/messages', '/watch', '/marketplace', '/reels', '/admin'];

export default function MainLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const isFull = FULL_WIDTH.some(r => pathname.startsWith(r));

  return (
    <SocketProvider>
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex pt-14">
          {!isFull && <LeftSidebar />}
          <main className={`flex-1 min-w-0 ${!isFull ? 'lg:ml-64 xl:mr-80' : ''}`}>
            {children}
          </main>
          {!isFull && <RightSidebar />}
        </div>
      </div>
    </SocketProvider>
  );
}
