'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Cake } from 'lucide-react';
import { Avatar, Skeleton } from '@/components/ui/index';
import { userAPI } from '@/lib/api';
import useAuthStore from '@/store/auth.store';
import { useSocket } from '@/lib/socket';

export default function RightSidebar() {
  const { user } = useAuthStore();
  const { isOnline } = useSocket();
  const [birthdays, setBirthdays] = useState<any[]>([]);
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      userAPI.getBirthdays().then(r => setBirthdays(r.data.birthdays || [])),
      userAPI.getSuggestions().then(r => setSuggestions(r.data.suggestions || [])),
    ]).finally(() => setLoading(false));
  }, []);

  const friends = (user as any)?.friends || [];

  return (
    <aside className="fixed right-0 top-14 h-[calc(100vh-56px)] w-80 hidden xl:flex flex-col overflow-y-auto py-4 px-3 scrollbar-none">
      {/* Birthdays */}
      {birthdays.length > 0 && (
        <div className="mb-5">
          <h4 className="text-sm font-semibold text-muted-foreground mb-2 px-1">Birthdays</h4>
          {birthdays.map(b => (
            <div key={b.id} className="flex items-center gap-3 px-2 py-2 rounded-xl hover:bg-muted transition-colors">
              <Cake className="w-8 h-8 text-amber-500 flex-shrink-0" />
              <p className="text-sm"><span className="font-semibold">{b.firstName}</span>'s birthday is today 🎂</p>
            </div>
          ))}
        </div>
      )}

      {/* People you may know */}
      {suggestions.length > 0 && (
        <div className="mb-5">
          <h4 className="text-sm font-semibold text-muted-foreground mb-2 px-1">People You May Know</h4>
          {loading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex items-center gap-3 px-2 py-2">
                <Skeleton className="w-9 h-9 rounded-full" />
                <div className="flex-1"><Skeleton className="h-3 w-24 mb-1" /><Skeleton className="h-3 w-16" /></div>
              </div>
            ))
          ) : suggestions.slice(0, 5).map(s => (
            <Link key={s.id} href={`/profile/${s.id}`}
              className="flex items-center gap-3 px-2 py-2 rounded-xl hover:bg-muted transition-colors">
              <Avatar src={s.profilePicture} firstName={s.firstName} lastName={s.lastName} size="sm" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate">{s.firstName} {s.lastName}</p>
                <p className="text-xs text-muted-foreground">{s._count?.followers || 0} followers</p>
              </div>
            </Link>
          ))}
        </div>
      )}

      {/* Online contacts */}
      <div>
        <h4 className="text-sm font-semibold text-muted-foreground mb-2 px-1">Contacts</h4>
        {loading ? (
          Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="flex items-center gap-3 px-2 py-2">
              <Skeleton className="w-9 h-9 rounded-full" />
              <Skeleton className="h-3 w-28" />
            </div>
          ))
        ) : friends.length === 0 ? (
          <p className="text-sm text-muted-foreground px-2">Add friends to see them here.</p>
        ) : friends.map((f: any) => (
          <Link key={f.id} href={`/messages?userId=${f.id}`}
            className="flex items-center gap-3 px-2 py-2 rounded-xl hover:bg-muted transition-colors">
            <Avatar src={f.profilePicture} firstName={f.firstName} lastName={f.lastName} size="sm" online={isOnline(f.id)} />
            <span className="text-sm font-medium truncate">{f.firstName} {f.lastName}</span>
          </Link>
        ))}
      </div>
    </aside>
  );
}
