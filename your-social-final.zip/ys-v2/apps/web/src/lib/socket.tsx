'use client';
import { createContext, useContext, useEffect, useRef, useState } from 'react';
import { io, Socket } from 'socket.io-client';
import useAuthStore from '@/store/auth.store';

interface SocketCtx {
  socket: Socket | null;
  onlineUsers: Set<string>;
  isOnline: (userId: string) => boolean;
}

const Context = createContext<SocketCtx>({ socket: null, onlineUsers: new Set(), isOnline: () => false });

export function SocketProvider({ children }: { children: React.ReactNode }) {
  const { user, isAuthenticated } = useAuthStore();
  const socketRef = useRef<Socket | null>(null);
  const [onlineUsers, setOnlineUsers] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!isAuthenticated || !user) return;

    const socket = io(process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:5000', {
      withCredentials: true,
      transports: ['websocket', 'polling'],
    });
    socketRef.current = socket;

    socket.on('connect', () => socket.emit('user_online', user.id));

    socket.on('user_status', ({ userId, isOnline }: any) => {
      setOnlineUsers(prev => {
        const next = new Set(prev);
        isOnline ? next.add(userId) : next.delete(userId);
        return next;
      });
    });

    return () => { socket.disconnect(); socketRef.current = null; };
  }, [isAuthenticated, user?.id]);

  return (
    <Context.Provider value={{ socket: socketRef.current, onlineUsers, isOnline: (id) => onlineUsers.has(id) }}>
      {children}
    </Context.Provider>
  );
}

export const useSocket = () => useContext(Context);
