import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

export const api = axios.create({
  baseURL: API_URL,
  withCredentials: true,
  timeout: 30000,
});

api.interceptors.request.use((config) => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('ys_token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (error) => {
    if (error.response?.status === 401 && typeof window !== 'undefined') {
      localStorage.removeItem('ys_token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth
export const authAPI = {
  register: (d: any) => api.post('/auth/register', d),
  login: (d: any) => api.post('/auth/login', d),
  logout: () => api.post('/auth/logout'),
  getMe: () => api.get('/auth/me'),
  verifyEmail: (token: string) => api.post('/auth/verify-email', { token }),
  forgotPassword: (email: string) => api.post('/auth/forgot-password', { email }),
  resetPassword: (d: any) => api.post('/auth/reset-password', d),
};

// Users
export const userAPI = {
  getProfile: (id: string) => api.get(`/users/${id}`),
  updateProfile: (d: any) => api.put('/users/profile', d),
  changePassword: (d: any) => api.put('/users/password', d),
  uploadAvatar: (f: File) => { const fd = new FormData(); fd.append('file', f); return api.post('/users/avatar', fd); },
  uploadCover: (f: File) => { const fd = new FormData(); fd.append('file', f); return api.post('/users/cover', fd); },
  getFriends: (id: string) => api.get(`/users/${id}/friends`),
  getPhotos: (id: string) => api.get(`/users/${id}/photos`),
  getBirthdays: () => api.get('/users/birthdays'),
  getSuggestions: () => api.get('/users/suggestions'),
  getAnalytics: () => api.get('/users/analytics'),
  block: (id: string) => api.post(`/users/${id}/block`),
  unblock: (id: string) => api.delete(`/users/${id}/block`),
};

// Posts
export const postAPI = {
  getFeed: (p = 1) => api.get(`/posts/feed?page=${p}`),
  getUserPosts: (id: string, p = 1) => api.get(`/posts/user/${id}?page=${p}`),
  getPost: (id: string) => api.get(`/posts/${id}`),
  createPost: (fd: FormData) => api.post('/posts', fd),
  updatePost: (id: string, d: any) => api.put(`/posts/${id}`, d),
  deletePost: (id: string) => api.delete(`/posts/${id}`),
  react: (id: string, type: string) => api.post(`/posts/${id}/react`, { type }),
  share: (id: string, d: any) => api.post(`/posts/${id}/share`, d),
  save: (id: string) => api.post(`/posts/${id}/save`),
  getSaved: (p = 1) => api.get(`/posts/saved?page=${p}`),
  votePoll: (optionId: string) => api.post('/posts/poll/vote', { optionId }),
};

// Comments
export const commentAPI = {
  get: (postId: string, p = 1) => api.get(`/comments/${postId}?page=${p}`),
  create: (d: any) => api.post('/comments', d),
  update: (id: string, content: string) => api.put(`/comments/${id}`, { content }),
  delete: (id: string) => api.delete(`/comments/${id}`),
  react: (id: string, type: string) => api.post(`/comments/${id}/react`, { type }),
  getReplies: (id: string, p = 1) => api.get(`/comments/${id}/replies?page=${p}`),
};

// Friends
export const friendAPI = {
  getRequests: () => api.get('/friends/requests'),
  send: (id: string) => api.post(`/friends/request/${id}`),
  accept: (id: string) => api.post(`/friends/accept/${id}`),
  decline: (id: string) => api.post(`/friends/decline/${id}`),
  cancel: (id: string) => api.delete(`/friends/cancel/${id}`),
  unfriend: (id: string) => api.delete(`/friends/unfriend/${id}`),
  follow: (id: string) => api.post(`/friends/follow/${id}`),
};

// Messages
export const messageAPI = {
  getConversations: () => api.get('/messages/conversations'),
  getOrCreate: (userId: string) => api.get(`/messages/conversations/${userId}`),
  getMessages: (id: string, p = 1) => api.get(`/messages/${id}?page=${p}`),
  send: (id: string, d: any) => api.post(`/messages/${id}`, d),
  edit: (id: string, content: string) => api.put(`/messages/${id}`, { content }),
  delete: (id: string, forEveryone = false) => api.delete(`/messages/${id}`, { data: { forEveryone } }),
  react: (id: string, emoji: string) => api.post(`/messages/${id}/react`, { emoji }),
  markSeen: (id: string) => api.post(`/messages/${id}/seen`),
  createGroup: (d: any) => api.post('/messages/group', d),
};

// Stories
export const storyAPI = {
  getAll: () => api.get('/stories'),
  create: (fd: FormData) => api.post('/stories', fd),
  view: (id: string) => api.post(`/stories/${id}/view`),
  react: (id: string, emoji: string) => api.post(`/stories/${id}/react`, { emoji }),
  delete: (id: string) => api.delete(`/stories/${id}`),
};

// Reels
export const reelAPI = {
  getAll: (p = 1) => api.get(`/reels?page=${p}`),
  create: (fd: FormData) => api.post('/reels', fd),
  view: (id: string) => api.post(`/reels/${id}/view`),
  react: (id: string, type: string) => api.post(`/reels/${id}/react`, { type }),
  delete: (id: string) => api.delete(`/reels/${id}`),
};

// Notifications
export const notifAPI = {
  getAll: (p = 1) => api.get(`/notifications?page=${p}`),
  readAll: () => api.put('/notifications/read-all'),
  readOne: (id: string) => api.put(`/notifications/${id}/read`),
  delete: (id: string) => api.delete(`/notifications/${id}`),
};

// Groups
export const groupAPI = {
  getMy: () => api.get('/groups'),
  discover: () => api.get('/groups/discover'),
  create: (d: any) => api.post('/groups', d),
  get: (id: string) => api.get(`/groups/${id}`),
  join: (id: string) => api.post(`/groups/${id}/join`),
  leave: (id: string) => api.post(`/groups/${id}/leave`),
  getPosts: (id: string, p = 1) => api.get(`/groups/${id}/posts?page=${p}`),
};

// Pages
export const pageAPI = {
  getMy: () => api.get('/pages'),
  create: (d: any) => api.post('/pages', d),
  get: (id: string) => api.get(`/pages/${id}`),
  like: (id: string) => api.post(`/pages/${id}/like`),
};

// Marketplace
export const marketAPI = {
  getAll: (p: any) => api.get('/marketplace', { params: p }),
  getMy: () => api.get('/marketplace/my'),
  get: (id: string) => api.get(`/marketplace/${id}`),
  create: (fd: FormData) => api.post('/marketplace', fd),
  update: (id: string, d: any) => api.put(`/marketplace/${id}`, d),
  delete: (id: string) => api.delete(`/marketplace/${id}`),
};

// Search
export const searchAPI = {
  search: (q: string, type = 'all', p = 1) => api.get(`/search?q=${q}&type=${type}&page=${p}`),
  trending: () => api.get('/trending'),
};

// Upload
export const uploadAPI = {
  single: (file: File, folder?: string) => {
    const fd = new FormData();
    fd.append('file', file);
    if (folder) fd.append('folder', folder);
    return api.post('/upload/single', fd);
  },
  multiple: (files: File[]) => {
    const fd = new FormData();
    files.forEach(f => fd.append('files', f));
    return api.post('/upload/multiple', fd);
  },
};

// Verification
export const verifyAPI = {
  submit: (fd: FormData) => api.post('/verification/submit', fd),
  getRequests: () => api.get('/admin/verification'),
  review: (id: string, decision: string, note?: string) => api.post(`/admin/verification/${id}`, { decision, note }),
};

// Admin
export const adminAPI = {
  getStats: () => api.get('/admin/stats'),
  getUsers: (p: any) => api.get('/admin/users', { params: p }),
  getReports: () => api.get('/admin/reports'),
};

// Events
export const eventAPI = {
  getAll: (params?: any) => api.get('/events', { params }),
  getMy: () => api.get('/events/my'),
  create: (d: any) => api.post('/events', d),
  get: (id: string) => api.get(`/events/${id}`),
  update: (id: string, d: any) => api.put(`/events/${id}`, d),
  delete: (id: string) => api.delete(`/events/${id}`),
  rsvp: (id: string, rsvp: string) => api.post(`/events/${id}/rsvp`, { rsvp }),
};
