import { Request, Response, NextFunction } from 'express';
import { verifyToken } from '../lib/jwt';
import prisma from '../lib/prisma';
import { unauthorized, AppError } from '../lib/errors';

export interface AuthRequest extends Request {
  user?: {
    id: string;
    email: string;
    role: string;
    firstName: string;
    lastName: string;
    profilePicture: string | null;
    username: string | null;
    isVerified: boolean;
  };
  io?: any;
}

const USER_SELECT = {
  id: true, email: true, role: true, firstName: true,
  lastName: true, profilePicture: true, username: true, isVerified: true,
};

export async function protect(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const auth = req.headers.authorization;
    if (!auth?.startsWith('Bearer ')) return next(unauthorized('No token provided'));
    const token = auth.split(' ')[1];
    const decoded = verifyToken(token);
    const user = await prisma.user.findUnique({ where: { id: decoded.id }, select: USER_SELECT });
    if (!user) return next(unauthorized('User not found'));
    req.user = user as any;
    next();
  } catch (err: any) {
    if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
      return next(unauthorized('Invalid or expired token'));
    }
    next(err);
  }
}

export function adminOnly(req: AuthRequest, res: Response, next: NextFunction) {
  if (req.user?.role !== 'ADMIN' && req.user?.role !== 'MODERATOR') {
    return next(new AppError('Admin access required', 403));
  }
  next();
}

export async function optionalAuth(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const auth = req.headers.authorization;
    if (!auth?.startsWith('Bearer ')) return next();
    const token = auth.split(' ')[1];
    const decoded = verifyToken(token);
    const user = await prisma.user.findUnique({ where: { id: decoded.id }, select: USER_SELECT });
    if (user) req.user = user as any;
    next();
  } catch {
    next(); // silently ignore - optional auth
  }
}
