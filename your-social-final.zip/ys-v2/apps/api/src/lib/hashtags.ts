import prisma from './prisma';

export function extractHashtags(text: string): string[] {
  const matches = text.match(/#[\w\u0980-\u09FF]+/g) || [];
  return [...new Set(matches.map(t => t.slice(1).toLowerCase()))];
}

export async function syncHashtags(entityId: string, entityType: 'post' | 'reel', text: string) {
  const tags = extractHashtags(text);
  if (!tags.length) return;

  for (const name of tags) {
    const hashtag = await prisma.hashtag.upsert({
      where: { name },
      create: { name, postCount: 1 },
      update: { postCount: { increment: 1 } },
    });

    if (entityType === 'post') {
      await prisma.postHashtag.upsert({
        where: { postId_hashtagId: { postId: entityId, hashtagId: hashtag.id } },
        create: { postId: entityId, hashtagId: hashtag.id },
        update: {},
      });
    } else {
      await prisma.reelHashtag.upsert({
        where: { reelId_hashtagId: { reelId: entityId, hashtagId: hashtag.id } },
        create: { reelId: entityId, hashtagId: hashtag.id },
        update: {},
      });
    }
  }
}
