import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);
const FROM = process.env.FROM_EMAIL || 'noreply@yoursocial.app';
const APP_URL = process.env.CLIENT_URL || 'http://localhost:3000';

export async function sendVerificationEmail(email: string, token: string, name: string) {
  const link = `${APP_URL}/verify-email?token=${token}`;
  return resend.emails.send({
    from: FROM,
    to: email,
    subject: 'Verify your Your Social account',
    html: `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto;">
        <h1 style="color:#1877f2">Welcome to Your Social, ${name}! 👋</h1>
        <p>Please verify your email address to get started.</p>
        <a href="${link}" style="display:inline-block;background:#1877f2;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:bold;margin:16px 0;">
          Verify Email
        </a>
        <p style="color:#888;font-size:12px;">This link expires in 24 hours. If you didn't create an account, please ignore this email.</p>
      </div>
    `,
  });
}

export async function sendPasswordResetEmail(email: string, token: string, name: string) {
  const link = `${APP_URL}/reset-password?token=${token}`;
  return resend.emails.send({
    from: FROM,
    to: email,
    subject: 'Reset your Your Social password',
    html: `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto;">
        <h1 style="color:#1877f2">Password Reset Request</h1>
        <p>Hi ${name}, click the button below to reset your password.</p>
        <a href="${link}" style="display:inline-block;background:#e41e3f;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:bold;margin:16px 0;">
          Reset Password
        </a>
        <p style="color:#888;font-size:12px;">This link expires in 1 hour. If you didn't request this, please ignore this email.</p>
      </div>
    `,
  });
}

export async function sendNotificationEmail(email: string, message: string, link: string) {
  return resend.emails.send({
    from: FROM,
    to: email,
    subject: 'New notification on Your Social',
    html: `
      <div style="font-family:sans-serif;max-width:600px;margin:0 auto;">
        <h2 style="color:#1877f2">Your Social</h2>
        <p>${message}</p>
        <a href="${link}" style="display:inline-block;background:#1877f2;color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none;">
          View
        </a>
      </div>
    `,
  });
}
