import { Server } from 'socket.io';
import prisma from '../lib/prisma';

const onlineUsers = new Map<string, string>(); // userId -> socketId

export function initSocket(io: Server) {
  io.on('connection', (socket) => {
    console.log(`🔌 Socket connected: ${socket.id}`);

    socket.on('user_online', async (userId: string) => {
      if (!userId) return;
      onlineUsers.set(userId, socket.id);
      (socket as any).userId = userId;
      socket.join(userId);

      await prisma.user.update({ where: { id: userId }, data: { isOnline: true, lastSeen: new Date() } }).catch(() => {});
      io.emit('user_status', { userId, isOnline: true });
    });

    socket.on('join_post', (postId: string) => socket.join(`post:${postId}`));
    socket.on('leave_post', (postId: string) => socket.leave(`post:${postId}`));

    socket.on('join_conversation', (convId: string) => socket.join(`conv:${convId}`));
    socket.on('leave_conversation', (convId: string) => socket.leave(`conv:${convId}`));

    socket.on('typing_start', ({ conversationId, userId }: { conversationId: string; userId: string }) => {
      socket.to(`conv:${conversationId}`).emit('typing_start', { userId, conversationId });
    });

    socket.on('typing_stop', ({ conversationId, userId }: { conversationId: string; userId: string }) => {
      socket.to(`conv:${conversationId}`).emit('typing_stop', { userId, conversationId });
    });

    // WebRTC signaling
    socket.on('call_user', ({ targetUserId, signal, callerInfo, callType }: any) => {
      const targetSocket = onlineUsers.get(targetUserId);
      if (targetSocket) {
        io.to(targetSocket).emit('incoming_call', { signal, callerInfo, callType, callerSocketId: socket.id });
      }
    });

    socket.on('accept_call', ({ callerSocketId, signal }: any) => {
      io.to(callerSocketId).emit('call_accepted', { signal });
    });

    socket.on('reject_call', ({ callerSocketId }: any) => {
      io.to(callerSocketId).emit('call_rejected');
    });

    socket.on('end_call', ({ targetUserId }: any) => {
      const targetSocket = onlineUsers.get(targetUserId);
      if (targetSocket) io.to(targetSocket).emit('call_ended');
    });

    socket.on('ice_candidate', ({ targetSocketId, candidate }: any) => {
      io.to(targetSocketId).emit('ice_candidate', { candidate });
    });

    socket.on('disconnect', async () => {
      const userId = (socket as any).userId;
      if (userId) {
        onlineUsers.delete(userId);
        await prisma.user.update({ where: { id: userId }, data: { isOnline: false, lastSeen: new Date() } }).catch(() => {});
        io.emit('user_status', { userId, isOnline: false, lastSeen: new Date() });
      }
      console.log(`🔌 Disconnected: ${socket.id}`);
    });
  });
}

export function getSocketId(userId: string) {
  return onlineUsers.get(userId);
}
