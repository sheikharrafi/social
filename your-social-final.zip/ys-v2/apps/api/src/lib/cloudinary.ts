import { v2 as cloudinary } from 'cloudinary';
import streamifier from 'streamifier';

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME!,
  api_key: process.env.CLOUDINARY_API_KEY!,
  api_secret: process.env.CLOUDINARY_API_SECRET!,
  secure: true,
});

export type UploadResult = {
  url: string;
  publicId: string;
  width?: number;
  height?: number;
  duration?: number;
  format?: string;
};

export async function uploadFromBuffer(
  buffer: Buffer,
  options: {
    folder?: string;
    resourceType?: 'image' | 'video' | 'auto' | 'raw';
    transformation?: object[];
    publicId?: string;
  } = {}
): Promise<UploadResult> {
  return new Promise((resolve, reject) => {
    const { folder = 'your-social', resourceType = 'auto', transformation, publicId } = options;

    const uploadStream = cloudinary.uploader.upload_stream(
      {
        folder,
        resource_type: resourceType,
        transformation,
        public_id: publicId,
        overwrite: true,
      },
      (error, result) => {
        if (error) return reject(error);
        resolve({
          url: result!.secure_url,
          publicId: result!.public_id,
          width: result!.width,
          height: result!.height,
          duration: result!.duration,
          format: result!.format,
        });
      }
    );

    streamifier.createReadStream(buffer).pipe(uploadStream);
  });
}

export async function deleteFile(publicId: string, resourceType: 'image' | 'video' | 'raw' = 'image') {
  return cloudinary.uploader.destroy(publicId, { resource_type: resourceType });
}

export const FOLDERS = {
  PROFILES: 'your-social/profiles',
  COVERS: 'your-social/covers',
  POSTS: 'your-social/posts',
  STORIES: 'your-social/stories',
  REELS: 'your-social/reels',
  MESSAGES: 'your-social/messages',
  GROUPS: 'your-social/groups',
  MARKETPLACE: 'your-social/marketplace',
  PAGES: 'your-social/pages',
};

export default cloudinary;
