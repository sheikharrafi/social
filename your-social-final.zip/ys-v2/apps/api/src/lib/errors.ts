import { Request, Response, NextFunction } from 'express';
import { logger } from './logger';

export class AppError extends Error {
  statusCode: number;
  isOperational: boolean;

  constructor(message: string, statusCode: number = 500) {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = true;
    Error.captureStackTrace(this, this.constructor);
  }
}

export function errorHandler(err: Error, req: Request, res: Response, next: NextFunction) {
  if (err instanceof AppError) {
    return res.status(err.statusCode).json({ success: false, message: err.message });
  }

  // Prisma errors
  if (err.constructor.name === 'PrismaClientKnownRequestError') {
    const prismaError = err as any;
    if (prismaError.code === 'P2002') {
      const field = prismaError.meta?.target?.[0] || 'field';
      return res.status(409).json({ success: false, message: `${field} already exists` });
    }
    if (prismaError.code === 'P2025') {
      return res.status(404).json({ success: false, message: 'Record not found' });
    }
  }

  logger.error(err.message, { stack: err.stack, url: req.url, method: req.method });
  return res.status(500).json({ success: false, message: 'Internal server error' });
}

export const ok = (res: Response, data: object = {}, message = 'Success') =>
  res.json({ success: true, message, ...data });

export const created = (res: Response, data: object = {}, message = 'Created') =>
  res.status(201).json({ success: true, message, ...data });

export const notFound = (name: string) => new AppError(`${name} not found`, 404);
export const forbidden = (msg = 'Forbidden') => new AppError(msg, 403);
export const badRequest = (msg: string) => new AppError(msg, 400);
export const unauthorized = (msg = 'Unauthorized') => new AppError(msg, 401);
export const conflict = (msg: string) => new AppError(msg, 409);
