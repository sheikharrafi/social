import prisma from '../lib/prisma';
import { NotificationType } from '@prisma/client';

interface CreateNotifOptions {
  recipientId: string;
  senderId: string;
  type: NotificationType;
  message: string;
  link?: string;
  entityId?: string;
  entityType?: string;
  io?: any;
}

export async function createNotification(opts: CreateNotifOptions) {
  if (opts.recipientId === opts.senderId) return null;

  const notif = await prisma.notification.create({
    data: {
      recipientId: opts.recipientId,
      senderId: opts.senderId,
      type: opts.type,
      message: opts.message,
      link: opts.link,
      entityId: opts.entityId,
      entityType: opts.entityType,
    },
    include: {
      sender: { select: { id: true, firstName: true, lastName: true, profilePicture: true, username: true } },
    },
  });

  // Real-time push
  if (opts.io) {
    opts.io.to(opts.recipientId).emit('notification', notif);
  }

  return notif;
}

export async function createBulkNotifications(
  recipientIds: string[],
  opts: Omit<CreateNotifOptions, 'recipientId'>
) {
  const filtered = recipientIds.filter(id => id !== opts.senderId);
  if (!filtered.length) return;

  const data = filtered.map(recipientId => ({
    recipientId,
    senderId: opts.senderId,
    type: opts.type,
    message: opts.message,
    link: opts.link,
    entityId: opts.entityId,
    entityType: opts.entityType,
  }));

  await prisma.notification.createMany({ data });

  if (opts.io) {
    filtered.forEach(recipientId => {
      opts.io.to(recipientId).emit('notification_badge');
    });
  }
}
