import { Response, NextFunction } from 'express';
import prisma from '../lib/prisma';
import { ok, created, notFound, forbidden } from '../lib/errors';
import { AuthRequest } from '../middleware/auth';
import { createNotification } from '../services/notification.service';
import { NotificationType } from '@prisma/client';

const COMMENT_INCLUDE = {
  author: { select: { id: true, firstName: true, lastName: true, profilePicture: true, username: true, isVerified: true } },
  reactions: { select: { userId: true, type: true } },
  _count: { select: { replies: true, reactions: true } },
} as const;

export async function getComments(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { postId } = req.params;
    const { page = '1', limit = '20' } = req.query;
    const skip = (Number(page) - 1) * Number(limit);

    const [comments, total] = await Promise.all([
      prisma.comment.findMany({
        where: { postId, parentCommentId: null },
        orderBy: { createdAt: 'desc' },
        skip,
        take: Number(limit),
        include: {
          ...COMMENT_INCLUDE,
          replies: {
            take: 3,
            orderBy: { createdAt: 'asc' },
            include: COMMENT_INCLUDE,
          },
        },
      }),
      prisma.comment.count({ where: { postId, parentCommentId: null } }),
    ]);

    return ok(res, { comments, total });
  } catch (err) { next(err); }
}

export async function createComment(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { postId, content, parentCommentId, imageUrl } = req.body;

    const post = await prisma.post.findUnique({ where: { id: postId }, select: { authorId: true } });
    if (!post) throw notFound('Post');

    const comment = await prisma.comment.create({
      data: { postId, authorId: req.user!.id, content, parentCommentId: parentCommentId || null, imageUrl },
      include: COMMENT_INCLUDE,
    });

    // Notify post author
    await createNotification({
      recipientId: post.authorId,
      senderId: req.user!.id,
      type: NotificationType.POST_COMMENT,
      message: `${req.user!.firstName} commented on your post`,
      link: `/posts/${postId}`,
      entityId: postId,
      io: (req as any).io,
    });

    // Notify parent comment author
    if (parentCommentId) {
      const parent = await prisma.comment.findUnique({ where: { id: parentCommentId }, select: { authorId: true } });
      if (parent && parent.authorId !== req.user!.id) {
        await createNotification({
          recipientId: parent.authorId,
          senderId: req.user!.id,
          type: NotificationType.COMMENT_REPLY,
          message: `${req.user!.firstName} replied to your comment`,
          link: `/posts/${postId}`,
          io: (req as any).io,
        });
      }
    }

    (req as any).io?.to(`post:${postId}`).emit('new_comment', comment);
    return created(res, { comment });
  } catch (err) { next(err); }
}

export async function updateComment(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const comment = await prisma.comment.findUnique({ where: { id: req.params.id } });
    if (!comment) throw notFound('Comment');
    if (comment.authorId !== req.user!.id) throw forbidden();

    const updated = await prisma.comment.update({
      where: { id: req.params.id },
      data: { content: req.body.content, isEdited: true },
      include: COMMENT_INCLUDE,
    });
    return ok(res, { comment: updated });
  } catch (err) { next(err); }
}

export async function deleteComment(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const comment = await prisma.comment.findUnique({ where: { id: req.params.id } });
    if (!comment) throw notFound('Comment');
    if (comment.authorId !== req.user!.id && req.user!.role !== 'ADMIN') throw forbidden();

    await prisma.comment.delete({ where: { id: req.params.id } });
    return ok(res, {}, 'Comment deleted');
  } catch (err) { next(err); }
}

export async function reactToComment(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { type = 'LIKE' } = req.body;
    const commentId = req.params.id;

    const existing = await prisma.commentReaction.findUnique({
      where: { commentId_userId: { commentId, userId: req.user!.id } },
    });

    if (existing) {
      if (existing.type === type) {
        await prisma.commentReaction.delete({ where: { commentId_userId: { commentId, userId: req.user!.id } } });
      } else {
        await prisma.commentReaction.update({ where: { commentId_userId: { commentId, userId: req.user!.id } }, data: { type } });
      }
    } else {
      await prisma.commentReaction.create({ data: { commentId, userId: req.user!.id, type } });
    }

    const reactions = await prisma.commentReaction.findMany({ where: { commentId } });
    return ok(res, { reactions });
  } catch (err) { next(err); }
}

export async function getReplies(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { page = '1', limit = '10' } = req.query;
    const replies = await prisma.comment.findMany({
      where: { parentCommentId: req.params.id },
      orderBy: { createdAt: 'asc' },
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
      include: COMMENT_INCLUDE,
    });
    return ok(res, { replies });
  } catch (err) { next(err); }
}
