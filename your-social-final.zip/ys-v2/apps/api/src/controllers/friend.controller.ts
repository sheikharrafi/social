import { Response, NextFunction } from 'express';
import prisma from '../lib/prisma';
import { ok, badRequest, notFound } from '../lib/errors';
import { AuthRequest } from '../middleware/auth';
import { createNotification } from '../services/notification.service';
import { NotificationType } from '@prisma/client';

export async function sendFriendRequest(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { userId: addresseeId } = req.params;
    const requesterId = req.user!.id;

    if (requesterId === addresseeId) throw badRequest('Cannot send friend request to yourself');

    const target = await prisma.user.findUnique({ where: { id: addresseeId } });
    if (!target) throw notFound('User');

    // Check if they already sent us a request — auto accept
    const reverseRequest = await prisma.friendship.findUnique({
      where: { requesterId_addresseeId: { requesterId: addresseeId, addresseeId: requesterId } },
    });

    if (reverseRequest?.status === 'PENDING') {
      await prisma.friendship.update({
        where: { id: reverseRequest.id },
        data: { status: 'ACCEPTED' },
      });
      await createNotification({
        recipientId: addresseeId, senderId: requesterId,
        type: NotificationType.FRIEND_ACCEPT,
        message: `${req.user!.firstName} accepted your friend request`,
        link: `/profile/${requesterId}`,
        io: (req as any).io,
      });
      return ok(res, { status: 'ACCEPTED' }, 'Friend request accepted');
    }

    const existing = await prisma.friendship.findUnique({
      where: { requesterId_addresseeId: { requesterId, addresseeId } },
    });
    if (existing) {
      if (existing.status === 'ACCEPTED') throw badRequest('Already friends');
      if (existing.status === 'PENDING') throw badRequest('Request already sent');
    }

    await prisma.friendship.create({ data: { requesterId, addresseeId, status: 'PENDING' } });

    await createNotification({
      recipientId: addresseeId, senderId: requesterId,
      type: NotificationType.FRIEND_REQUEST,
      message: `${req.user!.firstName} sent you a friend request`,
      link: `/profile/${requesterId}`,
      io: (req as any).io,
    });

    return ok(res, { status: 'PENDING' }, 'Friend request sent');
  } catch (err) { next(err); }
}

export async function acceptFriendRequest(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { userId: requesterId } = req.params;
    const me = req.user!.id;

    const friendship = await prisma.friendship.findUnique({
      where: { requesterId_addresseeId: { requesterId, addresseeId: me } },
    });
    if (!friendship || friendship.status !== 'PENDING') throw badRequest('No pending request found');

    await prisma.friendship.update({ where: { id: friendship.id }, data: { status: 'ACCEPTED' } });

    await createNotification({
      recipientId: requesterId, senderId: me,
      type: NotificationType.FRIEND_ACCEPT,
      message: `${req.user!.firstName} accepted your friend request`,
      link: `/profile/${me}`,
      io: (req as any).io,
    });

    (req as any).io?.to(requesterId).emit('friend_accepted', { userId: me });
    return ok(res, { status: 'ACCEPTED' }, 'Friend request accepted');
  } catch (err) { next(err); }
}

export async function declineFriendRequest(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { userId: requesterId } = req.params;
    await prisma.friendship.deleteMany({
      where: { requesterId, addresseeId: req.user!.id, status: 'PENDING' },
    });
    return ok(res, {}, 'Request declined');
  } catch (err) { next(err); }
}

export async function cancelFriendRequest(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { userId: addresseeId } = req.params;
    await prisma.friendship.deleteMany({
      where: { requesterId: req.user!.id, addresseeId, status: 'PENDING' },
    });
    return ok(res, {}, 'Request cancelled');
  } catch (err) { next(err); }
}

export async function unfriend(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { userId } = req.params;
    await prisma.friendship.deleteMany({
      where: {
        OR: [
          { requesterId: req.user!.id, addresseeId: userId },
          { requesterId: userId, addresseeId: req.user!.id },
        ],
        status: 'ACCEPTED',
      },
    });
    return ok(res, {}, 'Unfriended');
  } catch (err) { next(err); }
}

export async function getFriendRequests(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const [received, sent] = await Promise.all([
      prisma.friendship.findMany({
        where: { addresseeId: req.user!.id, status: 'PENDING' },
        include: { requester: { select: { id: true, firstName: true, lastName: true, profilePicture: true, username: true, bio: true } } },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.friendship.findMany({
        where: { requesterId: req.user!.id, status: 'PENDING' },
        include: { addressee: { select: { id: true, firstName: true, lastName: true, profilePicture: true, username: true } } },
        orderBy: { createdAt: 'desc' },
      }),
    ]);
    return ok(res, { received: received.map(f => f.requester), sent: sent.map(f => f.addressee) });
  } catch (err) { next(err); }
}

export async function toggleFollow(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { userId: followingId } = req.params;
    const followerId = req.user!.id;

    if (followerId === followingId) throw badRequest('Cannot follow yourself');

    const existing = await prisma.follow.findUnique({
      where: { followerId_followingId: { followerId, followingId } },
    });

    if (existing) {
      await prisma.follow.delete({ where: { followerId_followingId: { followerId, followingId } } });
      return ok(res, { following: false }, 'Unfollowed');
    } else {
      await prisma.follow.create({ data: { followerId, followingId } });
      await createNotification({
        recipientId: followingId, senderId: followerId,
        type: NotificationType.FOLLOW,
        message: `${req.user!.firstName} started following you`,
        link: `/profile/${followerId}`,
        io: (req as any).io,
      });
      return ok(res, { following: true }, 'Following');
    }
  } catch (err) { next(err); }
}
