import { Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import prisma from '../lib/prisma';
import { ok, notFound, badRequest } from '../lib/errors';
import { AuthRequest } from '../middleware/auth';
import { uploadFromBuffer, FOLDERS } from '../lib/cloudinary';

const PUBLIC_USER_SELECT = {
  id: true, firstName: true, lastName: true, email: true,
  username: true, profilePicture: true, coverPhoto: true,
  bio: true, website: true, location: true, workplace: true,
  education: true, relationship: true, birthday: true, gender: true,
  hometown: true, isVerified: true, isOnline: true, lastSeen: true,
  role: true, createdAt: true, privacyProfile: true,
  _count: {
    select: {
      friendships: { where: { status: 'ACCEPTED' } },
      followers: true,
      following: true,
      posts: true,
      reels: true,
    },
  },
} as const;

export async function getProfile(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { userId } = req.params;
    const viewerId = req.user?.id;

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: PUBLIC_USER_SELECT,
    });
    if (!user) throw notFound('User');

    // Track profile view
    if (viewerId && viewerId !== userId) {
      await prisma.profileView.upsert({
        where: { viewerId_profileOwner: { viewerId, profileOwner: userId } },
        create: { viewerId, profileOwner: userId },
        update: { createdAt: new Date() },
      }).catch(() => {});

      await prisma.user.update({ where: { id: userId }, data: { profileViews: { increment: 1 } } }).catch(() => {});
    }

    // Friendship status
    let friendStatus = 'NONE';
    if (viewerId && viewerId !== userId) {
      const friendship = await prisma.friendship.findFirst({
        where: {
          OR: [
            { requesterId: viewerId, addresseeId: userId },
            { requesterId: userId, addresseeId: viewerId },
          ],
        },
      });
      if (friendship) {
        if (friendship.status === 'ACCEPTED') friendStatus = 'FRIENDS';
        else if (friendship.status === 'PENDING') {
          friendStatus = friendship.requesterId === viewerId ? 'SENT' : 'RECEIVED';
        } else if (friendship.status === 'BLOCKED') friendStatus = 'BLOCKED';
      }
    }

    const isFollowing = viewerId
      ? !!(await prisma.follow.findUnique({
          where: { followerId_followingId: { followerId: viewerId, followingId: userId } },
        }))
      : false;

    return ok(res, { user: { ...user, friendStatus, isFollowing } });
  } catch (err) { next(err); }
}

export async function updateProfile(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const allowedFields = [
      'firstName', 'lastName', 'bio', 'website', 'location',
      'workplace', 'education', 'relationship', 'birthday',
      'gender', 'hometown', 'username',
      'privacyProfile', 'privacyFriendList', 'privacyPostDefault',
      'notifFriendRequests', 'notifPostLikes', 'notifComments',
      'notifMessages', 'notifGroupActivity',
    ];

    const data: Record<string, any> = {};
    allowedFields.forEach(f => {
      if (req.body[f] !== undefined) data[f] = req.body[f];
    });

    if (data.birthday) data.birthday = new Date(data.birthday);

    const user = await prisma.user.update({
      where: { id: req.user!.id },
      data,
      select: PUBLIC_USER_SELECT,
    });

    return ok(res, { user });
  } catch (err) { next(err); }
}

export async function uploadProfilePicture(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    if (!req.file) throw badRequest('No file uploaded');
    const result = await uploadFromBuffer(req.file.buffer, { folder: FOLDERS.PROFILES, resourceType: 'image' });
    const user = await prisma.user.update({
      where: { id: req.user!.id },
      data: { profilePicture: result.url },
      select: { id: true, profilePicture: true },
    });
    return ok(res, { user, url: result.url });
  } catch (err) { next(err); }
}

export async function uploadCoverPhoto(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    if (!req.file) throw badRequest('No file uploaded');
    const result = await uploadFromBuffer(req.file.buffer, { folder: FOLDERS.COVERS, resourceType: 'image' });
    const user = await prisma.user.update({
      where: { id: req.user!.id },
      data: { coverPhoto: result.url },
      select: { id: true, coverPhoto: true },
    });
    return ok(res, { user, url: result.url });
  } catch (err) { next(err); }
}

export async function changePassword(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { currentPassword, newPassword } = req.body;
    const user = await prisma.user.findUnique({ where: { id: req.user!.id }, select: { password: true } });
    if (!user) throw notFound('User');

    const isMatch = await bcrypt.compare(currentPassword, user.password);
    if (!isMatch) throw badRequest('Current password is incorrect');

    const hashed = await bcrypt.hash(newPassword, 12);
    await prisma.user.update({ where: { id: req.user!.id }, data: { password: hashed } });

    return ok(res, {}, 'Password changed successfully');
  } catch (err) { next(err); }
}

export async function getUserFriends(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { userId } = req.params;
    const { page = '1', limit = '20' } = req.query;
    const skip = (Number(page) - 1) * Number(limit);

    const friendships = await prisma.friendship.findMany({
      where: {
        OR: [{ requesterId: userId }, { addresseeId: userId }],
        status: 'ACCEPTED',
      },
      skip,
      take: Number(limit),
      include: {
        requester: { select: { id: true, firstName: true, lastName: true, profilePicture: true, isOnline: true, username: true } },
        addressee: { select: { id: true, firstName: true, lastName: true, profilePicture: true, isOnline: true, username: true } },
      },
    });

    const friends = friendships.map(f => f.requesterId === userId ? f.addressee : f.requester);
    return ok(res, { friends });
  } catch (err) { next(err); }
}

export async function getUserPhotos(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { userId } = req.params;
    const { page = '1', limit = '24' } = req.query;
    const skip = (Number(page) - 1) * Number(limit);

    const media = await prisma.postMedia.findMany({
      where: { post: { authorId: userId }, type: 'IMAGE' },
      orderBy: { createdAt: 'desc' },
      skip,
      take: Number(limit),
      select: { id: true, url: true, postId: true, createdAt: true, width: true, height: true },
    });

    return ok(res, { photos: media });
  } catch (err) { next(err); }
}

export async function getBirthdays(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const today = new Date();
    const friends = await prisma.friendship.findMany({
      where: {
        OR: [{ requesterId: req.user!.id }, { addresseeId: req.user!.id }],
        status: 'ACCEPTED',
      },
      include: {
        requester: { select: { id: true, firstName: true, lastName: true, profilePicture: true, birthday: true } },
        addressee: { select: { id: true, firstName: true, lastName: true, profilePicture: true, birthday: true } },
      },
    });

    const allFriends = friends.map(f => f.requesterId === req.user!.id ? f.addressee : f.requester);
    const todayBirthdays = allFriends.filter(f => {
      if (!f.birthday) return false;
      const bd = new Date(f.birthday);
      return bd.getMonth() === today.getMonth() && bd.getDate() === today.getDate();
    });

    return ok(res, { birthdays: todayBirthdays });
  } catch (err) { next(err); }
}

export async function blockUser(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { userId } = req.params;
    await prisma.blockedUser.upsert({
      where: { blockerId_blockedId: { blockerId: req.user!.id, blockedId: userId } },
      create: { blockerId: req.user!.id, blockedId: userId },
      update: {},
    });
    // Remove friendship
    await prisma.friendship.deleteMany({
      where: {
        OR: [
          { requesterId: req.user!.id, addresseeId: userId },
          { requesterId: userId, addresseeId: req.user!.id },
        ],
      },
    });
    return ok(res, {}, 'User blocked');
  } catch (err) { next(err); }
}

export async function unblockUser(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    await prisma.blockedUser.deleteMany({
      where: { blockerId: req.user!.id, blockedId: req.params.userId },
    });
    return ok(res, {}, 'User unblocked');
  } catch (err) { next(err); }
}

export async function getSuggestedUsers(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { limit = '10' } = req.query;

    // Get friend IDs to exclude
    const myFriendships = await prisma.friendship.findMany({
      where: {
        OR: [{ requesterId: req.user!.id }, { addresseeId: req.user!.id }],
      },
      select: { requesterId: true, addresseeId: true },
    });
    const excludeIds = new Set<string>([req.user!.id]);
    myFriendships.forEach(f => { excludeIds.add(f.requesterId); excludeIds.add(f.addresseeId); });

    const suggestions = await prisma.user.findMany({
      where: { id: { notIn: [...excludeIds] } },
      select: {
        id: true, firstName: true, lastName: true, profilePicture: true,
        bio: true, username: true, isVerified: true,
        _count: { select: { followers: true, posts: true } },
      },
      take: Number(limit),
      orderBy: { createdAt: 'desc' },
    });

    return ok(res, { suggestions });
  } catch (err) { next(err); }
}

export async function getCreatorAnalytics(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const userId = req.user!.id;
    const [totalPosts, totalReels, totalFollowers, totalViews, recentPosts] = await Promise.all([
      prisma.post.count({ where: { authorId: userId } }),
      prisma.reel.count({ where: { authorId: userId } }),
      prisma.follow.count({ where: { followingId: userId } }),
      prisma.postView.count({ where: { post: { authorId: userId } } }),
      prisma.post.findMany({
        where: { authorId: userId },
        orderBy: { createdAt: 'desc' },
        take: 10,
        select: {
          id: true, content: true, viewCount: true,
          _count: { select: { reactions: true, comments: true, shares: true } },
          createdAt: true,
        },
      }),
    ]);

    return ok(res, { analytics: { totalPosts, totalReels, totalFollowers, totalViews, recentPosts } });
  } catch (err) { next(err); }
}
