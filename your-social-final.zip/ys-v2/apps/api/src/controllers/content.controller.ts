import { Response, NextFunction } from 'express';
import prisma from '../lib/prisma';
import { ok, created, notFound, forbidden } from '../lib/errors';
import { AuthRequest } from '../middleware/auth';
import { uploadFromBuffer, FOLDERS } from '../lib/cloudinary';
import { syncHashtags } from '../lib/hashtags';
import { createNotification } from '../services/notification.service';
import { NotificationType } from '@prisma/client';

// ─── STORIES ───────────────────────────────────────────

export async function getStories(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const userId = req.user!.id;
    const friendships = await prisma.friendship.findMany({
      where: { OR: [{ requesterId: userId }, { addresseeId: userId }], status: 'ACCEPTED' },
      select: { requesterId: true, addresseeId: true },
    });
    const friendIds = friendships.map(f => f.requesterId === userId ? f.addresseeId : f.requesterId);
    const authorIds = [userId, ...friendIds];

    const stories = await prisma.story.findMany({
      where: { authorId: { in: authorIds }, expiresAt: { gt: new Date() } },
      orderBy: { createdAt: 'desc' },
      include: {
        author: { select: { id: true, firstName: true, lastName: true, profilePicture: true, username: true } },
        views: { select: { userId: true } },
        reactions: { select: { userId: true, emoji: true } },
      },
    });

    // Group by author
    const grouped = stories.reduce((acc: any, s) => {
      const id = s.author.id;
      if (!acc[id]) acc[id] = { author: s.author, stories: [] };
      acc[id].stories.push(s);
      return acc;
    }, {});

    return ok(res, { storyGroups: Object.values(grouped) });
  } catch (err) { next(err); }
}

export async function createStory(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const file = req.file;
    let mediaUrl: string | undefined;
    let publicId: string | undefined;

    if (file) {
      const result = await uploadFromBuffer(file.buffer, {
        folder: FOLDERS.STORIES,
        resourceType: file.mimetype.startsWith('video') ? 'video' : 'image',
      });
      mediaUrl = result.url;
      publicId = result.publicId;
    }

    const story = await prisma.story.create({
      data: {
        authorId: req.user!.id,
        type: req.body.type || (file?.mimetype.startsWith('video') ? 'VIDEO' : file ? 'IMAGE' : 'TEXT'),
        mediaUrl,
        publicId,
        text: req.body.text,
        textColor: req.body.textColor,
        bgColor: req.body.bgColor,
        bgGradient: req.body.bgGradient,
        font: req.body.font,
        audience: req.body.audience || 'FRIENDS',
      },
      include: {
        author: { select: { id: true, firstName: true, lastName: true, profilePicture: true } },
      },
    });

    return created(res, { story });
  } catch (err) { next(err); }
}

export async function viewStory(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    await prisma.storyView.upsert({
      where: { storyId_userId: { storyId: req.params.id, userId: req.user!.id } },
      create: { storyId: req.params.id, userId: req.user!.id },
      update: { viewedAt: new Date() },
    });
    return ok(res, {});
  } catch (err) { next(err); }
}

export async function reactToStory(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { emoji = '❤️' } = req.body;
    await prisma.storyReaction.upsert({
      where: { storyId_userId: { storyId: req.params.id, userId: req.user!.id } },
      create: { storyId: req.params.id, userId: req.user!.id, emoji },
      update: { emoji },
    });
    return ok(res, {});
  } catch (err) { next(err); }
}

export async function deleteStory(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const story = await prisma.story.findUnique({ where: { id: req.params.id } });
    if (!story) throw notFound('Story');
    if (story.authorId !== req.user!.id) throw forbidden();
    await prisma.story.delete({ where: { id: req.params.id } });
    return ok(res, {}, 'Story deleted');
  } catch (err) { next(err); }
}

// ─── REELS ────────────────────────────────────────────

export async function getReels(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { page = '1', limit = '10' } = req.query;
    const skip = (Number(page) - 1) * Number(limit);

    const reels = await prisma.reel.findMany({
      where: { audience: 'PUBLIC' },
      orderBy: { createdAt: 'desc' },
      skip,
      take: Number(limit),
      include: {
        author: { select: { id: true, firstName: true, lastName: true, profilePicture: true, username: true, isVerified: true } },
        reactions: { select: { userId: true, type: true } },
        hashtags: { include: { hashtag: { select: { name: true } } } },
        _count: { select: { reactions: true, comments: true, views: true } },
      },
    });

    return ok(res, { reels });
  } catch (err) { next(err); }
}

export async function createReel(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    if (!req.file) throw new Error('Video file required');
    const result = await uploadFromBuffer(req.file.buffer, {
      folder: FOLDERS.REELS,
      resourceType: 'video',
    });

    const reel = await prisma.reel.create({
      data: {
        authorId: req.user!.id,
        videoUrl: result.url,
        publicId: result.publicId,
        caption: req.body.caption,
        audioName: req.body.audioName,
        audience: req.body.audience || 'PUBLIC',
        duration: result.duration,
        width: result.width,
        height: result.height,
      },
      include: {
        author: { select: { id: true, firstName: true, lastName: true, profilePicture: true, username: true } },
      },
    });

    if (req.body.caption) await syncHashtags(reel.id, 'reel', req.body.caption).catch(() => {});
    return created(res, { reel });
  } catch (err) { next(err); }
}

export async function viewReel(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    await Promise.all([
      prisma.reelView.create({ data: { reelId: req.params.id, userId: req.user?.id } }),
      prisma.reel.update({ where: { id: req.params.id }, data: { viewCount: { increment: 1 } } }),
    ]);
    return ok(res, {});
  } catch (err) { next(err); }
}

export async function reactToReel(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { type = 'LIKE' } = req.body;
    const reelId = req.params.id;
    const existing = await prisma.reelReaction.findUnique({ where: { reelId_userId: { reelId, userId: req.user!.id } } });

    if (existing) {
      if (existing.type === type) await prisma.reelReaction.delete({ where: { reelId_userId: { reelId, userId: req.user!.id } } });
      else await prisma.reelReaction.update({ where: { reelId_userId: { reelId, userId: req.user!.id } }, data: { type } });
    } else {
      await prisma.reelReaction.create({ data: { reelId, userId: req.user!.id, type } });
    }
    const reactions = await prisma.reelReaction.findMany({ where: { reelId } });
    return ok(res, { reactions });
  } catch (err) { next(err); }
}

export async function deleteReel(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const reel = await prisma.reel.findUnique({ where: { id: req.params.id } });
    if (!reel) throw notFound('Reel');
    if (reel.authorId !== req.user!.id && req.user!.role !== 'ADMIN') throw forbidden();
    await prisma.reel.delete({ where: { id: req.params.id } });
    return ok(res, {}, 'Reel deleted');
  } catch (err) { next(err); }
}

// ─── SEARCH ───────────────────────────────────────────

export async function search(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { q, type = 'all', page = '1', limit = '10' } = req.query as any;
    if (!q?.trim()) return ok(res, { users: [], posts: [], groups: [], hashtags: [], reels: [] });

    const skip = (Number(page) - 1) * Number(limit);
    const search = { contains: q, mode: 'insensitive' as const };

    // Save search history
    if (req.user) {
      prisma.searchHistory.create({ data: { userId: req.user.id, query: q } }).catch(() => {});
    }

    const results: any = {};

    if (type === 'all' || type === 'people') {
      results.users = await prisma.user.findMany({
        where: {
          OR: [{ firstName: search }, { lastName: search }, { username: search }, { bio: search }],
          id: { not: req.user?.id },
        },
        select: { id: true, firstName: true, lastName: true, profilePicture: true, bio: true, username: true, isVerified: true, _count: { select: { followers: true } } },
        take: Number(limit), skip,
      });
    }

    if (type === 'all' || type === 'posts') {
      results.posts = await prisma.post.findMany({
        where: { content: search, audience: { in: ['PUBLIC', 'FRIENDS'] } },
        include: { author: { select: { id: true, firstName: true, lastName: true, profilePicture: true } }, _count: { select: { reactions: true, comments: true } } },
        take: Number(limit), skip,
        orderBy: { createdAt: 'desc' },
      });
    }

    if (type === 'all' || type === 'groups') {
      results.groups = await prisma.group.findMany({
        where: { name: search, privacy: 'PUBLIC' },
        select: { id: true, name: true, description: true, coverPhoto: true, privacy: true, _count: { select: { members: true } } },
        take: Number(limit), skip,
      });
    }

    if (type === 'all' || type === 'hashtags') {
      results.hashtags = await prisma.hashtag.findMany({
        where: { name: search },
        orderBy: { postCount: 'desc' },
        take: Number(limit),
      });
    }

    if (type === 'all' || type === 'reels') {
      results.reels = await prisma.reel.findMany({
        where: { caption: search, audience: 'PUBLIC' },
        include: { author: { select: { id: true, firstName: true, lastName: true, profilePicture: true } } },
        take: Number(limit), skip,
      });
    }

    return ok(res, results);
  } catch (err) { next(err); }
}

export async function getTrending(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const [hashtags, posts] = await Promise.all([
      prisma.hashtag.findMany({ orderBy: { postCount: 'desc' }, take: 10 }),
      prisma.post.findMany({
        where: { audience: 'PUBLIC', createdAt: { gte: new Date(Date.now() - 86400000 * 7) } },
        orderBy: [{ viewCount: 'desc' }, { shareCount: 'desc' }],
        take: 10,
        include: {
          author: { select: { id: true, firstName: true, lastName: true, profilePicture: true } },
          _count: { select: { reactions: true, comments: true } },
        },
      }),
    ]);
    return ok(res, { hashtags, posts });
  } catch (err) { next(err); }
}

// ─── NOTIFICATIONS ────────────────────────────────────

export async function getNotifications(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { page = '1', limit = '20' } = req.query;
    const skip = (Number(page) - 1) * Number(limit);

    const [notifications, unreadCount] = await Promise.all([
      prisma.notification.findMany({
        where: { recipientId: req.user!.id },
        orderBy: { createdAt: 'desc' },
        skip,
        take: Number(limit),
        include: { sender: { select: { id: true, firstName: true, lastName: true, profilePicture: true, username: true } } },
      }),
      prisma.notification.count({ where: { recipientId: req.user!.id, isRead: false } }),
    ]);

    return ok(res, { notifications, unreadCount });
  } catch (err) { next(err); }
}

export async function markAllRead(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    await prisma.notification.updateMany({ where: { recipientId: req.user!.id, isRead: false }, data: { isRead: true } });
    return ok(res, {}, 'All marked as read');
  } catch (err) { next(err); }
}

export async function markOneRead(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    await prisma.notification.update({ where: { id: req.params.id }, data: { isRead: true } });
    return ok(res, {});
  } catch (err) { next(err); }
}

export async function deleteNotification(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    await prisma.notification.deleteMany({ where: { id: req.params.id, recipientId: req.user!.id } });
    return ok(res, {}, 'Deleted');
  } catch (err) { next(err); }
}
