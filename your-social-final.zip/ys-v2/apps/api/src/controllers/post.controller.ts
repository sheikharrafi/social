import { Response, NextFunction } from 'express';
import prisma from '../lib/prisma';
import { ok, created, notFound, forbidden, badRequest } from '../lib/errors';
import { AuthRequest } from '../middleware/auth';
import { uploadFromBuffer, FOLDERS } from '../lib/cloudinary';
import { syncHashtags } from '../lib/hashtags';
import { createNotification, createBulkNotifications } from '../services/notification.service';
import { NotificationType } from '@prisma/client';

const POST_INCLUDE = {
  author: { select: { id: true, firstName: true, lastName: true, profilePicture: true, username: true, isVerified: true } },
  media: { orderBy: { order: 'asc' as const } },
  reactions: { select: { userId: true, type: true } },
  tags: { include: { user: { select: { id: true, firstName: true, lastName: true } } } },
  sharedPost: {
    include: {
      author: { select: { id: true, firstName: true, lastName: true, profilePicture: true, username: true } },
      media: { orderBy: { order: 'asc' as const } },
    },
  },
  hashtags: { include: { hashtag: { select: { name: true } } } },
  poll: { include: { options: { include: { _count: { select: { votes: true } } } } } },
  _count: { select: { comments: true, reactions: true, shares: true } },
} as const;

export async function getFeed(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { page = '1', limit = '10' } = req.query;
    const skip = (Number(page) - 1) * Number(limit);
    const userId = req.user!.id;

    // Get accepted friends
    const friendships = await prisma.friendship.findMany({
      where: { OR: [{ requesterId: userId }, { addresseeId: userId }], status: 'ACCEPTED' },
      select: { requesterId: true, addresseeId: true },
    });
    const friendIds = friendships.map(f => f.requesterId === userId ? f.addresseeId : f.requesterId);

    // Also get following
    const following = await prisma.follow.findMany({
      where: { followerId: userId },
      select: { followingId: true },
    });
    const followingIds = following.map(f => f.followingId);

    const authorIds = [...new Set([userId, ...friendIds, ...followingIds])];

    const [posts, total] = await Promise.all([
      prisma.post.findMany({
        where: {
          authorId: { in: authorIds },
          group: null,
          OR: [
            { audience: 'PUBLIC' },
            { audience: 'FRIENDS', authorId: { in: [...friendIds, userId] } },
            { audience: 'ONLY_ME', authorId: userId },
          ],
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: Number(limit),
        include: POST_INCLUDE,
      }),
      prisma.post.count({
        where: { authorId: { in: authorIds }, group: null },
      }),
    ]);

    return ok(res, { posts, total, page: Number(page), pages: Math.ceil(total / Number(limit)) });
  } catch (err) { next(err); }
}

export async function getUserPosts(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { userId } = req.params;
    const { page = '1', limit = '10' } = req.query;
    const skip = (Number(page) - 1) * Number(limit);
    const viewerId = req.user?.id;

    let audienceFilter: any = { audience: 'PUBLIC' };
    if (viewerId === userId) {
      audienceFilter = {};
    } else if (viewerId) {
      const areFriends = await prisma.friendship.findFirst({
        where: {
          OR: [{ requesterId: viewerId, addresseeId: userId }, { requesterId: userId, addresseeId: viewerId }],
          status: 'ACCEPTED',
        },
      });
      if (areFriends) audienceFilter = { audience: { in: ['PUBLIC', 'FRIENDS'] } };
    }

    const posts = await prisma.post.findMany({
      where: { authorId: userId, group: null, ...audienceFilter },
      orderBy: { createdAt: 'desc' },
      skip,
      take: Number(limit),
      include: POST_INCLUDE,
    });

    return ok(res, { posts });
  } catch (err) { next(err); }
}

export async function createPost(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const {
      content, audience = 'FRIENDS', postType = 'TEXT',
      background, feeling, feelingEmoji, location,
      taggedUserIds = [], groupId, pageId,
      poll: pollData,
    } = req.body;

    const files = (req.files as Express.Multer.File[]) || [];

    const post = await prisma.post.create({
      data: {
        authorId: req.user!.id,
        content: content || '',
        audience,
        postType,
        background,
        feeling,
        feelingEmoji,
        location,
        groupId: groupId || null,
        pageId: pageId || null,
        tags: taggedUserIds.length ? {
          create: taggedUserIds.map((uid: string) => ({ userId: uid })),
        } : undefined,
        poll: pollData ? {
          create: {
            question: pollData.question,
            expiresAt: pollData.expiresAt ? new Date(pollData.expiresAt) : undefined,
            options: { create: pollData.options.map((opt: string, i: number) => ({ text: opt, order: i })) },
          },
        } : undefined,
      },
    });

    // Upload media
    if (files.length) {
      const mediaUploads = await Promise.all(
        files.map((file, i) => uploadFromBuffer(file.buffer, {
          folder: file.mimetype.startsWith('video') ? FOLDERS.POSTS : FOLDERS.POSTS,
          resourceType: file.mimetype.startsWith('video') ? 'video' : 'image',
        }).then(r => ({
          postId: post.id,
          url: r.url,
          publicId: r.publicId,
          type: file.mimetype.startsWith('video') ? 'VIDEO' as const : 'IMAGE' as const,
          width: r.width,
          height: r.height,
          duration: r.duration,
          order: i,
        })))
      );
      await prisma.postMedia.createMany({ data: mediaUploads });
    }

    // Sync hashtags
    if (content) await syncHashtags(post.id, 'post', content).catch(() => {});

    // Notify tagged users
    if (taggedUserIds.length) {
      await createBulkNotifications(taggedUserIds, {
        senderId: req.user!.id,
        type: NotificationType.TAG,
        message: `${req.user!.firstName} tagged you in a post`,
        link: `/posts/${post.id}`,
        entityId: post.id,
        entityType: 'post',
        io: (req as any).io,
      });
    }

    const fullPost = await prisma.post.findUnique({ where: { id: post.id }, include: POST_INCLUDE });
    (req as any).io?.emit('new_post', fullPost);

    return created(res, { post: fullPost });
  } catch (err) { next(err); }
}

export async function getPost(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const post = await prisma.post.findUnique({ where: { id: req.params.id }, include: POST_INCLUDE });
    if (!post) throw notFound('Post');

    // Track view
    const viewerId = req.user?.id;
    await prisma.postView.create({ data: { postId: post.id, userId: viewerId } }).catch(() => {});
    await prisma.post.update({ where: { id: post.id }, data: { viewCount: { increment: 1 } } }).catch(() => {});

    return ok(res, { post });
  } catch (err) { next(err); }
}

export async function updatePost(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const post = await prisma.post.findUnique({ where: { id: req.params.id } });
    if (!post) throw notFound('Post');
    if (post.authorId !== req.user!.id) throw forbidden();

    const updated = await prisma.post.update({
      where: { id: req.params.id },
      data: {
        content: req.body.content ?? post.content,
        audience: req.body.audience ?? post.audience,
        feeling: req.body.feeling ?? post.feeling,
        location: req.body.location ?? post.location,
        isEdited: true,
      },
      include: POST_INCLUDE,
    });

    if (req.body.content) await syncHashtags(post.id, 'post', req.body.content).catch(() => {});
    return ok(res, { post: updated });
  } catch (err) { next(err); }
}

export async function deletePost(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const post = await prisma.post.findUnique({ where: { id: req.params.id } });
    if (!post) throw notFound('Post');
    if (post.authorId !== req.user!.id && req.user!.role !== 'ADMIN') throw forbidden();

    await prisma.post.delete({ where: { id: req.params.id } });
    return ok(res, {}, 'Post deleted');
  } catch (err) { next(err); }
}

export async function reactToPost(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { type = 'LIKE' } = req.body;
    const { id: postId } = req.params;

    const post = await prisma.post.findUnique({ where: { id: postId }, select: { authorId: true } });
    if (!post) throw notFound('Post');

    const existing = await prisma.postReaction.findUnique({
      where: { postId_userId: { postId, userId: req.user!.id } },
    });

    if (existing) {
      if (existing.type === type) {
        await prisma.postReaction.delete({ where: { postId_userId: { postId, userId: req.user!.id } } });
      } else {
        await prisma.postReaction.update({
          where: { postId_userId: { postId, userId: req.user!.id } },
          data: { type },
        });
      }
    } else {
      await prisma.postReaction.create({ data: { postId, userId: req.user!.id, type } });

      if (post.authorId !== req.user!.id) {
        await createNotification({
          recipientId: post.authorId,
          senderId: req.user!.id,
          type: NotificationType.POST_REACTION,
          message: `${req.user!.firstName} reacted to your post`,
          link: `/posts/${postId}`,
          entityId: postId,
          entityType: 'post',
          io: (req as any).io,
        });
      }
    }

    const reactions = await prisma.postReaction.findMany({ where: { postId } });
    (req as any).io?.to(`post:${postId}`).emit('post_reaction', { postId, reactions });
    return ok(res, { reactions });
  } catch (err) { next(err); }
}

export async function sharePost(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { content = '', audience = 'FRIENDS' } = req.body;
    const origPost = await prisma.post.findUnique({ where: { id: req.params.id }, select: { id: true, authorId: true } });
    if (!origPost) throw notFound('Post');

    const [sharedPost] = await Promise.all([
      prisma.post.create({
        data: {
          authorId: req.user!.id,
          content,
          audience,
          postType: 'SHARED',
          sharedPostId: origPost.id,
        },
        include: POST_INCLUDE,
      }),
      prisma.postShare.upsert({
        where: { postId_userId: { postId: origPost.id, userId: req.user!.id } },
        create: { postId: origPost.id, userId: req.user!.id },
        update: {},
      }),
      prisma.post.update({ where: { id: origPost.id }, data: { shareCount: { increment: 1 } } }),
    ]);

    if (origPost.authorId !== req.user!.id) {
      await createNotification({
        recipientId: origPost.authorId,
        senderId: req.user!.id,
        type: NotificationType.POST_SHARE,
        message: `${req.user!.firstName} shared your post`,
        link: `/posts/${sharedPost.id}`,
        entityId: sharedPost.id,
        io: (req as any).io,
      });
    }

    return created(res, { post: sharedPost });
  } catch (err) { next(err); }
}

export async function savePost(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const postId = req.params.id;
    const userId = req.user!.id;

    const existing = await prisma.savedPost.findUnique({
      where: { postId_userId: { postId, userId } },
    });

    if (existing) {
      await prisma.savedPost.delete({ where: { postId_userId: { postId, userId } } });
      return ok(res, { saved: false });
    } else {
      await prisma.savedPost.create({ data: { postId, userId } });
      return ok(res, { saved: true });
    }
  } catch (err) { next(err); }
}

export async function getSavedPosts(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { page = '1', limit = '10' } = req.query;
    const skip = (Number(page) - 1) * Number(limit);

    const saved = await prisma.savedPost.findMany({
      where: { userId: req.user!.id },
      orderBy: { createdAt: 'desc' },
      skip,
      take: Number(limit),
      include: { post: { include: POST_INCLUDE } },
    });

    return ok(res, { posts: saved.map(s => s.post) });
  } catch (err) { next(err); }
}

export async function votePoll(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { optionId } = req.body;
    const userId = req.user!.id;

    const option = await prisma.pollOption.findUnique({ where: { id: optionId }, include: { poll: true } });
    if (!option) throw notFound('Poll option');

    if (option.poll.expiresAt && option.poll.expiresAt < new Date()) throw badRequest('Poll has expired');

    // Remove existing vote in same poll
    const existingVote = await prisma.pollVote.findFirst({
      where: { option: { pollId: option.pollId }, userId },
    });
    if (existingVote) await prisma.pollVote.delete({ where: { id: existingVote.id } });

    await prisma.pollVote.create({ data: { optionId, userId } });

    const updatedPoll = await prisma.poll.findUnique({
      where: { id: option.pollId },
      include: { options: { include: { _count: { select: { votes: true } }, votes: { where: { userId }, select: { id: true } } } } },
    });

    return ok(res, { poll: updatedPoll });
  } catch (err) { next(err); }
}
