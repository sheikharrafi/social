import { Response, NextFunction } from 'express';
import prisma from '../lib/prisma';
import { ok, created, badRequest } from '../lib/errors';
import { AuthRequest } from '../middleware/auth';
import { uploadFromBuffer, deleteFile, FOLDERS } from '../lib/cloudinary';

// ─── UPLOAD ───────────────────────────────────────────

export async function uploadSingle(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    if (!req.file) throw badRequest('No file provided');
    const folder = req.body.folder || FOLDERS.POSTS;
    const resourceType = req.file.mimetype.startsWith('video') ? 'video' : req.file.mimetype.startsWith('audio') ? 'video' : 'image';

    const result = await uploadFromBuffer(req.file.buffer, { folder, resourceType });

    // Track in media library
    await prisma.mediaFile.create({
      data: {
        userId: req.user!.id,
        url: result.url,
        publicId: result.publicId,
        type: resourceType === 'video' ? 'VIDEO' : 'IMAGE',
        size: req.file.size,
        width: result.width,
        height: result.height,
        duration: result.duration,
      },
    }).catch(() => {});

    return ok(res, { url: result.url, publicId: result.publicId, width: result.width, height: result.height, duration: result.duration });
  } catch (err) { next(err); }
}

export async function uploadMultiple(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const files = (req.files as Express.Multer.File[]) || [];
    if (!files.length) throw badRequest('No files provided');
    const folder = req.body.folder || FOLDERS.POSTS;

    const results = await Promise.all(files.map(f =>
      uploadFromBuffer(f.buffer, {
        folder,
        resourceType: f.mimetype.startsWith('video') ? 'video' : 'image',
      })
    ));

    return ok(res, { files: results });
  } catch (err) { next(err); }
}

export async function deleteMedia(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { publicId, resourceType = 'image' } = req.body;
    if (!publicId) throw badRequest('publicId required');
    await deleteFile(publicId, resourceType);
    return ok(res, {}, 'Media deleted');
  } catch (err) { next(err); }
}

// ─── ADMIN ────────────────────────────────────────────

export async function getAdminStats(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const [users, posts, reels, stories, groups, reports] = await Promise.all([
      prisma.user.count(),
      prisma.post.count(),
      prisma.reel.count(),
      prisma.story.count(),
      prisma.group.count(),
      prisma.report.count({ where: { status: 'PENDING' } }),
    ]);

    const newUsersToday = await prisma.user.count({
      where: { createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) } },
    });

    const newUsersThisWeek = await prisma.user.count({
      where: { createdAt: { gte: new Date(Date.now() - 7 * 86400000) } },
    });

    return ok(res, { stats: { users, posts, reels, stories, groups, pendingReports: reports, newUsersToday, newUsersThisWeek } });
  } catch (err) { next(err); }
}

export async function getAdminUsers(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { page = '1', limit = '20', search } = req.query as any;
    const skip = (Number(page) - 1) * Number(limit);
    const where = search ? { OR: [{ email: { contains: search, mode: 'insensitive' as const } }, { firstName: { contains: search, mode: 'insensitive' as const } }] } : {};

    const [users, total] = await Promise.all([
      prisma.user.findMany({ where, skip, take: Number(limit), orderBy: { createdAt: 'desc' }, select: { id: true, firstName: true, lastName: true, email: true, role: true, isVerified: true, emailVerified: true, createdAt: true, _count: { select: { posts: true, followers: true } } } }),
      prisma.user.count({ where }),
    ]);

    return ok(res, { users, total, pages: Math.ceil(total / Number(limit)) });
  } catch (err) { next(err); }
}

export async function getVerificationRequests(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const requests = await prisma.verificationRequest.findMany({
      where: { status: 'PENDING' },
      include: { user: { select: { id: true, firstName: true, lastName: true, email: true, profilePicture: true } } },
      orderBy: { createdAt: 'asc' },
    });
    return ok(res, { requests });
  } catch (err) { next(err); }
}

export async function reviewVerification(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { decision, note } = req.body; // 'APPROVED' | 'REJECTED'
    const request = await prisma.verificationRequest.update({
      where: { id: req.params.id },
      data: { status: decision, reviewNote: note, reviewedAt: new Date() },
      include: { user: true },
    });

    if (decision === 'APPROVED') {
      await prisma.user.update({ where: { id: request.userId }, data: { isVerified: true } });
    }

    await prisma.notification.create({
      data: {
        recipientId: request.userId,
        senderId: req.user!.id,
        type: decision === 'APPROVED' ? 'VERIFICATION_APPROVED' : 'VERIFICATION_REJECTED',
        message: decision === 'APPROVED' ? 'Your verification request has been approved! ✓' : `Your verification request was declined. ${note || ''}`,
        link: '/settings/verification',
      },
    });

    return ok(res, { request }, `Verification ${decision.toLowerCase()}`);
  } catch (err) { next(err); }
}

export async function submitVerification(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const existing = await prisma.verificationRequest.findUnique({ where: { userId: req.user!.id } });
    if (existing?.status === 'PENDING') throw badRequest('You already have a pending request');

    let proofUrl: string | undefined;
    if (req.file) {
      const result = await uploadFromBuffer(req.file.buffer, { folder: 'your-social/verification', resourceType: 'image' });
      proofUrl = result.url;
    }

    const request = await prisma.verificationRequest.upsert({
      where: { userId: req.user!.id },
      create: { userId: req.user!.id, fullName: req.body.fullName, category: req.body.category, reason: req.body.reason, proofUrl },
      update: { fullName: req.body.fullName, category: req.body.category, reason: req.body.reason, proofUrl, status: 'PENDING', reviewNote: null },
    });

    return created(res, { request }, 'Verification request submitted');
  } catch (err) { next(err); }
}

export async function getPendingReports(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const reports = await prisma.report.findMany({
      where: { status: 'PENDING' },
      include: { reporter: { select: { id: true, firstName: true, lastName: true } } },
      orderBy: { createdAt: 'asc' },
      take: 50,
    });
    return ok(res, { reports });
  } catch (err) { next(err); }
}

export async function submitReport(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const report = await prisma.report.create({
      data: {
        reporterId: req.user!.id,
        entityId: req.body.entityId,
        entityType: req.body.entityType,
        reason: req.body.reason,
        description: req.body.description,
      },
    });
    return created(res, { report }, 'Report submitted');
  } catch (err) { next(err); }
}
