import { Response, NextFunction } from 'express';
import prisma from '../lib/prisma';
import { ok, created, notFound, forbidden, badRequest } from '../lib/errors';
import { AuthRequest } from '../middleware/auth';
import { uploadFromBuffer, FOLDERS } from '../lib/cloudinary';

const CONV_INCLUDE = {
  members: {
    include: {
      user: { select: { id: true, firstName: true, lastName: true, profilePicture: true, isOnline: true, lastSeen: true, username: true } },
    },
  },
  lastMessage: {
    include: { sender: { select: { id: true, firstName: true, lastName: true } } },
  },
} as const;

const MSG_INCLUDE = {
  sender: { select: { id: true, firstName: true, lastName: true, profilePicture: true, username: true } },
  replyTo: { include: { sender: { select: { id: true, firstName: true, lastName: true } } } },
  reactions: true,
  seenBy: true,
} as const;

export async function getConversations(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const conversations = await prisma.conversation.findMany({
      where: { members: { some: { userId: req.user!.id } } },
      orderBy: { updatedAt: 'desc' },
      include: CONV_INCLUDE,
    });
    return ok(res, { conversations });
  } catch (err) { next(err); }
}

export async function getOrCreateConversation(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { userId: otherId } = req.params;
    const myId = req.user!.id;

    if (otherId === myId) throw badRequest('Cannot message yourself');

    // Find existing 1:1 conversation
    const existing = await prisma.conversation.findFirst({
      where: {
        isGroup: false,
        members: { every: { userId: { in: [myId, otherId] } } },
        AND: [
          { members: { some: { userId: myId } } },
          { members: { some: { userId: otherId } } },
        ],
      },
      include: CONV_INCLUDE,
    });

    if (existing) return ok(res, { conversation: existing });

    const conversation = await prisma.conversation.create({
      data: {
        isGroup: false,
        members: { create: [{ userId: myId }, { userId: otherId }] },
      },
      include: CONV_INCLUDE,
    });
    return created(res, { conversation });
  } catch (err) { next(err); }
}

export async function getMessages(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { conversationId } = req.params;
    const { page = '1', limit = '30' } = req.query;
    const skip = (Number(page) - 1) * Number(limit);

    const isMember = await prisma.conversationMember.findUnique({
      where: { conversationId_userId: { conversationId, userId: req.user!.id } },
    });
    if (!isMember) throw forbidden('Not a member of this conversation');

    const messages = await prisma.message.findMany({
      where: {
        conversationId,
        deletedFor: { none: { userId: req.user!.id } },
      },
      orderBy: { createdAt: 'desc' },
      skip,
      take: Number(limit),
      include: MSG_INCLUDE,
    });

    return ok(res, { messages: messages.reverse() });
  } catch (err) { next(err); }
}

export async function sendMessage(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { conversationId } = req.params;
    const { content, type = 'TEXT', replyToId } = req.body;
    const file = req.file;

    const member = await prisma.conversationMember.findUnique({
      where: { conversationId_userId: { conversationId, userId: req.user!.id } },
    });
    if (!member) throw forbidden('Not a member');

    let mediaUrl: string | undefined;
    let publicId: string | undefined;
    let duration: number | undefined;

    if (file) {
      const result = await uploadFromBuffer(file.buffer, {
        folder: FOLDERS.MESSAGES,
        resourceType: file.mimetype.startsWith('video') ? 'video' : file.mimetype.startsWith('audio') ? 'video' : 'image',
      });
      mediaUrl = result.url;
      publicId = result.publicId;
      duration = result.duration;
    }

    const message = await prisma.message.create({
      data: {
        conversationId,
        senderId: req.user!.id,
        type: type as any,
        content: content || null,
        mediaUrl,
        publicId,
        duration,
        fileName: file?.originalname,
        fileSize: file?.size,
        replyToId: replyToId || null,
      },
      include: MSG_INCLUDE,
    });

    // Update conversation lastMessage and timestamp
    await prisma.conversation.update({
      where: { id: conversationId },
      data: { lastMessageId: message.id, updatedAt: new Date() },
    });

    // Reset unread for sender, increment for others
    await prisma.conversationMember.updateMany({
      where: { conversationId, userId: { not: req.user!.id } },
      data: { unreadCount: { increment: 1 } },
    });
    await prisma.conversationMember.update({
      where: { conversationId_userId: { conversationId, userId: req.user!.id } },
      data: { unreadCount: 0 },
    });

    // Emit to all members
    const members = await prisma.conversationMember.findMany({ where: { conversationId }, select: { userId: true } });
    members.forEach(m => {
      (req as any).io?.to(m.userId).emit('new_message', { conversationId, message });
    });

    return created(res, { message });
  } catch (err) { next(err); }
}

export async function editMessage(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const msg = await prisma.message.findUnique({ where: { id: req.params.id } });
    if (!msg) throw notFound('Message');
    if (msg.senderId !== req.user!.id) throw forbidden();

    const updated = await prisma.message.update({
      where: { id: req.params.id },
      data: { content: req.body.content, isEdited: true },
      include: MSG_INCLUDE,
    });
    (req as any).io?.to(msg.conversationId).emit('message_edited', updated);
    return ok(res, { message: updated });
  } catch (err) { next(err); }
}

export async function deleteMessage(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { forEveryone = false } = req.body;
    const msg = await prisma.message.findUnique({ where: { id: req.params.id } });
    if (!msg) throw notFound('Message');

    if (forEveryone && msg.senderId === req.user!.id) {
      await prisma.message.update({ where: { id: req.params.id }, data: { isDeleted: true, content: null } });
      (req as any).io?.to(msg.conversationId).emit('message_deleted', { messageId: req.params.id });
    } else {
      await prisma.messageDeletedFor.create({ data: { messageId: req.params.id, userId: req.user!.id } });
    }
    return ok(res, {}, 'Message deleted');
  } catch (err) { next(err); }
}

export async function reactToMessage(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { emoji } = req.body;
    const messageId = req.params.id;
    const userId = req.user!.id;

    const existing = await prisma.messageReaction.findUnique({ where: { messageId_userId: { messageId, userId } } });
    if (existing) {
      if (existing.emoji === emoji) {
        await prisma.messageReaction.delete({ where: { messageId_userId: { messageId, userId } } });
      } else {
        await prisma.messageReaction.update({ where: { messageId_userId: { messageId, userId } }, data: { emoji } });
      }
    } else {
      await prisma.messageReaction.create({ data: { messageId, userId, emoji } });
    }

    const msg = await prisma.message.findUnique({ where: { id: messageId }, select: { conversationId: true, reactions: true } });
    (req as any).io?.to(msg?.conversationId).emit('message_reaction', { messageId, reactions: msg?.reactions });
    return ok(res, { reactions: msg?.reactions });
  } catch (err) { next(err); }
}

export async function markSeen(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { conversationId } = req.params;
    const unseenMessages = await prisma.message.findMany({
      where: {
        conversationId,
        senderId: { not: req.user!.id },
        seenBy: { none: { userId: req.user!.id } },
      },
      select: { id: true },
    });

    if (unseenMessages.length) {
      await prisma.messageSeen.createMany({
        data: unseenMessages.map(m => ({ messageId: m.id, userId: req.user!.id })),
        skipDuplicates: true,
      });
    }

    await prisma.conversationMember.update({
      where: { conversationId_userId: { conversationId, userId: req.user!.id } },
      data: { unreadCount: 0 },
    });

    (req as any).io?.to(conversationId).emit('messages_seen', { conversationId, userId: req.user!.id });
    return ok(res, {});
  } catch (err) { next(err); }
}

export async function createGroupChat(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { participantIds, groupName, groupPhoto } = req.body;
    const allIds = [...new Set([req.user!.id, ...participantIds])];

    const conversation = await prisma.conversation.create({
      data: {
        isGroup: true,
        groupName,
        groupPhoto,
        members: {
          create: allIds.map((uid: string) => ({
            userId: uid,
            role: uid === req.user!.id ? 'ADMIN' : 'MEMBER',
          })),
        },
      },
      include: CONV_INCLUDE,
    });
    return created(res, { conversation });
  } catch (err) { next(err); }
}
