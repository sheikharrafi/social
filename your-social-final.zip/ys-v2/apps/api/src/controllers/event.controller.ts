import { Response, NextFunction } from 'express';
import prisma from '../lib/prisma';
import { ok, created, notFound, forbidden } from '../lib/errors';
import { AuthRequest } from '../middleware/auth';

const EVENT_INCLUDE = {
  host: { select: { id: true, firstName: true, lastName: true, profilePicture: true, username: true } },
  _count: { select: { attendees: true } },
} as const;

export async function getEvents(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { page = '1', limit = '20', upcoming = 'true' } = req.query;
    const skip = (Number(page) - 1) * Number(limit);

    const where: any = { privacy: { in: ['PUBLIC', 'FRIENDS'] } };
    if (upcoming === 'true') where.startDate = { gte: new Date() };

    const events = await prisma.event.findMany({
      where,
      orderBy: { startDate: 'asc' },
      skip,
      take: Number(limit),
      include: EVENT_INCLUDE,
    });

    return ok(res, { events });
  } catch (err) { next(err); }
}

export async function getMyEvents(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const [hosting, attending] = await Promise.all([
      prisma.event.findMany({
        where: { hostId: req.user!.id },
        include: EVENT_INCLUDE,
        orderBy: { startDate: 'asc' },
      }),
      prisma.eventAttendee.findMany({
        where: { userId: req.user!.id, rsvp: { in: ['GOING', 'MAYBE'] } },
        include: { event: { include: EVENT_INCLUDE } },
      }),
    ]);

    return ok(res, { hosting, attending: attending.map(a => ({ ...a.event, myRsvp: a.rsvp })) });
  } catch (err) { next(err); }
}

export async function createEvent(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { title, description, startDate, endDate, location, onlineLink, privacy, category, coverPhoto } = req.body;
    const event = await prisma.event.create({
      data: {
        hostId: req.user!.id,
        title,
        description,
        startDate: new Date(startDate),
        endDate: endDate ? new Date(endDate) : undefined,
        location,
        onlineLink,
        privacy: privacy || 'PUBLIC',
        category: category || 'General',
        coverPhoto,
      },
      include: EVENT_INCLUDE,
    });
    return created(res, { event });
  } catch (err) { next(err); }
}

export async function getEvent(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const event = await prisma.event.findUnique({
      where: { id: req.params.id },
      include: {
        ...EVENT_INCLUDE,
        attendees: {
          take: 20,
          include: { event: false } as any,
        },
      },
    });
    if (!event) throw notFound('Event');

    const myAttendance = req.user
      ? await prisma.eventAttendee.findUnique({
          where: { eventId_userId: { eventId: req.params.id, userId: req.user.id } },
        })
      : null;

    return ok(res, { event, myRsvp: myAttendance?.rsvp || null });
  } catch (err) { next(err); }
}

export async function rsvpEvent(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { rsvp } = req.body; // GOING | MAYBE | NOT_GOING
    const eventId = req.params.id;

    const attendance = await prisma.eventAttendee.upsert({
      where: { eventId_userId: { eventId, userId: req.user!.id } },
      create: { eventId, userId: req.user!.id, rsvp },
      update: { rsvp },
    });

    return ok(res, { attendance }, `RSVP: ${rsvp}`);
  } catch (err) { next(err); }
}

export async function updateEvent(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const event = await prisma.event.findUnique({ where: { id: req.params.id } });
    if (!event) throw notFound('Event');
    if (event.hostId !== req.user!.id) throw forbidden();

    const updated = await prisma.event.update({
      where: { id: req.params.id },
      data: req.body,
      include: EVENT_INCLUDE,
    });
    return ok(res, { event: updated });
  } catch (err) { next(err); }
}

export async function deleteEvent(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const event = await prisma.event.findUnique({ where: { id: req.params.id } });
    if (!event) throw notFound('Event');
    if (event.hostId !== req.user!.id && req.user!.role !== 'ADMIN') throw forbidden();
    await prisma.event.delete({ where: { id: req.params.id } });
    return ok(res, {}, 'Event deleted');
  } catch (err) { next(err); }
}
