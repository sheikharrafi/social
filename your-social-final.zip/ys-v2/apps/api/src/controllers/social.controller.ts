import { Response, NextFunction } from 'express';
import prisma from '../lib/prisma';
import { ok, created, notFound, forbidden, badRequest } from '../lib/errors';
import { AuthRequest } from '../middleware/auth';
import { uploadFromBuffer, FOLDERS } from '../lib/cloudinary';

// ─── GROUPS ───────────────────────────────────────────

export async function getMyGroups(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const groups = await prisma.group.findMany({
      where: { members: { some: { userId: req.user!.id, isBanned: false } } },
      include: {
        _count: { select: { members: true, posts: true } },
        creator: { select: { id: true, firstName: true, lastName: true, profilePicture: true } },
      },
      orderBy: { updatedAt: 'desc' },
    });
    return ok(res, { groups });
  } catch (err) { next(err); }
}

export async function discoverGroups(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const groups = await prisma.group.findMany({
      where: {
        privacy: 'PUBLIC',
        members: { none: { userId: req.user!.id } },
      },
      include: { _count: { select: { members: true } }, creator: { select: { id: true, firstName: true, lastName: true } } },
      take: 20,
      orderBy: { createdAt: 'desc' },
    });
    return ok(res, { groups });
  } catch (err) { next(err); }
}

export async function createGroup(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const group = await prisma.group.create({
      data: {
        name: req.body.name,
        description: req.body.description,
        privacy: req.body.privacy || 'PUBLIC',
        category: req.body.category || 'General',
        creatorId: req.user!.id,
        members: { create: [{ userId: req.user!.id, role: 'ADMIN' }] },
      },
    });
    return created(res, { group });
  } catch (err) { next(err); }
}

export async function getGroup(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const group = await prisma.group.findUnique({
      where: { id: req.params.id },
      include: {
        creator: { select: { id: true, firstName: true, lastName: true, profilePicture: true } },
        members: {
          where: { isBanned: false },
          take: 12,
          include: { user: { select: { id: true, firstName: true, lastName: true, profilePicture: true, isOnline: true } } },
        },
        _count: { select: { members: true, posts: true } },
      },
    });
    if (!group) throw notFound('Group');

    const myMembership = await prisma.groupMember.findUnique({
      where: { groupId_userId: { groupId: req.params.id, userId: req.user!.id } },
    });

    return ok(res, { group, myRole: myMembership?.role || null, isMember: !!myMembership && !myMembership.isBanned });
  } catch (err) { next(err); }
}

export async function joinGroup(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const group = await prisma.group.findUnique({ where: { id: req.params.id } });
    if (!group) throw notFound('Group');

    await prisma.groupMember.upsert({
      where: { groupId_userId: { groupId: req.params.id, userId: req.user!.id } },
      create: { groupId: req.params.id, userId: req.user!.id, isPending: group.memberApproval },
      update: { isBanned: false },
    });

    return ok(res, { pending: group.memberApproval }, group.memberApproval ? 'Request sent' : 'Joined group');
  } catch (err) { next(err); }
}

export async function leaveGroup(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    await prisma.groupMember.delete({
      where: { groupId_userId: { groupId: req.params.id, userId: req.user!.id } },
    });
    return ok(res, {}, 'Left group');
  } catch (err) { next(err); }
}

export async function getGroupPosts(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { page = '1', limit = '10' } = req.query;
    const posts = await prisma.post.findMany({
      where: { groupId: req.params.id },
      orderBy: { createdAt: 'desc' },
      skip: (Number(page) - 1) * Number(limit),
      take: Number(limit),
      include: {
        author: { select: { id: true, firstName: true, lastName: true, profilePicture: true, username: true, isVerified: true } },
        media: { orderBy: { order: 'asc' } },
        reactions: { select: { userId: true, type: true } },
        _count: { select: { comments: true, reactions: true } },
      },
    });
    return ok(res, { posts });
  } catch (err) { next(err); }
}

// ─── PAGES ────────────────────────────────────────────

export async function getMyPages(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const pages = await prisma.page.findMany({
      where: { ownerId: req.user!.id },
      include: { _count: { select: { likes: true, posts: true } } },
      orderBy: { updatedAt: 'desc' },
    });
    return ok(res, { pages });
  } catch (err) { next(err); }
}

export async function createPage(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const page = await prisma.page.create({
      data: { ...req.body, ownerId: req.user!.id },
    });
    return created(res, { page });
  } catch (err) { next(err); }
}

export async function getPage(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const page = await prisma.page.findUnique({
      where: { id: req.params.id },
      include: {
        owner: { select: { id: true, firstName: true, lastName: true } },
        _count: { select: { likes: true, followers: true, posts: true } },
      },
    });
    if (!page) throw notFound('Page');

    const isLiked = !!(await prisma.pageLike.findUnique({
      where: { pageId_userId: { pageId: req.params.id, userId: req.user!.id } },
    }));
    return ok(res, { page, isLiked });
  } catch (err) { next(err); }
}

export async function togglePageLike(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const existing = await prisma.pageLike.findUnique({
      where: { pageId_userId: { pageId: req.params.id, userId: req.user!.id } },
    });
    if (existing) {
      await prisma.pageLike.delete({ where: { pageId_userId: { pageId: req.params.id, userId: req.user!.id } } });
      return ok(res, { liked: false });
    } else {
      await prisma.pageLike.create({ data: { pageId: req.params.id, userId: req.user!.id } });
      return ok(res, { liked: true });
    }
  } catch (err) { next(err); }
}

// ─── MARKETPLACE ──────────────────────────────────────

export async function getListings(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const { category, condition, minPrice, maxPrice, search, page = '1', limit = '20' } = req.query as any;
    const skip = (Number(page) - 1) * Number(limit);

    const where: any = { status: 'ACTIVE' };
    if (category) where.category = category;
    if (condition) where.condition = condition;
    if (minPrice || maxPrice) where.price = {};
    if (minPrice) where.price.gte = parseFloat(minPrice);
    if (maxPrice) where.price.lte = parseFloat(maxPrice);
    if (search) where.OR = [
      { title: { contains: search, mode: 'insensitive' } },
      { description: { contains: search, mode: 'insensitive' } },
    ];

    const [listings, total] = await Promise.all([
      prisma.marketplaceListing.findMany({
        where, skip, take: Number(limit),
        orderBy: { createdAt: 'desc' },
        include: {
          seller: { select: { id: true, firstName: true, lastName: true, profilePicture: true } },
          images: { orderBy: { order: 'asc' } },
        },
      }),
      prisma.marketplaceListing.count({ where }),
    ]);

    return ok(res, { listings, total, pages: Math.ceil(total / Number(limit)) });
  } catch (err) { next(err); }
}

export async function createListing(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const files = (req.files as Express.Multer.File[]) || [];
    const listing = await prisma.marketplaceListing.create({
      data: {
        sellerId: req.user!.id,
        title: req.body.title,
        description: req.body.description,
        price: parseFloat(req.body.price),
        currency: req.body.currency || 'BDT',
        category: req.body.category || 'Other',
        condition: req.body.condition || 'GOOD',
        location: req.body.location,
        negotiable: req.body.negotiable === 'true',
      },
    });

    if (files.length) {
      const uploads = await Promise.all(files.map((f, i) =>
        uploadFromBuffer(f.buffer, { folder: FOLDERS.MARKETPLACE, resourceType: 'image' })
          .then(r => ({ listingId: listing.id, url: r.url, publicId: r.publicId, order: i }))
      ));
      await prisma.marketplaceImage.createMany({ data: uploads });
    }

    const full = await prisma.marketplaceListing.findUnique({
      where: { id: listing.id },
      include: { images: true, seller: { select: { id: true, firstName: true, lastName: true, profilePicture: true } } },
    });
    return created(res, { listing: full });
  } catch (err) { next(err); }
}

export async function getListing(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const listing = await prisma.marketplaceListing.findUnique({
      where: { id: req.params.id },
      include: {
        images: { orderBy: { order: 'asc' } },
        seller: { select: { id: true, firstName: true, lastName: true, profilePicture: true, isOnline: true } },
      },
    });
    if (!listing) throw notFound('Listing');
    await prisma.marketplaceListing.update({ where: { id: req.params.id }, data: { viewCount: { increment: 1 } } });
    return ok(res, { listing });
  } catch (err) { next(err); }
}

export async function updateListing(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const listing = await prisma.marketplaceListing.findUnique({ where: { id: req.params.id } });
    if (!listing) throw notFound('Listing');
    if (listing.sellerId !== req.user!.id) throw forbidden();
    const updated = await prisma.marketplaceListing.update({ where: { id: req.params.id }, data: req.body });
    return ok(res, { listing: updated });
  } catch (err) { next(err); }
}

export async function deleteListing(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const listing = await prisma.marketplaceListing.findUnique({ where: { id: req.params.id } });
    if (!listing) throw notFound('Listing');
    if (listing.sellerId !== req.user!.id && req.user!.role !== 'ADMIN') throw forbidden();
    await prisma.marketplaceListing.delete({ where: { id: req.params.id } });
    return ok(res, {}, 'Listing deleted');
  } catch (err) { next(err); }
}

export async function getMyListings(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const listings = await prisma.marketplaceListing.findMany({
      where: { sellerId: req.user!.id },
      include: { images: { take: 1, orderBy: { order: 'asc' } } },
      orderBy: { createdAt: 'desc' },
    });
    return ok(res, { listings });
  } catch (err) { next(err); }
}
