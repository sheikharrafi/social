import { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import prisma from '../lib/prisma';
import { signToken, generateShortToken } from '../lib/jwt';
import { sendVerificationEmail, sendPasswordResetEmail } from '../lib/email';
import { ok, created, badRequest, unauthorized, conflict, AppError } from '../lib/errors';
import { AuthRequest } from '../middleware/auth';

const USER_SELECT = {
  id: true,
  firstName: true,
  lastName: true,
  email: true,
  username: true,
  profilePicture: true,
  coverPhoto: true,
  bio: true,
  role: true,
  isVerified: true,
  emailVerified: true,
  isOnline: true,
  lastSeen: true,
  createdAt: true,
  privacyProfile: true,
  privacyFriendList: true,
  privacyPostDefault: true,
  notifFriendRequests: true,
  notifPostLikes: true,
  notifComments: true,
  notifMessages: true,
  notifGroupActivity: true,
  website: true,
  location: true,
  workplace: true,
  education: true,
  relationship: true,
  birthday: true,
  gender: true,
  hometown: true,
} as const;

export async function register(req: Request, res: Response, next: NextFunction) {
  try {
    const { firstName, lastName, email, password, birthday, gender } = req.body;

    const existing = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });
    if (existing) throw conflict('Email already registered');

    const hashed = await bcrypt.hash(password, 12);
    const verifyToken = generateShortToken();

    const user = await prisma.user.create({
      data: {
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        email: email.toLowerCase().trim(),
        password: hashed,
        birthday: birthday ? new Date(birthday) : undefined,
        gender: gender || undefined,
        emailVerifyToken: verifyToken,
      },
      select: USER_SELECT,
    });

    // Send verification email (non-blocking)
    sendVerificationEmail(user.email, verifyToken, user.firstName).catch(console.error);

    const token = signToken({ id: user.id, role: user.role });
    return created(res, { token, user }, 'Account created successfully');
  } catch (err) { next(err); }
}

export async function login(req: Request, res: Response, next: NextFunction) {
  try {
    const { email, password } = req.body;

    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase() },
      select: { ...USER_SELECT, password: true },
    });
    if (!user) throw unauthorized('Invalid credentials');

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) throw unauthorized('Invalid credentials');

    // Update online status
    await prisma.user.update({
      where: { id: user.id },
      data: { isOnline: true, lastSeen: new Date() },
    });

    const { password: _, ...safeUser } = user;
    const token = signToken({ id: user.id, role: user.role });

    return ok(res, { token, user: safeUser }, 'Login successful');
  } catch (err) { next(err); }
}

export async function logout(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    if (req.user) {
      await prisma.user.update({
        where: { id: req.user.id },
        data: { isOnline: false, lastSeen: new Date() },
      });
    }
    return ok(res, {}, 'Logged out');
  } catch (err) { next(err); }
}

export async function getMe(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user!.id },
      select: {
        ...USER_SELECT,
        _count: {
          select: {
            friendships: { where: { status: 'ACCEPTED' } },
            friendshipsOf: { where: { status: 'ACCEPTED' } },
            followers: true,
            following: true,
            posts: true,
          },
        },
      },
    });
    if (!user) throw unauthorized('User not found');
    return ok(res, { user });
  } catch (err) { next(err); }
}

export async function verifyEmail(req: Request, res: Response, next: NextFunction) {
  try {
    const { token } = req.body;
    const user = await prisma.user.findFirst({ where: { emailVerifyToken: token } });
    if (!user) throw badRequest('Invalid or expired verification token');

    await prisma.user.update({
      where: { id: user.id },
      data: { emailVerified: true, emailVerifyToken: null },
    });
    return ok(res, {}, 'Email verified successfully');
  } catch (err) { next(err); }
}

export async function forgotPassword(req: Request, res: Response, next: NextFunction) {
  try {
    const { email } = req.body;
    const user = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });

    // Always return success to prevent email enumeration
    if (user) {
      const resetToken = generateShortToken();
      const expiry = new Date(Date.now() + 3600000); // 1 hour

      await prisma.user.update({
        where: { id: user.id },
        data: { resetToken, resetTokenExpiry: expiry },
      });

      sendPasswordResetEmail(user.email, resetToken, user.firstName).catch(console.error);
    }

    return ok(res, {}, 'If that email is registered, you will receive a reset link');
  } catch (err) { next(err); }
}

export async function resetPassword(req: Request, res: Response, next: NextFunction) {
  try {
    const { token, password } = req.body;

    const user = await prisma.user.findFirst({
      where: {
        resetToken: token,
        resetTokenExpiry: { gt: new Date() },
      },
    });
    if (!user) throw badRequest('Invalid or expired reset token');

    const hashed = await bcrypt.hash(password, 12);
    await prisma.user.update({
      where: { id: user.id },
      data: { password: hashed, resetToken: null, resetTokenExpiry: null },
    });

    return ok(res, {}, 'Password reset successfully');
  } catch (err) { next(err); }
}

export async function refreshToken(req: AuthRequest, res: Response, next: NextFunction) {
  try {
    const token = signToken({ id: req.user!.id, role: req.user!.role });
    return ok(res, { token });
  } catch (err) { next(err); }
}
