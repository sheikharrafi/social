import { Router } from 'express';
import { protect, adminOnly, optionalAuth } from '../middleware/auth';
import { uploadSingle as uploadMiddleware, uploadMultiple as uploadMultipleMiddleware } from '../middleware/upload';

import * as auth from '../controllers/auth.controller';
import * as user from '../controllers/user.controller';
import * as post from '../controllers/post.controller';
import * as comment from '../controllers/comment.controller';
import * as friend from '../controllers/friend.controller';
import * as message from '../controllers/message.controller';
import * as content from '../controllers/content.controller';
import * as social from '../controllers/social.controller';
import * as upload from '../controllers/upload.controller';
import * as event from '../controllers/event.controller';

const router = Router();

// ─── AUTH ─────────────────────────────────────────────
router.post('/auth/register', auth.register);
router.post('/auth/login', auth.login);
router.post('/auth/logout', protect, auth.logout);
router.get('/auth/me', protect, auth.getMe);
router.post('/auth/verify-email', auth.verifyEmail);
router.post('/auth/forgot-password', auth.forgotPassword);
router.post('/auth/reset-password', auth.resetPassword);
router.post('/auth/refresh', protect, auth.refreshToken);

// ─── USERS ────────────────────────────────────────────
router.get('/users/suggestions', protect, user.getSuggestedUsers);
router.get('/users/birthdays', protect, user.getBirthdays);
router.get('/users/analytics', protect, user.getCreatorAnalytics);
router.put('/users/profile', protect, user.updateProfile);
router.put('/users/password', protect, user.changePassword);
router.post('/users/avatar', protect, uploadMiddleware, user.uploadProfilePicture);
router.post('/users/cover', protect, uploadMiddleware, user.uploadCoverPhoto);
router.get('/users/:userId', optionalAuth, user.getProfile);
router.get('/users/:userId/friends', optionalAuth, user.getUserFriends);
router.get('/users/:userId/photos', optionalAuth, user.getUserPhotos);
router.post('/users/:userId/block', protect, user.blockUser);
router.delete('/users/:userId/block', protect, user.unblockUser);

// ─── FRIENDS ──────────────────────────────────────────
router.get('/friends/requests', protect, friend.getFriendRequests);
router.post('/friends/request/:userId', protect, friend.sendFriendRequest);
router.post('/friends/accept/:userId', protect, friend.acceptFriendRequest);
router.post('/friends/decline/:userId', protect, friend.declineFriendRequest);
router.delete('/friends/cancel/:userId', protect, friend.cancelFriendRequest);
router.delete('/friends/unfriend/:userId', protect, friend.unfriend);
router.post('/friends/follow/:userId', protect, friend.toggleFollow);

// ─── POSTS ────────────────────────────────────────────
router.get('/posts/feed', protect, post.getFeed);
router.get('/posts/saved', protect, post.getSavedPosts);
router.get('/posts/user/:userId', optionalAuth, post.getUserPosts);
router.post('/posts', protect, uploadMultipleMiddleware, post.createPost);
router.get('/posts/:id', optionalAuth, post.getPost);
router.put('/posts/:id', protect, post.updatePost);
router.delete('/posts/:id', protect, post.deletePost);
router.post('/posts/:id/react', protect, post.reactToPost);
router.post('/posts/:id/share', protect, post.sharePost);
router.post('/posts/:id/save', protect, post.savePost);
router.post('/posts/poll/vote', protect, post.votePoll);

// ─── COMMENTS ─────────────────────────────────────────
router.get('/comments/:postId', optionalAuth, comment.getComments);
router.post('/comments', protect, comment.createComment);
router.put('/comments/:id', protect, comment.updateComment);
router.delete('/comments/:id', protect, comment.deleteComment);
router.post('/comments/:id/react', protect, comment.reactToComment);
router.get('/comments/:id/replies', optionalAuth, comment.getReplies);

// ─── STORIES ──────────────────────────────────────────
router.get('/stories', protect, content.getStories);
router.post('/stories', protect, uploadMiddleware, content.createStory);
router.post('/stories/:id/view', protect, content.viewStory);
router.post('/stories/:id/react', protect, content.reactToStory);
router.delete('/stories/:id', protect, content.deleteStory);

// ─── REELS ────────────────────────────────────────────
router.get('/reels', optionalAuth, content.getReels);
router.post('/reels', protect, uploadMiddleware, content.createReel);
router.post('/reels/:id/view', optionalAuth, content.viewReel);
router.post('/reels/:id/react', protect, content.reactToReel);
router.delete('/reels/:id', protect, content.deleteReel);

// ─── MESSAGES ─────────────────────────────────────────
router.get('/messages/conversations', protect, message.getConversations);
router.get('/messages/conversations/:userId', protect, message.getOrCreateConversation);
router.post('/messages/group', protect, message.createGroupChat);
router.get('/messages/:conversationId', protect, message.getMessages);
router.post('/messages/:conversationId', protect, uploadMiddleware, message.sendMessage);
router.post('/messages/:conversationId/seen', protect, message.markSeen);
router.put('/messages/:id', protect, message.editMessage);
router.delete('/messages/:id', protect, message.deleteMessage);
router.post('/messages/:id/react', protect, message.reactToMessage);

// ─── NOTIFICATIONS ────────────────────────────────────
router.get('/notifications', protect, content.getNotifications);
router.put('/notifications/read-all', protect, content.markAllRead);
router.put('/notifications/:id/read', protect, content.markOneRead);
router.delete('/notifications/:id', protect, content.deleteNotification);

// ─── GROUPS ───────────────────────────────────────────
router.get('/groups', protect, social.getMyGroups);
router.get('/groups/discover', protect, social.discoverGroups);
router.post('/groups', protect, social.createGroup);
router.get('/groups/:id', protect, social.getGroup);
router.post('/groups/:id/join', protect, social.joinGroup);
router.post('/groups/:id/leave', protect, social.leaveGroup);
router.get('/groups/:id/posts', protect, social.getGroupPosts);

// ─── PAGES ────────────────────────────────────────────
router.get('/pages', protect, social.getMyPages);
router.post('/pages', protect, social.createPage);
router.get('/pages/:id', protect, social.getPage);
router.post('/pages/:id/like', protect, social.togglePageLike);

// ─── MARKETPLACE ──────────────────────────────────────
router.get('/marketplace', optionalAuth, social.getListings);
router.get('/marketplace/my', protect, social.getMyListings);
router.post('/marketplace', protect, uploadMultipleMiddleware, social.createListing);
router.get('/marketplace/:id', optionalAuth, social.getListing);
router.put('/marketplace/:id', protect, social.updateListing);
router.delete('/marketplace/:id', protect, social.deleteListing);

// ─── EVENTS ───────────────────────────────────────────
router.get('/events', optionalAuth, event.getEvents);
router.get('/events/my', protect, event.getMyEvents);
router.post('/events', protect, event.createEvent);
router.get('/events/:id', optionalAuth, event.getEvent);
router.put('/events/:id', protect, event.updateEvent);
router.delete('/events/:id', protect, event.deleteEvent);
router.post('/events/:id/rsvp', protect, event.rsvpEvent);

// ─── SEARCH ───────────────────────────────────────────
router.get('/search', optionalAuth, content.search);
router.get('/trending', content.getTrending);

// ─── UPLOAD ───────────────────────────────────────────
router.post('/upload/single', protect, uploadMiddleware, upload.uploadSingle);
router.post('/upload/multiple', protect, uploadMultipleMiddleware, upload.uploadMultiple);
router.delete('/upload', protect, upload.deleteMedia);

// ─── VERIFICATION ─────────────────────────────────────
router.post('/verification/submit', protect, uploadMiddleware, upload.submitVerification);
router.get('/admin/verification', protect, adminOnly, upload.getVerificationRequests);
router.post('/admin/verification/:id', protect, adminOnly, upload.reviewVerification);

// ─── REPORTS ──────────────────────────────────────────
router.post('/reports', protect, upload.submitReport);
router.get('/admin/reports', protect, adminOnly, upload.getPendingReports);

// ─── ADMIN ────────────────────────────────────────────
router.get('/admin/stats', protect, adminOnly, upload.getAdminStats);
router.get('/admin/users', protect, adminOnly, upload.getAdminUsers);

export default router;
