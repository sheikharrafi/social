import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // Admin user
  const adminPassword = await bcrypt.hash('Admin@123456', 12);
  const admin = await prisma.user.upsert({
    where: { email: 'admin@yoursocial.app' },
    update: {},
    create: {
      firstName: 'Admin',
      lastName: 'User',
      email: 'admin@yoursocial.app',
      password: adminPassword,
      username: 'admin',
      role: 'ADMIN',
      emailVerified: true,
      isVerified: true,
      bio: 'Your Social Administrator',
    },
  });
  console.log('✅ Admin user created:', admin.email);

  // Demo user
  const demoPassword = await bcrypt.hash('Demo@123456', 12);
  const demo = await prisma.user.upsert({
    where: { email: 'demo@yoursocial.app' },
    update: {},
    create: {
      firstName: 'Demo',
      lastName: 'User',
      email: 'demo@yoursocial.app',
      password: demoPassword,
      username: 'demouser',
      emailVerified: true,
      bio: 'Welcome to Your Social! This is a demo account.',
      location: 'Dhaka, Bangladesh',
    },
  });
  console.log('✅ Demo user created:', demo.email);

  // Sample hashtags
  const tags = ['yoursocial', 'photography', 'travel', 'food', 'technology', 'music', 'art', 'sports'];
  for (const name of tags) {
    await prisma.hashtag.upsert({ where: { name }, update: {}, create: { name, postCount: 0 } });
  }
  console.log('✅ Hashtags seeded');

  console.log('✅ Seeding complete!');
  console.log('\n📝 Demo credentials:');
  console.log('   Admin: admin@yoursocial.app / Admin@123456');
  console.log('   Demo:  demo@yoursocial.app  / Demo@123456');
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
