# Your Social 🌐

A production-ready, full-stack social media platform built with modern technologies.

## ✨ Features

### Core
- 🔐 JWT Authentication (Login, Register, Email Verification, Password Reset)
- 👤 Rich Profiles (Avatar, Cover Photo, Bio, About, Friends, Photos)
- 📰 News Feed with infinite scroll
- 📖 Stories (24h expiry, image/video/text)
- 🎬 Reels (vertical infinite scroll)
- ❤️ 6-type Reactions (Like, Love, Haha, Wow, Sad, Angry)
- 💬 Nested Comments & Replies
- 📤 Share & Save Posts
- 📊 Polls

### Social
- 👥 Friend System (Send/Accept/Decline/Cancel)
- 🔔 Follow System
- 🔍 Universal Search (People, Posts, Groups, Hashtags)
- 📢 Trending Hashtags & Posts
- 👥 Groups (Public/Private, Roles, Posts)
- 🚩 Pages

### Messaging
- 💌 Real-time Messenger (Socket.IO)
- 💬 Group Chats
- ↩️ Reply to Messages
- 🗑️ Delete for Everyone
- 👁️ Read Receipts & Typing Indicator
- 🟢 Online Status

### Media
- 📸 Multi-image Posts
- 📹 Video Posts & Watch
- ☁️ Cloudinary Storage
- 🖼️ Image Viewer

### Commerce & More
- 🛒 Marketplace (Buy & Sell)
- 🔔 Real-time Notifications
- ✅ Verification System (Blue tick)
- 📊 Creator Analytics
- ⚙️ Full Settings (Profile, Privacy, Notifications, Display)
- 🌙 Dark / Light Mode

## 🛠 Tech Stack

| | Technology |
|---|---|
| **Frontend** | Next.js 14, TypeScript, Tailwind CSS, Framer Motion |
| **UI Components** | Radix UI, Lucide Icons, shadcn/ui |
| **State** | Zustand |
| **Backend** | Node.js, Express, TypeScript |
| **Database** | Supabase PostgreSQL |
| **ORM** | Prisma |
| **Realtime** | Socket.IO |
| **Media** | Cloudinary |
| **Email** | Resend |
| **Auth** | JWT |
| **Deploy** | Vercel (frontend) + Render (backend) |

## 📁 Structure

```
your-social/
├── apps/
│   ├── api/                 # Express backend
│   │   ├── prisma/
│   │   │   ├── schema.prisma
│   │   │   └── seed.ts
│   │   └── src/
│   │       ├── controllers/
│   │       ├── lib/
│   │       ├── middleware/
│   │       ├── routes/
│   │       └── services/
│   └── web/                 # Next.js frontend
│       └── src/
│           ├── app/         # App Router pages
│           ├── components/
│           ├── lib/
│           └── store/
├── DEPLOYMENT.md
└── README.md
```

## 🚀 Quick Start

See [DEPLOYMENT.md](./DEPLOYMENT.md) for full setup instructions.

```bash
npm install
# Set up .env files
npm run db:generate
npm run db:migrate
npm run db:seed
npm run dev
```

## 📝 API Routes

| Method | Route | Description |
|--------|-------|-------------|
| POST | /api/auth/register | Register |
| POST | /api/auth/login | Login |
| GET | /api/auth/me | Get current user |
| GET | /api/posts/feed | Get news feed |
| POST | /api/posts | Create post |
| POST | /api/posts/:id/react | React to post |
| GET | /api/stories | Get stories |
| GET | /api/reels | Get reels |
| GET | /api/messages/conversations | Get conversations |
| POST | /api/messages/:id | Send message |
| GET | /api/notifications | Get notifications |
| GET | /api/search | Universal search |
| GET | /api/trending | Trending content |
| GET | /api/groups | My groups |
| GET | /api/marketplace | Listings |
| GET | /api/admin/stats | Admin stats |

See full route list in `apps/api/src/routes/index.ts`
