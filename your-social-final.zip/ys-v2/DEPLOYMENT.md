# Your Social — Deployment Guide

## Tech Stack
| Layer | Service | Plan |
|-------|---------|------|
| Frontend | Next.js on Vercel | Free |
| Backend | Node.js/Express on Render | Free |
| Database | Supabase PostgreSQL | Free |
| Media | Cloudinary | Free |
| Email | Resend | Free |
| Realtime | Socket.IO (on Render) | — |

---

## 1. Database — Supabase

1. Go to [supabase.com](https://supabase.com) → New Project
2. Copy from **Settings → Database**:
   - `DATABASE_URL` (Connection string — Transaction mode)
   - `DIRECT_URL` (Connection string — Session mode)
3. Copy from **Settings → API**:
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY`

---

## 2. Media — Cloudinary

1. Go to [cloudinary.com](https://cloudinary.com) → Free account
2. Copy from Dashboard:
   - `CLOUDINARY_CLOUD_NAME`
   - `CLOUDINARY_API_KEY`
   - `CLOUDINARY_API_SECRET`

---

## 3. Email — Resend

1. Go to [resend.com](https://resend.com) → Free account
2. Create an API key → copy `RESEND_API_KEY`
3. Add your sending domain (or use `onboarding@resend.dev` for testing)

---

## 4. Backend — Render

1. Push your code to GitHub
2. Go to [render.com](https://render.com) → New Web Service
3. Connect your GitHub repo
4. Settings:
   - **Build command:** `cd apps/api && npm install && npx prisma generate && npm run build`
   - **Start command:** `cd apps/api && node dist/index.js`
   - **Node version:** 20
5. Add all environment variables from `apps/api/.env.example`
6. Set `CLIENT_URL` = your Vercel URL (after deploying frontend)

### Run database migrations (first time):
In Render shell or locally with production DATABASE_URL:
```bash
cd apps/api
npx prisma migrate deploy
npx tsx prisma/seed.ts
```

---

## 5. Frontend — Vercel

1. Go to [vercel.com](https://vercel.com) → New Project
2. Import your GitHub repo
3. Framework: **Next.js**
4. Root directory: `apps/web`
5. Add environment variables:
   - `NEXT_PUBLIC_API_URL` = `https://your-render-app.onrender.com/api`
   - `NEXT_PUBLIC_SOCKET_URL` = `https://your-render-app.onrender.com`

---

## 6. Local Development

```bash
# 1. Clone and install
git clone <your-repo>
cd your-social
npm install

# 2. Set up API env
cp apps/api/.env.example apps/api/.env
# Edit apps/api/.env with your credentials

# 3. Set up web env
cp apps/web/.env.example apps/web/.env
# Edit apps/web/.env

# 4. Generate Prisma client
npm run db:generate

# 5. Run migrations
npm run db:migrate:dev  # (in apps/api)
# or for existing DB:
npm run db:migrate

# 6. Seed database
npm run db:seed

# 7. Start development
npm run dev
# API: http://localhost:5000
# Web: http://localhost:3000
```

---

## 7. Demo Credentials (after seeding)

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@yoursocial.app | Admin@123456 |
| Demo | demo@yoursocial.app | Demo@123456 |

---

## 8. Environment Variables Reference

### apps/api/.env
```env
DATABASE_URL=postgresql://...
DIRECT_URL=postgresql://...
SUPABASE_URL=https://xxx.supabase.co
SUPABASE_ANON_KEY=eyJ...
JWT_SECRET=your-super-secret-jwt-key-min-32-chars
JWT_EXPIRES_IN=30d
CLOUDINARY_CLOUD_NAME=your-cloud-name
CLOUDINARY_API_KEY=your-api-key
CLOUDINARY_API_SECRET=your-api-secret
RESEND_API_KEY=re_...
FROM_EMAIL=noreply@yoursocial.app
CLIENT_URL=https://your-vercel-app.vercel.app
PORT=5000
NODE_ENV=production
```

### apps/web/.env
```env
NEXT_PUBLIC_API_URL=https://your-render-app.onrender.com/api
NEXT_PUBLIC_SOCKET_URL=https://your-render-app.onrender.com
NEXT_PUBLIC_APP_NAME=Your Social
NEXT_PUBLIC_APP_URL=https://your-vercel-app.vercel.app
```
